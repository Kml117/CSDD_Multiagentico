# Parche v0.4.1 → v0.4.2 · Windows sin ajustes manuales y versiones alineadas

Contiene **solo** los 25 archivos que cambian o son nuevos respecto de: v0.4.0 + parche v0.4.1 (el árbol que ya tiene Claude Code). **No borra nada.**
Rutas relativas a la carpeta `csdd-multiagent-engineering-system/`. **No incluye `dist/`**: se regenera con `python scripts/build_claude_web.py` (solo cambia `csdd-multiagent-orchestrator.zip`).

## Qué cambia
- **Guard y CLI en UTF-8:** ya no hace falta `PYTHONUTF8=1` en Windows.
- **Instaladores (`install.sh`, `Install.ps1`):** prueban cada Python candidato y descartan el alias vacío de la Tienda de Microsoft; aceptan `CSDD_PYTHON`; `Install.ps1` escribe `settings.json` sin BOM.
- **Versiones alineadas** (`csdd-mentor@1.6.1`, `VERSION`, roles, sistema, plantillas, manifest).
- **Pruebas:** 24 en total (14 pasan + 10 brechas que fallan a propósito). Nuevas: `test_13` y `test_14`; `tests/test_known_gaps.py` es nuevo en este árbol.
- **Roadmap** (`docs/ROADMAP-DESARROLLO.md`, nuevo en este árbol) con lo que se comprobó en Windows.

## Aplicarlo
1. Copia la carpeta `v0.4.1/csdd-multiagent-engineering-system` a una nueva `v0.4.2/` (no toques la v0.4.1).
2. Descomprime este zip encima. **Antes de sobrescribir `README.md`, `CHANGELOG.md`, `MANIFEST.yaml`, `MIGRATION-0.3-to-0.4.md` y `EXECUTION_GUIDE.md`, compáralos con los actuales** y conserva cualquier cosa que se hubiera añadido a mano (p. ej. enlaces a `MANUAL-DE-USO.md`).
3. `python -m unittest discover -s tests -v` → esperado: `Ran 24 tests … OK (expected failures=10)`. **En Windows:** `OK (skipped=1, expected failures=10)`: `test_14` se omite allí (usa enlaces simbólicos y un PATH POSIX).
4. Mueve `PARCHE-v0.4.2-LEEME.md` fuera del paquete (a `origen/`): no es parte del paquete.

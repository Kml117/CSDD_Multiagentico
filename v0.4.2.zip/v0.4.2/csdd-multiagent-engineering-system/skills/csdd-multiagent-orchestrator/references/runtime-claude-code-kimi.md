# Runtime: Claude Code + Kimi Code en VS Code (v0.4.2)

> Estatus de cada afirmación: **VALIDADO** (documentación oficial consultada en nov 2026 o probado en la suite `tests/test_system.py`), **HIPÓTESIS** (toca verificar en tu máquina), **PROPUESTA** (diseño recomendado).

## 1. Instalación en un repositorio (ej. Corbeta)

```bash
cd ~/proyectos/corbeta            # repo git existente
bash /ruta/csdd-multiagent-engineering-system/scripts/install.sh .
# Windows PowerShell: .\scripts\Install.ps1 -TargetPath C:\ruta\corbeta
git add .csdd .claude .agents AGENTS.md CLAUDE.md .github .gitignore
git commit -m "chore: instala CSDD multi-agent v0.4.2"
python3 .csdd/tools/csdd.py doctor
```
- El instalador es idempotente: lo que ya existe se omite; `--force` respalda en `.csdd-backup/<fecha>/` y reemplaza. **VALIDADO (suite).**
- Commitea antes de crear worktrees: cada worktree solo tiene guard si `.csdd/` está en la rama base. **VALIDADO (suite).**
- Requiere Python 3.11+ (usa `tomllib`). Sin dependencias externas. **VALIDADO.**

## 2. Claude Code

- `.claude/settings.json` registra un hook `PreToolUse` para `Edit|Write|MultiEdit|NotebookEdit|Bash|Read` que ejecuta `.csdd/hooks/guard.py`. **VALIDADO:** exit 2 bloquea y el texto de stderr llega a Claude; cualquier otro código no bloquea (por eso el guard es *fail-secure*: ante error interno en escritura/shell devuelve 2).
- `permissions.deny` añade una segunda capa nativa (lectura de `.env`, `*.pem`, force push, `reset --hard`, `rm -rf`, `sudo`). Defensa en profundidad (Art. V).
- Subagentes: `.claude/agents/csdd-*.md` (Jarvis, El Hombre de la Bolsa, Cortana, El Portero), generados por `sync_agents.py` desde `roles.toml` + el bloque "Núcleo operativo" de cada Skill de rol. El campo `tools` limita herramientas de forma nativa (El Portero no tiene Edit/Write). **VALIDADO** el formato de frontmatter (`name`, `description`, `tools`, `model`).
- **HIPÓTESIS:** que el JSON del hook incluya la identidad del subagente (`agent_type` u otro). `guard.py` registra los *nombres* de los campos (nunca valores) en `.project/log/hook-payload-keys.jsonl`; `csdd.py doctor` te dice si llega. Si llega → Modo B disponible; si no → Modo A.
- Windows: el instalador de PowerShell cambia `python3` por `python` en el hook.

## 3. Kimi Code (extensión de VS Code)

- **VALIDADO (docs Kimi Code, nov 2026):** lee `AGENTS.md`; hooks en `~/.kimi-code/config.toml`; exit 0 permite, exit 2 bloquea, otro código permite (fail-open); solo `PreToolUse`, `Stop` y `UserPromptSubmit` pueden bloquear; la extensión de VS Code envuelve la CLI.
- **HIPÓTESIS:** el esquema exacto de la sección `[hooks]` y los nombres de herramientas (`ReadFile`, `WriteFile`, `StrReplaceFile`, `Shell`). La plantilla está en `.csdd/integrations/kimi/hooks.example.toml`; verifícala antes de confiar. Si los nombres difieren, añádelos a `WRITE_TOOLS/READ_TOOLS/SHELL_TOOLS` en `guard.py` (cambio protegido: hazlo tú y commitea).
- **HIPÓTESIS:** formato de agentes en `.agents/agents/` (lo genera `sync_agents.py` con frontmatter `name` y `description`).
- **PROPUESTA:** abre Kimi con la carpeta del worktree de la tarea (`<repo>-wt/T-001`). El `.csdd-task` de esa carpeta le asigna rol y tarea, así el guard sabe qué puede tocar sin depender de variables de entorno.

## 4. Flujo diario recomendado (Modo A)

En **cada** sesión (cualquier rol, cualquier worktree): `csdd.py session start` al empezar y `csdd.py session end --horas X` al cerrar. Sin sesión vigente el guard bloquea las modificaciones.


1. **Tú + Jefe Maestro (Claude Code, worktree principal):** objetivo → Jarvis especifica (EARS con REQ) → `csdd.py task new …` → `csdd.py worktree new T-001`.
2. **Kimi en `../corbeta-wt/T-001`:** `csdd.py task start T-001` → pruebas primero → commits `[REQ-…][Art. …]` → `csdd.py handoff T-001 …`.
3. **Jefe Maestro:** `csdd.py route` → `csdd.py worktree review T-001`.
4. **Claude Code (Cortana) en `../corbeta-wt/T-001-review`:** re-ejecuta, escribe pruebas de aceptación, guarda evidencia, `csdd.py result T-001 --status …`.
5. **El Portero** (si aplica): misma carpeta de revisión, sesión con `CSDD_ROLE=csdd-security-reviewer`.
6. **Jefe Maestro:** `csdd.py route` → `csdd.py merge T-001` → `csdd.py verify` → informe.
7. Periódico: `csdd.py watchdog` (tareas que superan `max_minutes`), `csdd.py status`.

## 5. Problemas frecuentes

| Síntoma | Causa probable | Solución |
|---|---|---|
| "necesita una tarea activa" | Implementador fuera de su worktree | Abre la carpeta de `csdd.py worktree new` |
| "escritura fuera del repositorio" | El agente intentó escribir en `.project/` del worktree principal | Usar `csdd.py send/handoff/result` (escriben ahí por ti) |
| "posible bucle" | Mismo comando >4 veces sin editar nada | Cambiar estrategia o BLOCKER |
| "presupuesto agotado" | Llegó a `max_tool_calls` | BLOCKER al Jefe Maestro; él decide ampliar (nueva tarea) o partir |
| El guard no bloquea nada | Hook no registrado o worktree sin `.csdd/` | `csdd.py doctor`; commitear `.csdd/` en la base |
| Todo bloqueado con "error interno" | `roles.toml` inválido o Python < 3.11 | `python3 -c "import tomllib"`; revisar `roles.toml` |
| Falsos positivos de shell | Heurística (p. ej. `>` dentro de un string) | Reescribir el comando, o autorización Comunista con `--commands` |

## 6. Límites honestos

- El análisis de shell es heurístico: `python -c "open('x','w')"` no se detecta. Por eso CI (`csdd-gate.yml`) y la revisión de alcance de Cortana (`git diff --name-only`) siguen siendo obligatorios.
- La bitácora y el estado (`.project/state`, `.project/log`) no se versionan; si necesitas auditoría durable, archívalos periódicamente.
- Los hooks de Kimi son fail-open por diseño: un hook mal configurado deja pasar todo.

## 6. Windows (probado por Claude Code el 3-nov-2026; ver notas de estatus)

**Requisitos [VALIDADO]:** Python 3.11+ real, Git para Windows (trae `bash`, que necesitan `install.sh` y la suite de pruebas) o usar `scripts\Install.ps1`. Un `python3` que solo abre la Tienda de Microsoft es un alias vacío, no un Python.

| Hallazgo (Windows, 3-nov) | Estado en 0.4.2 |
|---|---|
| `install.sh` no encontraba `python3` (solo existía el alias de la Tienda) | **Corregido**: prueba cada candidato (`python3.13`…`python`) ejecutándolo; se puede forzar con `CSDD_PYTHON` |
| Sin `PYTHONUTF8=1`, 3 pruebas fallaban por tildes rotas en los mensajes del guard | **Corregido en el código** (UTF-8 forzado en stdin/stdout/stderr y al leer los argumentos). Validado emulando una consola sin UTF-8 en Linux; **falta reconfirmarlo en Windows real** |
| `Install.ps1` + `doctor` + `session start` | Funcionaron (11 PASS, 1 UNKNOWN esperado) |
| `Install.ps1` escribía `settings.json` con BOM (Windows PowerShell 5.1) | **Corregido** (sin BOM). **[HIPÓTESIS]** que el BOM rompiera a Claude Code; se evita igual |
| Guard con comandos de PowerShell (`Set-Content`, `Remove-Item`) | **Sigue sin cubrirse**: el guard analiza sintaxis bash (roadmap WP-V3) |

Si algo falla en Windows, ejecuta `python .csdd\tools\csdd.py doctor` y revisa que el hook de Claude Code invoque el mismo `python` que usó el instalador.

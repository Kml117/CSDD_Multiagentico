# Protocolo Comunista — desbloqueo con autorización delimitada (v0.4.0)

## Qué es y qué dejó de ser

En v0.3.0 "Comunista" era un **agente** con capacidad de ejecutar acciones excepcionales en nombre del usuario. Eso concentraba el mayor riesgo del sistema en un solo rol (OWASP Agentic ASI03, abuso de identidad y privilegios), y además dependía de un registro YAML que nada hacía cumplir.

En v0.4.0 Comunista es un **protocolo**: una autorización temporal, acotada a una tarea y a un rol, que crea el propietario y que el guard aplica de verdad. Conserva su propósito original: desbloquear burocracia y retrabajo sin derogar controles obligatorios.

## Cuándo usarlo

- Una tarea necesita tocar archivos fuera de su `allowed_paths` y partirla en otra tarea sería más caro que el riesgo.
- Hace falta una dependencia nueva que no estaba en el contrato (luego El Portero la revisa).
- Un comando legítimo cae en un falso positivo del guard.
- Un trámite local (no constitucional) se puede simplificar o reutilizar evidencia vigente.

Antes de pedirlo, Jefe Maestro debe clasificar el requisito que estorba: **MUST constitucional** (no se toca; solo ADR), **SHOULD** (excepción documentada), **procedimiento local** o **costumbre** (simplificable).

## Cómo se activa

1. El agente bloqueado envía `BLOCKER` explicando exactamente qué necesita y por qué.
2. Jefe Maestro lo recomienda en el informe al propietario, con riesgo, reversibilidad y al menos dos alternativas (p. ej. "autorización 2 h" frente a "nueva tarea T-002").
3. **El propietario, en su terminal (no un agente):**
```bash
python .csdd/tools/csdd.py approval new --task T-001 --role csdd-implementation-engineer \
  --purpose "Mover scripts de build" --paths "scripts/**" --deps esbuild \
  --commands "^npm run build:legacy$" --hours 2 \
  --risk "bajo, reversible" --rollback "git revert del merge" --review csdd-qa-verification
```
4. El guard amplía permisos **solo** para esa tarea y ese rol hasta `expires_at` (máx. `max_hours` de `system.toml`, 8 h por defecto). Cada uso queda en `events.jsonl` con el `approval_id`.
5. `csdd.py approval revoke <id>` lo corta antes de tiempo.
6. Después: revisión independiente (Cortana y/o El Portero). Quien ejecutó nunca certifica su resultado.

## Lo que nunca desbloquea (hecho cumplir en código)

- Rutas protegidas: `constitution.md`, `AGENTS.md`, `CLAUDE.md`, `.csdd/`, `.claude/`, `.agents/`, `.kimi-code/`, `.github/workflows/`, aprobaciones.
- Secretos (`.env`, `*.pem`, claves).
- Comandos prohibidos globales (force push, `reset --hard`, `--no-verify`, `sudo`, pipe de internet a shell…).
- Autoaprobación y merge sin RESULT PASS independiente.
- Cambiar MUST/SHOULD/MAY: eso exige enmienda con ADR ratificada.

## Requisitos de cada autorización (heredados de v0.3.0)

Objetivo, archivos/recursos, comandos o clases de acción permitidos, límites, duración/ventana, riesgos, exclusiones, recuperación y verificaciones posteriores. La aprobación de una acción no concede acceso general a credenciales, producción, datos personales ni firmas. Las firmas personales requieren autorización específica y mecanismo legítimo de firma; producción, destrucción de datos, migraciones irreversibles, gastos y compromisos externos requieren aprobación específica adicional, fuera de este protocolo.

## Límite honesto

Las autorizaciones viven en `.project/state/approvals/` (no versionado). Un agente no puede escribir ahí por herramientas ni por shell (el guard lo bloquea), pero el sistema no firma criptográficamente las autorizaciones: la protección asume que el propietario es quien opera su terminal.

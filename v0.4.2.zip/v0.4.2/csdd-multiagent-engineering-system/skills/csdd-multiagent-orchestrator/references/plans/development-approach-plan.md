# Plan de enfoque de desarrollo

> Plan de referencia del sistema CSDD Multi-Agent v0.4.0 (actualizado desde v0.3.0 sin recortar contenido vigente).


## Distinción esencial

El ciclo de vida del proyecto es la serie de fases desde inicio hasta cierre. El enfoque de desarrollo es el método para crear y evolucionar el producto/servicio/resultado durante ese ciclo. La cadencia es el ritmo de entregas. Se eligen de forma relacionada pero separada.

## Enfoques

### Predictivo

Útil cuando los requisitos pueden definirse, recopilarse y analizarse al comienzo y son relativamente estables. También puede convenir cuando inversión, regulación o riesgos exigen controles y revisiones planificadas. Se conoce como waterfall en muchos contextos. Planificación anticipada, cambios controlados y entregas mayormente planificadas.

### Adaptativo

Útil con alta incertidumbre, requisitos cambiantes y necesidad de feedback frecuente. Se trabaja con ciclos cortos, backlog priorizado, inspección y adaptación. Agile es un conjunto de valores/principios/prácticas; no una única metodología. El equipo aprende y adapta el producto.

### Híbrido

Combina elementos predictivos y adaptativos. Útil cuando hay componentes estables y otros inciertos, requisitos con riesgo, entregables modulares o equipos distintos. Puede aplicarse por fase, componente, tipo de entregable o equipo.

## Características iterativas e incrementales

- **Iterativo:** repetir ciclos para aprender, explorar alternativas y refinar el resultado.
- **Incremental:** agregar capacidades/valor mediante entregas parciales sucesivas.
- Pueden combinarse; no son equivalentes.
- Adaptativo suele usar iteraciones e incrementos, pero la etiqueta por sí sola no define el método concreto.

## Ciclo de vida del proyecto

El proyecto puede tener fases secuenciales, solapadas o repetidas. Una referencia posible es: inicio/viabilidad, descubrimiento, planificación/diseño, construcción, verificación, despliegue/transición y cierre. No es una plantilla obligatoria: fusionar, dividir, repetir o solapar según entregables, riesgos, cadena de entrega, estado del producto y gobernanza.

## Selección

Evaluar:
- claridad/estabilidad de requisitos;
- incertidumbre técnica y de negocio;
- criticidad, regulación y seguridad;
- modularidad y posibilidad de entregas parciales;
- dependencias entre componentes/equipos;
- velocidad de feedback y disponibilidad de usuarios;
- estado inicial (greenfield, retrofit, brownfield);
- capacidad del equipo y madurez organizacional;
- coste de cambio y consecuencias de fallo.

Registrar la decisión y sus razones en `lifecycle-profile.yaml`. Puede elegirse enfoque distinto por entregable y revisarse si cambian las condiciones.

## Niveles de ceremonia (v0.4.0)

Independiente del enfoque, cada cambio declara cuánta documentación exige, para no caer en sobrecarga documental:

- **Trivial:** commit con REQ/Art. si aplica + pruebas en verde. Ej.: corregir un typo, ajustar un texto.
- **Normal:** spec delta (ADDED / MODIFIED / REMOVED) con REQ-IDs + contrato de tarea + RESULT de Cortana.
- **Arquitectónico:** spec EARS completa + ADR + modelo de amenazas + RESULT de Cortana y El Portero + aprobación del propietario.

Un cambio que toca un MUST nunca es trivial. El nivel se registra en `lifecycle-profile.yaml` (`ceremony_levels`) y en cada contrato de tarea.

## Ruta crítica según el enfoque (v0.4.1)

El ciclo de vida y el enfoque se eligen **antes** de calcular la ruta crítica, porque determinan su forma: CPM completo con línea base (predictivo), por iteración o incremento, **rodante** con horizonte de 4–6 semanas (adaptativo) o híbrida (lo estable con línea base, lo incierto rodante; los relojes de calendario mandan el orden). Mantenimiento en flujo continuo no usa ruta de proyecto, salvo para releases con fecha. Detalle y tabla completa: `references/ruta-critica.md`. Registra `horizonte_semanas` y el modo en `.project/ruta-critica.toml`.

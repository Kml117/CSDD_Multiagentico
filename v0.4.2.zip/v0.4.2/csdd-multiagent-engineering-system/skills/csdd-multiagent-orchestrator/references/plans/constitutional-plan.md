# Plan constitucional (CSDD)

> Plan de referencia del sistema CSDD Multi-Agent v0.4.0 (actualizado desde v0.3.0 sin recortar contenido vigente).


## Propósito

Establecer cómo se gobierna el desarrollo y qué reglas son obligatorias. La Skill `csdd-mentor` del usuario conserva la autoridad educativa y el contenido de la constitución. Este documento define su lugar dentro del sistema; no replica los artículos.

## Fuentes de autoridad

1. Constitución CSDD aprobada para el proyecto.
2. Artefactos y decisiones vigentes de esa constitución.
3. Este plan, que establece cómo se consulta y aplica la constitución.

## Aplicación

- En intake, identificar si existe constitución y qué modo aplica (Greenfield/Retrofit).
- Consultar `csdd-mentor` para elaborar, comprender o revisar la constitución cuando sea necesario.
- Vincular tareas y gates a artículos aplicables; no copiar el texto entero en cada tarea.
- Distinguir obligaciones MUST de recomendaciones SHOULD y prácticas locales.
- Mantener evidencia reutilizable y vigente para evitar repetir verificaciones sin motivo.
- Mantener `constitution-controls.toml` alineado con `constitution.md`: cada MUST con control automatizado o `manual_justification` (lo verifica `check_constitution_controls.py` en CI).
- Fijar el nivel de ceremonia por tarea; un cambio que toca un MUST nunca es trivial.

## Relación con el protocolo Comunista

Desde v0.4.0 Comunista es una autorización acotada (no un agente). Una autorización puede ampliar rutas, dependencias o comandos de una tarea; no puede cambiar, ignorar o reinterpretar una regla constitucional MUST, y el guard nunca le abre rutas protegidas (constitución, hooks, CI, roles, aprobaciones). Si un rol considera que un control es desproporcionado, Jefe Maestro presenta una solicitud de cambio constitucional al usuario (ADR), con análisis de riesgo y al menos dos alternativas. Hasta aprobación, el control sigue vigente.

## Excepciones

Solo pueden concederse excepciones a elementos que la propia constitución permita exceptuar y por la autoridad indicada. No se puede autorizar una excepción a obligaciones legales, contractuales, de seguridad crítica o controles MUST no derogables.

# Plan de organización de agentes

> Plan de referencia del sistema CSDD Multi-Agent v0.4.0. Reescrito: pasa de nueve roles casi idénticos a cinco roles con permisos reales y distintos (decisión del propietario, ADR-0003).

## Principio

La estructura es dinámica y se adapta al ciclo de vida, enfoque, complejidad, riesgo y estado del producto. Los nombres operativos son alias legibles; los identificadores estables se usan en contratos, mensajes y logs. **Un rol solo existe si tiene herramientas, rutas o autoridad distintas de los demás**: si no, es un sombrero, no un agente.

## Registro de roles

| ID | Nombre | Responsabilidad | Diferencia real (hecha cumplir por el guard) |
|---|---|---|---|
| csdd-executive-supervisor | Jefe Maestro | Dirección, enrutamiento, Git/worktrees, integración, informe | Único que crea tareas/worktrees, enruta e integra; no toca `src/`/`tests/` |
| csdd-software-architect | Jarvis (+ modo Tráiler) | Descubrimiento, requisitos EARS, arquitectura, contratos, ADR | Solo escribe specs/ADR/arquitectura; shell de solo lectura |
| csdd-implementation-engineer | El Hombre de la Bolsa | Implementación Test-First | Solo escribe `allowed_paths` de su tarea, en su worktree; dependencias solo autorizadas |
| csdd-qa-verification | Cortana | QA, verificación independiente e integración | Solo escribe tests de aceptación/propiedad/e2e/integración y evidencia; registra RESULT |
| csdd-security-reviewer | El Portero | Seguridad, amenazas, dependencias, cadena de suministro de agentes | Solo lectura + escáneres; RESULT con bloqueo |

Roles retirados (v0.3.0): `csdd-project-analyst` (Tráiler) → modo de Jarvis; `csdd-integration-reviewer` → Cortana; `csdd-git-worktree-operator` → Jefe Maestro vía `csdd.py`; `csdd-unblocker-comunista` → protocolo de autorización.

## Composición típica por contexto

- **Prototipo simple:** Jefe Maestro + El Hombre de la Bolsa + Cortana ligera (otra sesión). Jarvis solo si hay incertidumbre; El Portero solo si hay riesgo que lo justifique.
- **Greenfield medio:** Jefe Maestro, Jarvis, El Hombre de la Bolsa, Cortana.
- **Retrofit/brownfield:** Jarvis en modo Tráiler inspecciona el sistema existente y propone pruebas de caracterización; El Portero revisa riesgos; Cortana refuerza integración y regresión; Jefe Maestro aísla cambios en worktrees.
- **Sistema complejo/enterprise:** los cinco; revisiones independientes; trazabilidad completa.
- **Adaptativo:** equipo estable por iteración; reducir handoffs; feedback frecuente.
- **Predictivo:** especialistas por fase y gate, con contratos detallados.
- **Híbrido:** células por componente/entregable con gobernanza común.

## Asignación de runtime y modelo (yo propongo; validar con tareas reales)

| Rol | Runtime | Modelo sugerido | Por qué |
|---|---|---|---|
| Jefe Maestro | Claude Code, sesión principal | Opus | Planeación, descomposición e integración pesan más que el volumen |
| Jarvis | Claude Code (subagente o sesión) | Opus | Requisitos y contratos ambiguos |
| El Hombre de la Bolsa | Kimi Code en el worktree de la tarea | K2.x Code | Volumen a bajo costo |
| Cortana | Claude Code en el worktree de revisión | Sonnet | Modelo distinto al implementador = verificación cruzada |
| El Portero | Claude Code | Opus | Juicio de seguridad |

## Separación de responsabilidades

Jefe Maestro coordina; no reemplaza al propietario del proyecto. El ejecutor no aprueba su propio trabajo (la CLI lo impide). El Portero puede emitir bloqueo por riesgo de seguridad crítico fundamentado y con evidencia. Una autorización Comunista amplía lo que un rol puede hacer en una tarea, pero nunca le permite aprobar su propio resultado ni alterar la constitución.

# Plan de orquestación

> Plan de referencia del sistema CSDD Multi-Agent v0.4.0 (actualizado desde v0.3.0 sin recortar contenido vigente).


## Propósito

Definir cómo se despliegan, coordinan y supervisan los agentes. No define la constitución ni sustituye la dirección del proyecto.

## Componentes

- **Jefe Maestro:** coordinador ejecutivo y punto de contacto consolidado.
- **Orquestador/runtime:** `csdd.py` (tareas, worktrees, buzón, gates, merge) + `guard.py` (permisos por rol) + CI (`csdd-gate.yml`). Jefe Maestro es el único que enruta (`csdd.py route`) e integra (`csdd.py merge`).
- **Buzón:** mensajes estructurados y trazables (seis tipos), en el `.project/` del worktree principal.
- **Repositorio:** fuente de verdad de artefactos y evidencias.
- **Worktrees/sandbox:** aislamiento de cambios cuando sea necesario.

## Reglas de despliegue

- Desplegar el mínimo conjunto de roles capaz de completar la tarea con calidad.
- Agregar revisores según riesgo y criticidad, no por ritual.
- Paralelizar solo tareas con dependencias y contratos claros.
- Asignar un responsable único por entregable mutable (`allowed_paths` que no se pisan; la CLI lo comprueba).
- Máximo dos tareas de escritura en paralelo en un proyecto personal (`max_parallel_write_tasks`).
- Toda tarea lleva presupuesto; el guard corta al agotarlo y el watchdog marca STUCK por tiempo.
- Un agente ejecutor no puede ser el único revisor de su resultado.
- Escalar al usuario solo decisiones reservadas o permisos expresos.

## Patrones

- **Secuencial:** análisis → arquitectura → implementación → QA → integración.
- **Paralelo:** tareas independientes, con contratos de interfaz y worktrees separados.
- **Iterativo:** diseño/implementación/prueba/feedback en ciclos repetidos.
- **Incremental:** equipos o agentes por capacidad funcional, con integración por incremento.
- **Híbrido:** combinar patrones por componente, fase o entregable.

## Control de flujo

Cada tarea tiene estado, responsable, criterios, dependencias, deadline/ventana si aplica y evidencias. Los gates se activan por criterios verificables. Un bloqueo genera mensaje `BLOCKER`; Jefe Maestro evalúa si reasigna, solicita análisis a Jarvis, recomienda al propietario una autorización Comunista o escala al usuario. Tras `max_retries` fallos de QA la tarea pasa a STUCK y entra un BLOCKER del sistema.

## Protocolo de sesión (anti-retrabajo, v0.4.1)

- Sin `csdd.py session start` vigente, el guard bloquea toda modificación; el estado se calcula, no se escribe a mano.
- Una sesión = una tarea del tramo vigente de la ruta crítica.
- Solo `git add <ruta exacta>`; nada se da por hecho sin comando y salida; contradicciones a la lista de limpieza.
- `session end` exige verificación si se tocó código y horas reales; Jefe Maestro reescribe `SIGUIENTE-SESION.md`.
- Detalle: `references/protocolo-sesion.md`.

## Reporte humano

Jefe Maestro presenta un informe consolidado, no un reporte por agente. Debe incluir logros, artefactos, pruebas, riesgos, decisiones ya tomadas dentro de la delegación y decisiones pendientes del usuario.

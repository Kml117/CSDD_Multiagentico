# Plan de dirección del proyecto (PMBOK-tailored)

> Plan de referencia del sistema CSDD Multi-Agent v0.4.0 (actualizado desde v0.3.0 sin recortar contenido vigente).


## Propósito

Definir cómo se inicia, planifica, ejecuta, monitorea, controla y cierra el proyecto. Es transversal al ciclo de vida y se adapta al tamaño, riesgo y contexto. Está inspirado en PMI/PMBOK; no pretende copiar ni certificar el estándar.

## 1. Acta / mandato del proyecto

Registrar problema, propósito, objetivos medibles, patrocinador/propietario, usuarios, beneficios esperados, límites, restricciones y criterios de éxito. El usuario es propietario y autoridad final.

## 2. Tailoring inicial

Jefe Maestro, apoyado por Jarvis en modo Tráiler (descubrimiento), propone:
- complejidad y criticidad;
- estado: greenfield, retrofit/brownfield, mantenimiento/evolución;
- ciclo de vida del proyecto;
- enfoque de desarrollo por entregable/componente;
- cadencia de entrega;
- fases, hitos, gates y entregables;
- agentes (de los cinco roles), modo de despliegue A/B y nivel de control;
- nivel de ceremonia por defecto (trivial / normal / arquitectónico);
- artefactos mínimos necesarios.

El usuario aprueba decisiones estratégicas y las reservas definidas en la matriz de autoridad. Los ajustes operativos de bajo riesgo quedan delegados.

## 3. Planes subsidiarios

Este plan referencia, no absorbe:
- Plan constitucional CSDD.
- Plan de enfoque de desarrollo.
- Plan de orquestación.
- Plan organizacional de agentes.
- Plan de calidad/verificación cuando el riesgo lo requiera.
- Plan de seguridad y datos cuando corresponda.

## 4. Áreas de dirección

- **Alcance:** objetivos, entregables, exclusiones y control de cambios.
- **Cronograma:** fases, iteraciones/incrementos, dependencias, hitos y **ruta crítica adaptada al ciclo de vida y al enfoque** (`references/ruta-critica.md`): recurso limitante (horas del propietario), relojes de calendario arrancados temprano, tramos con bloque de deuda y semáforo de hitos. `csdd.py ruta` calcula; el propietario aprueba `docs/RUTA-CRITICA.md`.
- **Costos/recursos:** presupuesto, límites de cómputo, herramientas y capacidad de agentes. Cada tarea lleva presupuesto (`max_tool_calls`, `max_minutes`, `max_retries`); el consumo real sale de `.project/log/events.jsonl` y se reporta en el informe ejecutivo.
- **Calidad:** criterios de aceptación, estrategia de pruebas y gates.
- **Recursos/equipo:** roles humanos y agentes activados dinámicamente.
- **Comunicaciones:** buzón enrutado por Jefe Maestro, reportes, interesados, cadencia y escalación.
- **Riesgos:** registro, propietario, probabilidad/impacto, respuesta y riesgo residual.
- **Adquisiciones/dependencias:** APIs, servicios externos, licencias y proveedores.
- **Interesados:** usuarios, propietario, responsables de aceptación y afectados. Las **entradas del propietario** se piden en una sola tanda con fecha límite antes del tramo que las necesita.
- **Cambios:** solicitud, análisis de impacto, autoridad de aprobación y actualización de baselines.

## 5. Seguimiento y control

Cada sesión empieza con `csdd.py session start` (estado calculado) y termina con `session end` (bitácora con horas reales): son el insumo del control. Jefe Maestro consolida progreso contra entregables y resultados, no cantidad de mensajes ni documentos. Actualiza riesgos, dependencias, cambios, costos y pronóstico. En proyectos adaptativos usa backlog, flujo, objetivos de iteración e incrementos; en predictivos usa hitos y baselines; en híbridos usa ambos donde correspondan.

## 6. Gates y aceptación

Cada fase/iteración/incremento define entrada, salida, entregables, evidencia, responsable y autoridad de aceptación. La revisión técnica puede delegarse; la aceptación final del producto y decisiones reservadas corresponden al usuario.

## 7. Cierre

Confirmar aceptación, transición/operación, documentación mínima útil, deuda técnica, riesgos residuales, lecciones aprendidas, cierre de ramas/entornos y archivo de artefactos.

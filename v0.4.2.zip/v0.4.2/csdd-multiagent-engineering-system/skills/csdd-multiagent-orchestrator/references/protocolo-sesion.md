# Protocolo de sesión anti-retrabajo (v0.4.1)

> Origen: `PROTOCOLO-SESION.md` + `scripts/estado.sh` de Corbeta (aprobados por Camilo el 2-nov-2026).
> **Por qué existe:** en los primeros días de Corbeta se perdió mucho tiempo reconstruyendo el estado del proyecto a partir de documentos que se contradecían, con errores reales: una migración dada por aplicada sin estarlo, un RATIFY hecho por un agente y estados de ADR equivocados. Con pocas horas por semana, cada hora de reconciliación es una hora que no se construye. El protocolo reemplaza esa reconstrucción por **un comando y una plantilla corta**.

## 1. Estatus en la constitución

Es un **MUST operativo** del sistema, hecho cumplir en código, y un **control del Artículo IX** (Verificación reproducible) en `constitution-controls.toml`: `session-protocol` y `no-blind-add`. No es un artículo nuevo: elevarlo a artículo propio es una decisión del propietario (ADR-0004, opción B).

## 2. Al empezar (sin excepciones)

```bash
git fetch origin
python .csdd/tools/csdd.py session start --tarea T-001 --tramo T2
```
1. La salida **es la fuente del estado del repo**: rama, cambios sin commitear, commits de `origin/main` con firma, PR abiertos y CI (si hay `gh`), tareas y worktrees CSDD, migraciones en la rama, archivos sensibles rastreados, documentos con señales de desfase, bitácora (último bloque, horas, tope de líneas), semáforo de la ruta crítica y "qué sigue". **No se copia a ningún documento.**
2. Declara la tarea y, si es de la ruta crítica, el tramo.
3. **ALERTA** (archivos privados o secretos en git) → la sesión **no se abre**; solo el propietario puede abrirla con `--acepto-alertas` (el guard se lo impide a cualquier agente). Cambios sin commitear que no son tuyos → **detente y pregunta**.
4. Sin sesión vigente (12 h por defecto) el guard bloquea toda escritura y todo comando que modifique; leer sí está permitido.

## 3. Una fuente de verdad por tema

| Tema | Dónde vive | Quién lo escribe |
|---|---|---|
| Estado del repo (ramas, PR, CI, migraciones del repo) | `csdd.py estado` | Nadie: se calcula |
| Si una migración está aplicada en la base | La base misma (consulta o conector) | Nadie lo afirma sin comprobarlo |
| Orden, tramos y fechas | `docs/RUTA-CRITICA.md` + `csdd.py ruta` | Jefe Maestro/Aurora calcula; propietario aprueba |
| Qué sigue | `docs/SIGUIENTE-SESION.md` (se **reescribe**; máx. una página) | Jefe Maestro al cerrar |
| Historia de lo hecho | `docs/BITACORA.md` (un bloque ≤ 10 líneas por sesión) | `csdd.py session end` |
| Reglas | `constitution.md` | Solo el propietario, con enmienda |
| Requisitos | specs / SRS / PRD | Cambios por PR |
| Estado de las tareas | `csdd.py` (agentes) y tu herramienta de seguimiento (Notion) | Según el proyecto |

**No se crean documentos nuevos** sin que el propietario lo pida. Si algo no cabe en esta tabla, se pregunta dónde va.

## 4. Reglas contra el retrabajo

1. **Nada se da por hecho sin comando y salida.** Tampoco lo que diga otro agente o un documento: "ya se aplicó", "ya se fusionó" se comprueba antes de seguir (Regla 6 de csdd-mentor).
2. **Un agente por árbol de trabajo**; el segundo usa un worktree (`csdd.py worktree new`). **Nunca `git add -A` ni `git add .`**: solo rutas exactas (el guard lo bloquea, junto con `git commit -a`).
3. **Lo congelado está congelado** (prototipos, versiones viejas): solo se arregla lo que impida su uso; lo nuevo nace en el producto nuevo. Decláralo en el Project Profile.
4. **Las contradicciones entre documentos no se arreglan sobre la marcha:** se anotan en una línea (`archivo:línea`) en la lista de limpieza de `SIGUIENTE-SESION.md` y se corrigen todas juntas en el PR de limpieza del gate (bloque de deuda).
5. **Las horas se registran siempre.** "Sin medir" no es respuesta: `session end` no cierra sin `--horas`; si el agente no las sabe, se las pregunta al propietario.

## 5. Al terminar (en este orden)

```bash
python .csdd/tools/csdd.py session end --resultado completado --horas 1.5 --tarea T-001 \
  --verificado "uv run pytest -q -> 42 passed" --no-verificado "migración en dev" --pide "nada"
```
1. Si tocaste código: se ejecuta `verify_command` (si está configurado); si falla, la sesión queda **parcial** automáticamente. Sin `verify_command`, debes declarar `--verificado` con comando y salida.
2. Se recalcula el estado (alertas).
3. Se añade **un** bloque a la bitácora (máx. 10 líneas): fecha · tarea · quién; resultado; PR y commits (automáticos desde el inicio de la sesión); verificado; no verificado; horas y acumulado; seguimiento; qué se pide al propietario.
4. Jefe Maestro **reescribe** "Qué sigue, en orden" en `SIGUIENTE-SESION.md` (sin historia).
5. Contradicciones encontradas → lista de limpieza.
6. Mensaje final al propietario: qué quedó hecho, qué falta, qué necesita. Cinco líneas como máximo.

## 6. Cómo se aplica a cada quien
- **Claude Code:** `CLAUDE.md` lo indica; el guard lo hace cumplir.
- **Kimi Code u otro agente:** `AGENTS.md` lo incluye; los agentes generados (`.claude/agents`, `.agents/agents`) llevan el bloque `templates/protocolo-sesion-core.md`. Si el agente no lee AGENTS.md, el prompt empieza con: "Lee AGENTS.md y aplica el Protocolo de sesión al empezar y al terminar."
- **Aurora (claude.ai):** no ve el repo. Aplica §3 y §4 con lo que el propietario pega; al recibir la bitácora actualiza el seguimiento y recalcula la ruta en cada gate.
- **El propietario:** respaldo de lo que no está en git (datos privados) con la cadencia que defina el proyecto; un respaldo que nunca se ha abierto no es un respaldo.

## 7. Configuración (`.csdd/config/system.toml`, sección `[session]`)
`required`, `ttl_hours`, `base_branch`, `bitacora_file`, `siguiente_file`, `bitacora_max_lines`, `hours_since`, `verify_command`, `code_globs`, `private_paths`/`private_allow`, `migrations_globs`, `stale_doc_globs`, `stale_signals`. Ejemplo para Corbeta en `ruta-critica.md` §5. Cambiarla es un cambio protegido: lo hace el propietario.

## 8. Límites honestos
- El gate de sesión depende del hook: en Kimi (fail-open) un hook mal configurado lo deja pasar; CI no puede verificar sesiones. Es disciplina asistida, no criptografía.
- `estado` usa `gh` para PR y CI; sin `gh` lo marca NO VERIFICADO.
- La detección de documentos desfasados es por patrones que tú defines; da falsos positivos (citas históricas).

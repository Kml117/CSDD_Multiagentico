# Ruta crítica adaptable (v0.4.1)

> Origen: práctica aplicada en Corbeta (RUTA-CRITICA.md v1.1, 1-2 nov 2026), generalizada para cualquier proyecto.
> Estatus: **VALIDADO en Corbeta** (una muestra: la calculadora reproduce sus cifras, ver `tests/test_system.py::test_12`) ·
> la adaptación por ciclo de vida es **PROPUESTA** basada en PMI (Spectrum of Approaches, Tailoring) y en Critical Chain;
> úsala y ajústala con datos reales.

## 1. La idea en tres líneas

1. **El recurso que limita casi nunca es el cómputo: son las horas del propietario** (en Corbeta, 7 h/semana). Reordenar tareas **no acorta el trabajo**: horas pendientes ÷ horas por semana = semanas.
2. **Lo que sí hace perder semanas son las esperas de calendario** que no consumen horas: periodos de uso real, revisiones externas, aprobaciones, ventanas regulatorias. Si quedan al final del plan, **se suman al final**. En Corbeta, dejar el reloj de "2 meses de uso real" al final costaba ~8,5 semanas.
3. Por eso la ruta crítica no se ejecuta "en orden de fase": **primero lo que dispara un reloj**, y el resto en **tramos**, cada uno cerrado con un **bloque corto de deuda**.

## 2. Orden correcto: ciclo de vida → enfoque → ruta

La ruta crítica **se deriva** de dos decisiones previas, registradas en `lifecycle-profile.yaml`:

1. **Ciclo de vida del proyecto** (fases desde inicio hasta cierre): predictivo, iterativo, incremental, adaptativo o híbrido.
2. **Enfoque de desarrollo** (cómo se crea el producto): predictivo, adaptativo o híbrido; por entregable si hace falta.
3. **Ruta crítica**: su forma depende de 1 y 2. Se adapta poco a poco y se recalcula en cada gate.

| Ciclo / enfoque | Forma de la ruta | Detalle | Recálculo | Lo crítico de verdad |
|---|---|---|---|---|
| **Predictivo** | CPM completo con línea base (`horizonte_semanas = 0`) | Todas las tareas estimadas (PERT si hay incertidumbre) | Gate de fase + desvío > 50 % | Cadena más larga + hitos contractuales/regulatorios |
| **Iterativo** | Ruta por iteración | Solo la iteración en curso; el resto en bloques estimados | Fin de cada iteración | Lo que se aprende en cada vuelta (riesgo técnico) |
| **Incremental** | Ruta por incremento entregable | Incremento actual detallado; los siguientes como bloques | Cierre de cada incremento | Dependencias entre incrementos y su integración |
| **Adaptativo** | **Ruta rodante** (`horizonte_semanas = 4–6`) | Detalle solo dentro del horizonte; fuera, backlog priorizado con horas gruesas | Cada iteración/sprint | **Relojes y dependencias externas**; el orden del backlog lo da el valor |
| **Híbrido** (caso Corbeta) | CPM con línea base para lo estable + rodante para lo incierto | Núcleo estable estimado; módulos inciertos en bloques | Gate + desvío | Relojes: mandan el orden |
| Mantenimiento / flujo | Sin ruta crítica de proyecto | Kanban: límites de trabajo en curso y tiempo de ciclo | Continuo | Solo para releases planificados |

| Estado del producto | Ajuste |
|---|---|
| Greenfield | La ruta empieza en arquitectura y constitución; los relojes se identifican desde el día 1. |
| Retrofit / brownfield | Añade un tramo inicial de **pruebas de caracterización** y descubrimiento (Jarvis, modo Tráiler); estimaciones más anchas (PERT con `p` alto). |
| Mantenimiento | Normalmente flujo; ruta solo para cambios grandes con fecha. |

**Con un solo recurso humano** la ruta real es la de **recurso limitado** (cadena crítica), no la de dependencias puras. Por eso la calculadora da dos fechas: la cota inferior (solo dependencias, "si tuviera más horas") y la fecha real con tus horas.

## 3. Reglas que la hacen funcionar

1. **Relojes primero.** Identifica toda espera de calendario y adelanta la cadena que la dispara. El "último día para empezar" la cadena de un hito es una fecha dura.
2. **Tramos con bloque de deuda.** Cada tramo cierra con un bloque corto. **Tope: 1 h por ítem y 2 ítems por bloque.** Lo que no cabe se agenda como tarea con estimación propia. El PR de limpieza de documentos vive aquí (uno por gate).
3. **Entradas del propietario en una sola tanda, con fecha límite**, antes del tramo que las necesita. Una sesión de agente esperando un dato del propietario es la forma más barata de perder una semana.
4. **Una sesión = una tarea del tramo vigente** (+ su parte del bloque de deuda). Al empezar se declara el tramo (`session start --tramo`).
5. **No se adelantan tareas de tramos posteriores**, salvo que la siguiente esté bloqueada y el propietario lo autorice por escrito.
6. **Horas reales siempre** en la bitácora. Sin horas no hay recálculo honesto.
7. **Recálculo:** tras cada gate con horas reales, y **en el momento** si una tarea supera su estimación en > 50 % (`umbral_desvio`). Una sola muestra no basta para re-estimar todo: espera 2-3 tramos.
8. **Semáforo del hito** (lo calcula `csdd.py estado`): verde ≤ umbral amarillo; amarillo hasta el rojo (sube la cadena del hito de prioridad); rojo (> horas disponibles sin el hito: la fecha final se mueve, recalcula). Por defecto, rojo = horas disponibles hasta la fecha límite; amarillo = rojo − horas del tramo del hito (en Corbeta: 70 y 54 h).
9. **Separación de fuentes:** el orden y las decisiones viven en `RUTA-CRITICA.md`; las fechas, en el cálculo automático; el estado del repo, en `csdd.py estado`; el estado de tareas, en tu herramienta de seguimiento (Notion en Corbeta).

## 4. Cómo se hace con el sistema

1. Jefe Maestro (o Aurora en chat) arma `.project/ruta-critica.toml` desde `.csdd/templates/ruta-critica.toml`: tareas en el orden propuesto, horas (o PERT o/m/p), predecesoras, tramos, relojes e hitos con fecha límite.
2. `python .csdd/tools/csdd.py ruta` → informe: fin con tus horas, cota inferior, ruta crítica, esperas por relojes, tramos, hitos (holgura, horas disponibles, umbrales, probabilidad PERT), desvíos y horizonte.
3. Compara órdenes alternativos duplicando el TOML y cambiando el orden (así se decidió en Corbeta: ~2 meses ganados).
4. Escribe `docs/RUTA-CRITICA.md` (plantilla `.csdd/templates/RUTA-CRITICA.md`) con las decisiones y supuestos; el propietario aprueba.
5. Cada sesión: `session start` muestra el semáforo y avisa de desvíos. Cada gate: actualiza `estado`/`horas_reales`/`restante` y recalcula (`csdd.py ruta --out docs/ruta-critica-calculo.md`).
6. En claude.ai: la skill puede hacer el cálculo con el script de `assets/system/tools/ruta_critica.py` sobre el TOML que el usuario pegue o suba.

**Coordinación con otras skills:** para WBS, EVM, charter o cronogramas formales de PMBOK, usa también `gestion-proyectos-aplicada` si está instalada; esta referencia se centra en la adaptación al ciclo de vida, los relojes y el recurso limitado.

## 5. Ejemplo de configuración para Corbeta

```toml
# .csdd/config/system.toml  (cambio protegido: lo hace Camilo)
[session]
bitacora_file = "notion-sincronizacion.md"
siguiente_file = "SIGUIENTE-SESION.md"
hours_since = "2026-11-02"
verify_command = "pnpm verify"
private_paths = ["datos-privados/**", "archivo/**", "**/*.csv"]
migrations_globs = ["supabase/migrations/*.sql"]
stale_signals = ["npm run", "ANON_KEY", "[Cc]andidata", "pendiente de (Verification )?[Gg]ate"]
```
Si la bitácora y SIGUIENTE-SESION viven en la raíz (como en Corbeta), añade esas dos rutas a `write_paths` del Jefe Maestro en `roles.toml`. El hito "F3 antes del 10-ene-2027" se declara en `.project/ruta-critica.toml` y el semáforo sale solo (antes: variable `F3_HECHA`).

## 6. Límites honestos
- Las dependencias salen de lo que declares; si faltan, la ruta es optimista. Revísalas en cada recálculo.
- La programación con un recurso usa el orden del archivo (list scheduling), no busca el orden óptimo: compara alternativas explícitamente.
- La probabilidad PERT supone tareas independientes y aproximación normal; es orientativa.
- No incluye buffers: añade un margen explícito (Corbeta: ≈ 1 semana por bloques de deuda + tareas sin estimar).

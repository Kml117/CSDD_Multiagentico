"""csdd_core — utilidades compartidas por guard.py, csdd.py y los verificadores.

Solo librería estándar. Requiere Python 3.11+ (tomllib).
Conceptos:
  repo_root         raíz del worktree actual (donde trabaja el agente)
  coordination_root raíz del worktree PRINCIPAL; ahí vive .project/ compartido
                    (buzón, estado, log), para que todos los worktrees lo vean.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import re
import subprocess
import sys
import tempfile
import tomllib
from functools import lru_cache
from pathlib import Path

VERSION = "0.4.2"
LEAD = "csdd-executive-supervisor"
QA = "csdd-qa-verification"
SEC = "csdd-security-reviewer"
IMPL = "csdd-implementation-engineer"
ARCH = "csdd-software-architect"
TASK_FILE = ".csdd-task"
ACTIVE_STATES = {"QUEUED", "IN_PROGRESS", "IN_REVIEW", "REWORK", "STUCK"}



def ensure_utf8_stdio() -> None:
    """Fuerza UTF-8 en stdin/stdout/stderr.

    En Windows (consola heredada) o con LANG=C, Python usa otra codificación: los mensajes con tildes
    salían rotos o lanzaban UnicodeEncodeError, y el JSON del hook se leía mal. Llamar al arrancar.
    """
    for stream, errors in ((sys.stdin, "replace"), (sys.stdout, "replace"), (sys.stderr, "replace")):
        try:
            stream.reconfigure(encoding="utf-8", errors=errors)  # type: ignore[union-attr]
        except (AttributeError, ValueError, OSError):
            pass


def decode_argv(argv: list[str]) -> list[str]:
    """Re-decodifica como UTF-8 los argumentos que Python escapó (locale C/POSIX sin UTF-8)."""
    fixed = []
    for a in argv:
        if any("\udc80" <= ch <= "\udcff" for ch in a):
            a = os.fsencode(a).decode("utf-8", errors="replace")
        fixed.append(a)
    return fixed


# ----------------------------------------------------------------- tiempo ---
def now() -> _dt.datetime:
    return _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0)


def now_iso() -> str:
    return now().isoformat()


def parse_iso(value: str) -> _dt.datetime:
    dt = _dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=_dt.timezone.utc)
    return dt


# ------------------------------------------------------------------- git ----
def _git(args: list[str], cwd: Path) -> str | None:
    try:
        out = subprocess.run(["git", *args], cwd=str(cwd), capture_output=True,
                             text=True, encoding="utf-8", errors="replace", timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    if out.returncode != 0:
        return None
    return out.stdout.strip()


def repo_root(start: Path | None = None) -> Path:
    start = Path(start or os.getcwd()).resolve()
    top = _git(["rev-parse", "--show-toplevel"], start)
    return Path(top).resolve() if top else start


def coordination_root(start: Path | None = None) -> Path:
    """Raíz del worktree principal (el que contiene el directorio .git real)."""
    start = Path(start or os.getcwd()).resolve()
    common = _git(["rev-parse", "--path-format=absolute", "--git-common-dir"], start)
    if not common:
        common = _git(["rev-parse", "--git-common-dir"], start)
        if common:
            common = str((start / common).resolve())
    if not common:
        return repo_root(start)
    p = Path(common).resolve()
    return p.parent if p.name == ".git" else p.parent


# ------------------------------------------------------------------ globs ---
@lru_cache(maxsize=512)
def glob_to_re(pattern: str) -> re.Pattern:
    p = pattern.replace("\\", "/").removeprefix("./")
    i, out = 0, ""
    while i < len(p):
        if p.startswith("**/", i):
            out += "(?:.*/)?"
            i += 3
        elif p.startswith("**", i):
            out += ".*"
            i += 2
        elif p[i] == "*":
            out += "[^/]*"
            i += 1
        elif p[i] == "?":
            out += "[^/]"
            i += 1
        else:
            out += re.escape(p[i])
            i += 1
    return re.compile("^" + out + "$")


def match_any(rel_path: str, patterns: list[str] | tuple[str, ...]) -> bool:
    rel = rel_path.replace("\\", "/").removeprefix("./")
    return any(glob_to_re(p).match(rel) for p in patterns)


def static_prefix(pattern: str) -> str:
    p = pattern.replace("\\", "/").removeprefix("./")
    m = re.search(r"[*?\[]", p)
    return p[: m.start()] if m else p


def globs_overlap(a: list[str], b: list[str]) -> list[tuple[str, str]]:
    """Aproximación conservadora: dos globs chocan si un prefijo estático contiene al otro."""
    hits = []
    for x in a:
        for y in b:
            px, py = static_prefix(x), static_prefix(y)
            if px.startswith(py) or py.startswith(px):
                hits.append((x, y))
    return hits


# ----------------------------------------------------------------- config ---
def config_dir(root: Path) -> Path:
    return root / ".csdd" / "config"


def load_toml(path: Path) -> dict:
    with open(path, "rb") as fh:
        return tomllib.load(fh)


def load_roles(root: Path) -> dict:
    return load_toml(config_dir(root) / "roles.toml")


def load_system(root: Path) -> dict:
    path = config_dir(root) / "system.toml"
    return load_toml(path) if path.exists() else {}


# --------------------------------------------------------- estado / tareas ---
def project_dir(coord: Path) -> Path:
    return coord / ".project"


def tasks_dir(coord: Path) -> Path:
    return project_dir(coord) / "state" / "tasks"


def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def write_json_atomic(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp-", suffix=".json")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    os.replace(tmp, path)


def load_task(coord: Path, task_id: str) -> dict | None:
    if not task_id or not re.fullmatch(r"[A-Za-z0-9._-]{1,64}", task_id):
        return None
    return read_json(tasks_dir(coord) / f"{task_id}.json")


def save_task(coord: Path, task: dict) -> None:
    task["updated_at"] = now_iso()
    write_json_atomic(tasks_dir(coord) / f"{task['task_id']}.json", task)


def all_tasks(coord: Path) -> list[dict]:
    d = tasks_dir(coord)
    if not d.exists():
        return []
    out = []
    for f in sorted(d.glob("*.json")):
        t = read_json(f)
        if isinstance(t, dict):
            out.append(t)
    return out


def worktree_task(root: Path) -> dict:
    data = read_json(root / TASK_FILE, {})
    return data if isinstance(data, dict) else {}


# --------------------------------------------------------- resolución rol ---
def resolve_role(root: Path, roles_cfg: dict, hook_payload: dict | None = None) -> tuple[str, str]:
    """Devuelve (rol, fuente). Orden: agent_type del hook > CSDD_ROLE > .csdd-task > default."""
    known = set(roles_cfg.get("roles", {}))
    legacy = roles_cfg.get("legacy", {})

    def norm(value):
        if not value:
            return None
        value = str(value).strip()
        value = legacy.get(value, value)
        return value if value in known else None

    if hook_payload:
        for key in ("agent_type", "subagent_type", "agent_name", "agent"):
            r = norm(hook_payload.get(key))
            if r:
                return r, f"hook:{key}"
    r = norm(os.environ.get("CSDD_ROLE"))
    if r:
        return r, "env:CSDD_ROLE"
    r = norm(worktree_task(root).get("role"))
    if r:
        return r, TASK_FILE
    default = roles_cfg.get("defaults", {}).get("default_role", LEAD)
    return default, "default"


# ---------------------------------------------------------------- eventos ---
_REDACT = re.compile(r"(?i)\b([A-Z0-9_]*(token|secret|password|passwd|api[_-]?key|private[_-]?key)[A-Z0-9_]*)\s*[=:]\s*\S+")


def redact(text: str, limit: int = 400) -> str:
    text = _REDACT.sub(r"\1=***", text or "")
    return text if len(text) <= limit else text[:limit] + "…"


def log_event(coord: Path, event: dict) -> None:
    """Bitácora append-only (Art. VII). Nunca debe romper al llamador."""
    try:
        path = project_dir(coord) / "log" / "events.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        event = {"ts": now_iso(), **event}
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(event, ensure_ascii=False) + "\n")
    except OSError:
        pass


# ------------------------------------------------------------ aprobaciones ---
def active_approvals(coord: Path, task_id: str | None, role: str) -> list[dict]:
    d = project_dir(coord) / "state" / "approvals"
    if not d.exists():
        return []
    out = []
    current = now()
    for f in sorted(d.glob("*.toml")):
        try:
            a = load_toml(f).get("approval", {})
        except (OSError, tomllib.TOMLDecodeError):
            continue
        if a.get("status") != "APPROVED":
            continue
        if a.get("task_id") not in (task_id, "*") or a.get("role") not in (role, "*"):
            continue
        try:
            if parse_iso(str(a.get("valid_from", "1970-01-01T00:00:00+00:00"))) > current:
                continue
            if parse_iso(str(a["expires_at"])) <= current:
                continue
        except (KeyError, ValueError):
            continue
        a["_file"] = f.name
        out.append(a)
    return out

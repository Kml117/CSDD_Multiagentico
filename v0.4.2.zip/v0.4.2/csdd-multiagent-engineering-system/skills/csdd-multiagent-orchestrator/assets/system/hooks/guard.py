#!/usr/bin/env python3
"""CSDD guard v0.4.2 — hook PreToolUse para Claude Code y Kimi Code.

Contrato del hook:  exit 0 = permitir · exit 2 = bloquear (el motivo va por stderr
y el agente lo recibe).  Fail-secure (Art. VI): si el guard falla al evaluar una
escritura o un comando de shell, bloquea.

Qué hace cumplir (fuente: .csdd/config/roles.toml):
  1. Rutas protegidas y secretos: ningún agente escribe/lee ahí.
  2. Permisos de escritura por rol (y por tarea para El Hombre de la Bolsa).
  3. Shell por clase de rol: git, instalaciones, redirecciones, borrados.
  4. CLI del buzón: subcomandos solo-líder, solo-revisor, solo-humano.
  5. Presupuesto de llamadas por tarea y detector de bucles.
  6. Autorizaciones Comunista vigentes (amplían, nunca tocan lo protegido).
Es una barrera temprana, no la única: el gate real es CI (csdd-gate.yml).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True  # no ensuciar .csdd/ (ruta protegida) con __pycache__
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parent.parent / "lib"))
import csdd_core as core  # noqa: E402
sys.path.insert(0, str(HERE.parent.parent / "tools"))
import sesion  # noqa: E402

WRITE_TOOLS = {"Edit", "Write", "MultiEdit", "NotebookEdit", "WriteFile", "StrReplaceFile",
               "ApplyPatch", "str_replace", "create_file", "write_file", "edit_file"}
READ_TOOLS = {"Read", "ReadFile", "NotebookRead", "read_file", "view"}
SHELL_TOOLS = {"Bash", "Shell", "shell", "bash", "RunCommand", "Terminal", "run_command"}
PATH_KEYS = ("file_path", "path", "notebook_path", "filepath", "file", "target", "filename")
CMD_KEYS = ("command", "cmd", "script")

HARD_DENY = [
    (r"\bgit\s+push\b[^;&|]*(--force\b|--force-with-lease\b|\s-f\b)", "force push"),
    (r"\bgit\s+reset\s+--hard\b", "git reset --hard"),
    (r"\bgit\s+clean\s+-\w*f", "git clean -f"),
    (r"\bgit\s+(-c\s+\S+\s+)*config\b[^;&|]*core\.hooksPath", "cambiar core.hooksPath"),
    (r"--no-verify\b", "--no-verify (saltarse hooks)"),
    (r"\brm\s+-\w*r\w*\s+(/|~|\$HOME|\.|\*|\./\*)(\s|$)", "borrado recursivo de raíz/home/proyecto"),
    (r"\b(curl|wget)\b[^|;&]*\|\s*(sudo\s+)?(ba|z|da)?sh\b", "pipe de internet a shell"),
    (r"\bchmod\s+(-R\s+)?0?777\b", "chmod 777"),
    (r"\bsudo\b", "sudo"),
    (r"CSDD_GUARD|CSDD_ROLE\s*=", "manipular el guard o el rol"),
    (r"(^|[;&|]\s*)(printenv|env)\s*($|[;&|])", "volcar variables de entorno"),
]
SECRET_TOKEN = re.compile(r"(^|[\s/'\"=:])(\.env(\.[\w.-]+)?(?![\w])|[\w.-]*\.pem|id_rsa\w*|id_ed25519\w*|[\w.-]*\.p12|\.secrets?/)")
SECRET_OK = re.compile(r"\.env\.(example|sample)\b")
PROTECTED_FRAGMENTS = ("constitution.md", ".csdd/", ".claude/", ".agents/", ".kimi-code/",
                       "AGENTS.md", "CLAUDE.md", ".github/workflows", "state/approvals", "roles.toml")
SHELL_WRITE_HINT = re.compile(r"(>|\btee\b|\bsed\s+-i|\bperl\s+-\w*i|\brm\b|\bmv\b|\bcp\b|\btouch\b|"
                              r"\btruncate\b|\bln\b|\bchmod\b|\bgit\s+(checkout|restore|rm|mv)\b|\bdd\b)")
GIT_SAFE = {"status", "diff", "log", "show", "blame", "grep", "ls-files", "rev-parse", "fetch",
            "describe", "shortlog", "cat-file", "ls-tree", "reflog"}
GIT_BY_CLASS = {
    "lead": None,  # todo salvo lo de abajo
    "implementer": {"add", "commit", "stash", "restore", "rm", "mv", "revert"},
    "reviewer_commit": {"add", "commit", "stash"},
    "reviewer": set(),
    "readonly": set(),
}
CLI_LEAD_ONLY = {"route", "merge", "worktree"}
CLI_TASK_LEAD_ONLY = {"new", "set-status", "cancel"}
CLI_HUMAN_ONLY = {"approval"}
READ_ONLY_CMDS = {"ls", "cat", "head", "tail", "pwd", "echo", "wc", "rg", "grep", "find", "tree", "which", "date",
                  "whoami", "printf"}
CLI_NO_SESSION_OK = {"session", "estado", "status", "doctor", "inbox", "ruta"}
INSTALL_RE = re.compile(
    r"^(?:(npm|pnpm|yarn|bun)\s+(i|install|add)\b|(pip3?|python3?\s+-m\s+pip|uv\s+pip)\s+install\b|"
    r"(uv|poetry|pdm)\s+add\b)(.*)$")


class Block(Exception):
    pass


# -------------------------------------------------------------- utilidades ---
def first(d: dict, keys) -> str | None:
    for k in keys:
        v = d.get(k)
        if isinstance(v, str) and v.strip():
            return v
    return None


def tool_class(name: str) -> str:
    if name in WRITE_TOOLS:
        return "write"
    if name in READ_TOOLS:
        return "read"
    if name in SHELL_TOOLS:
        return "shell"
    return "other"


def rel_to(root: Path, raw: str, cwd: Path) -> tuple[str | None, Path]:
    p = Path(raw)
    if not p.is_absolute():
        p = cwd / p
    p = Path(os.path.normpath(str(p)))
    try:
        return p.resolve().relative_to(root).as_posix(), p
    except ValueError:
        try:
            return p.relative_to(root).as_posix(), p
        except ValueError:
            return None, p


def in_temp(p: Path) -> bool:
    tmp = Path(tempfile.gettempdir()).resolve()
    try:
        p.resolve().relative_to(tmp)
        return True
    except ValueError:
        return str(p).startswith(("/tmp/", "/dev/null"))


class Ctx:
    def __init__(self, payload: dict):
        self.payload = payload
        self.cwd = Path(payload.get("cwd") or os.getcwd()).resolve()
        self.root = core.repo_root(self.cwd)
        self.coord = core.coordination_root(self.root)
        self.cfg = core.load_roles(self.root)
        self.defaults = self.cfg.get("defaults", {})
        self.role, self.role_source = core.resolve_role(self.root, self.cfg, payload)
        self.rcfg = self.cfg["roles"][self.role]
        wt = core.worktree_task(self.root)
        self.task_id = wt.get("task_id")
        self.task = core.load_task(self.coord, self.task_id) if self.task_id else None
        self.approvals = core.active_approvals(self.coord, self.task_id, self.role)

    # ------------------------------------------------------------ rutas ----
    def writable_patterns(self) -> list[str]:
        pats = list(self.rcfg.get("write_paths", []))
        if self.rcfg.get("write_paths_from_task"):
            if not self.task:
                raise Block(f"{self.rcfg['alias']} necesita una tarea activa: abre su worktree "
                            "(csdd.py worktree new <TAREA>) y trabaja ahí.")
            pats += list(self.task.get("allowed_paths", []))
        for a in self.approvals:
            pats += list(a.get("scope", {}).get("paths", []))
        return pats

    def check_write_path(self, raw: str) -> str:
        rel, absp = rel_to(self.root, raw, self.cwd)
        if rel is None:
            if in_temp(absp):
                return "tmp"
            raise Block(f"escritura fuera del repositorio/worktree: {absp}. Usa la CLI "
                        "(csdd.py) para el buzón compartido.")
        if core.match_any(rel, self.defaults.get("secret_paths", [])) and not \
                core.match_any(rel, self.defaults.get("secret_allow", [])):
            raise Block(f"'{rel}' es un archivo de secretos (Art. VIII). Ningún agente lo toca.")
        if core.match_any(rel, self.defaults.get("protected_paths", [])):
            raise Block(f"'{rel}' está protegido (constitución, hooks, CI, config de agentes o "
                        "aprobaciones). Solo el propietario lo cambia, fuera del agente. "
                        "Propón el cambio con un ADR o un mensaje DECISION/BLOCKER.")
        if not core.match_any(rel, self.writable_patterns()):
            where = "allowed_paths de la tarea" if self.rcfg.get("write_paths_from_task") else "write_paths del rol"
            hint = ("Crea una tarea para El Hombre de la Bolsa (csdd.py task new + worktree new); el líder no "
                    "escribe código de producto.") if self.role == core.LEAD else \
                   ("Si de verdad hace falta, pide ampliar el contrato (BLOCKER al Jefe Maestro) "
                    "o una autorización Comunista al propietario.")
            raise Block(f"{self.rcfg['alias']} ({self.role}) no puede escribir '{rel}': fuera de {where}. {hint}")
        return rel

    def check_read_path(self, raw: str) -> None:
        rel, _ = rel_to(self.root, raw, self.cwd)
        name = Path(raw).name
        target = rel if rel is not None else name
        if (core.match_any(target, self.defaults.get("secret_paths", [])) or
                core.match_any(name, self.defaults.get("secret_paths", []))) and not \
                (core.match_any(target, self.defaults.get("secret_allow", [])) or
                 core.match_any(name, self.defaults.get("secret_allow", []))):
            raise Block(f"lectura de secretos bloqueada: '{target}' (Art. VIII). Usa .env.example.")

    # ------------------------------------------------------------ shell ----
    def approval_allows_command(self, segment: str) -> str | None:
        for a in self.approvals:
            for rx in a.get("scope", {}).get("commands_regex", []):
                try:
                    if re.search(rx, segment):
                        return a.get("approval_id", a.get("_file"))
                except re.error:
                    continue
        return None

    def approved_dependencies(self) -> set[str]:
        deps = {d.lower() for d in (self.task or {}).get("dependencies_allowed", [])}
        for a in self.approvals:
            deps |= {d.lower() for d in a.get("scope", {}).get("dependencies", [])}
        return deps

    def shell_class(self) -> str:
        c = self.rcfg.get("shell_class", "readonly")
        if c == "reviewer" and self.rcfg.get("reviewer_can_commit"):
            return "reviewer_commit"
        return c

    def check_shell(self, command: str) -> list[str]:
        notes = []
        for rx, label in HARD_DENY:
            if re.search(rx, command):
                raise Block(f"comando prohibido para todo agente: {label}.")
        for m in SECRET_TOKEN.finditer(command):
            if not SECRET_OK.search(command[m.start(): m.end() + 12]):
                raise Block("el comando toca un archivo de secretos (Art. VIII). Usa .env.example o "
                            "pide al propietario que exporte la variable en tu sesión.")
        if SHELL_WRITE_HINT.search(command) and any(f in command for f in PROTECTED_FRAGMENTS):
            raise Block("el comando parece escribir en rutas protegidas (constitución, hooks, CI, "
                        "config de agentes, roles o aprobaciones).")
        for seg in split_segments(command):
            approval = self.approval_allows_command(seg)
            if approval:
                notes.append(f"comando autorizado por {approval}")
                continue
            self.check_segment(seg)
        return notes

    def check_segment(self, seg: str) -> None:
        try:
            toks = shlex.split(seg, posix=True)
        except ValueError:
            toks = seg.split()
        if not toks:
            return
        while toks and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", toks[0]):
            toks = toks[1:]  # VAR=valor cmd
        if not toks:
            return
        cls = self.shell_class()
        self.check_cli(toks)
        self.check_git(toks, cls)
        self.check_install(seg.strip(), cls)
        self.check_fs(toks, seg, cls)

    def check_cli(self, toks: list[str]) -> None:
        idx = next((i for i, t in enumerate(toks) if t.endswith("csdd.py")), None)
        if idx is None:
            return
        rest = toks[idx + 1:]
        if "--as" in rest:
            j = rest.index("--as")
            claimed = rest[j + 1] if j + 1 < len(rest) else ""
            if claimed != self.role:
                raise Block(f"no puedes actuar --as {claimed}: tu rol es {self.role}.")
        sub = next((t for t in rest if not t.startswith("-")), "")
        sub2 = ""
        if sub in rest:
            after = rest[rest.index(sub) + 1:]
            sub2 = next((t for t in after if not t.startswith("-")), "")
        if "--acepto-alertas" in rest:
            raise Block("abrir una sesión con ALERTAS lo decide el propietario (--acepto-alertas), no un agente.")
        if sub in CLI_HUMAN_ONLY:
            raise Block("las autorizaciones (approval) solo las crea el propietario en su terminal.")
        if (sub in CLI_LEAD_ONLY or (sub == "task" and sub2 in CLI_TASK_LEAD_ONLY)) and self.role != core.LEAD:
            label = ("csdd.py " + sub + " " + sub2).strip()
            raise Block(f"'{label}' es solo del Jefe Maestro (enrutador e integrador).")
        if sub == "result" and not self.rcfg.get("can_record_results"):
            raise Block("solo Cortana o El Portero registran RESULT.")

    def check_git(self, toks: list[str], cls: str) -> None:
        if toks[0] != "git":
            return
        i = 1
        while i < len(toks) and toks[i].startswith("-"):
            i += 2 if toks[i] in ("-C", "-c") else 1
        if i >= len(toks):
            return
        sub = toks[i]
        args = toks[i + 1:]
        if sub == "add" and any(x in ("-A", "--all", ".", "-u", "--update", ":/", "*") for x in args):
            raise Block("anti-retrabajo: nunca 'git add -A' ni 'git add .'; añade solo rutas exactas.")
        if sub == "commit" and any(re.fullmatch(r"-[a-zA-Z]*a[a-zA-Z]*", x) or x == "--all" for x in args):
            raise Block("anti-retrabajo: nunca 'git commit -a'; añade rutas exactas con git add <ruta>.")
        if sub in GIT_SAFE or (sub == "branch" and (not args or args[0] in ("--list", "-a", "-r", "-v", "--show-current"))):
            return
        if sub == "stash" and args[:1] in (["list"], ["show"]):
            return
        allowed = GIT_BY_CLASS.get(cls, set())
        if cls == "lead":
            if sub == "merge":
                raise Block("el Jefe Maestro integra con 'csdd.py merge <TAREA>' (exige RESULT PASS "
                            "independiente). git merge directo está bloqueado.")
            if sub == "push":
                pos = [a for a in args if not a.startswith("-")]
                if len(pos) < 2:
                    raise Block("git push necesita remoto y rama explícitos (p. ej. git push origin task/T-001).")
                if any(re.search(r"(^|:)(main|master|HEAD)$", a) for a in pos[1:]):
                    raise Block("push a main/master lo hace el propietario, no un agente.")
            return
        if sub in ("rm", "mv", "restore") and sub in allowed:
            for a in [x for x in args if not x.startswith("-")]:
                self.check_write_path(a)
        if sub not in allowed:
            raise Block(f"'git {sub}' no está permitido para {self.rcfg['alias']} ({self.role}). "
                        f"Permitidos además de lectura: {sorted(allowed) or 'ninguno'}.")

    def check_install(self, seg: str, cls: str) -> None:
        m = INSTALL_RE.match(seg)
        if not m:
            return
        rest = m.group(m.lastindex) if m.lastindex else ""
        pkgs, skip = [], False
        for tok in (rest or "").split():
            if skip:
                skip = False
                continue
            if tok in ("-r", "--requirement", "-c", "--constraint", "-e", "--editable", "-f", "--find-links",
                       "-i", "--index-url", "--extra-index-url"):
                skip = True
                continue
            if tok.startswith("-") or tok in (".", "./"):
                continue
            mm = re.match(r"^(@?[^@=<>~!\[;\s]+)", tok)
            if mm:
                pkgs.append(mm.group(1).lower())
        if not pkgs:
            if cls == "readonly":
                raise Block("Jarvis no instala dependencias.")
            return  # instalación desde lockfile/requirements: reproducible
        allowed = self.approved_dependencies() if cls == "implementer" else \
            {d.lower() for a in self.approvals for d in a.get("scope", {}).get("dependencies", [])}
        missing = [p for p in pkgs if p not in allowed]
        if missing:
            raise Block(f"dependencias nuevas no autorizadas: {missing} (Art. I). Deben estar en "
                        "dependencies_allowed de la tarea y pasar revisión de El Portero.")

    def check_fs(self, toks: list[str], seg: str, cls: str) -> None:
        cmd = toks[0]
        targets = []
        for m in re.finditer(r"(?<![<>&\d=\-])\d?>>?(?!&)\s*([^\s;&|<>]+)", seg):
            targets.append(m.group(1))
        if cmd == "tee":
            targets += [t for t in toks[1:] if not t.startswith("-")]
        if cmd in ("sed", "perl") and any(re.fullmatch(r"-\w*i\w*", t) or t.startswith("--in-place") for t in toks[1:]):
            if cls in ("readonly", "reviewer", "reviewer_commit"):
                raise Block(f"edición en sitio ({cmd} -i) no permitida para {self.rcfg['alias']}.")
        if cmd in ("rm", "mv", "cp", "touch", "truncate", "ln", "mkdir", "chmod", "rmdir"):
            if cls in ("readonly", "reviewer", "reviewer_commit") and cmd not in ("mkdir",):
                raise Block(f"'{cmd}' no permitido para {self.rcfg['alias']} (rol de solo lectura/revisión).")
            args = [t for t in toks[1:] if not t.startswith("-")]
            if cmd == "chmod" and args:
                args = args[1:]
            if cmd == "cp" and len(args) >= 2:
                args = args[-1:]
            targets += args
        for t in targets:
            if t in ("/dev/null", "/dev/stdout", "/dev/stderr") or t.startswith("&") or "$" in t:
                continue
            self.check_write_path(t)


def split_segments(command: str) -> list[str]:
    parts = re.split(r"&&|\|\||;|\n|(?<!\|)\|(?!\|)", command)
    return [p.strip() for p in parts if p.strip()]


# --------------------------------------------------- protocolo de sesión ---
def allowed_without_session(seg: str) -> bool:
    try:
        toks = shlex.split(seg, posix=True)
    except ValueError:
        return False
    if not toks:
        return True
    head = toks[0]
    if head in READ_ONLY_CMDS:
        return True
    if head == "git":
        sub = next((t for t in toks[1:] if not t.startswith("-")), "")
        return sub in GIT_SAFE
    if any(t.endswith("csdd.py") for t in toks):
        i = next(i for i, t in enumerate(toks) if t.endswith("csdd.py"))
        rest = [t for t in toks[i + 1:] if not t.startswith("-")]
        sub = rest[0] if rest else ""
        return sub in CLI_NO_SESSION_OK or (sub == "task" and len(rest) > 1 and rest[1] in ("show", "list"))
    return any(t.endswith("ruta_critica.py") for t in toks)


def session_gate(ctx: "Ctx", cls: str, tin: dict) -> str | None:
    """Protocolo anti-retrabajo: sin `session start` vigente, nada que modifique."""
    if cls not in ("write", "shell"):
        return None
    s = sesion.cfg_session(core.load_system(ctx.root))
    if not s.get("required"):
        return None
    if sesion.active_session(ctx.coord, ctx.root, s["ttl_hours"]):
        return None
    if cls == "shell":
        cmd = first(tin, CMD_KEYS) or ""
        if all(allowed_without_session(x) for x in split_segments(cmd)):
            return None
    return ("Protocolo de sesión (anti-retrabajo, Art. IX): antes de modificar nada ejecuta "
            "`python .csdd/tools/csdd.py session start` y lee el estado calculado. Leer sí está permitido.")


# ------------------------------------------------------- presupuesto/bucles ---
def counters_path(ctx: Ctx) -> Path:
    return core.project_dir(ctx.coord) / "state" / "counters" / f"{ctx.task_id}__{ctx.role}.json"


def budget_and_loops(ctx: Ctx, cls: str, command: str | None) -> dict | None:
    if not ctx.task or ctx.role == core.LEAD:
        return None
    path = counters_path(ctx)
    c = core.read_json(path, {}) or {}
    c.setdefault("tool_calls", 0)
    c.setdefault("writes", 0)
    c.setdefault("cmds", {})
    budget = ctx.task.get("budget", {})
    max_calls = int(budget.get("max_tool_calls", 150))
    if c["tool_calls"] >= max_calls:
        raise Block(f"presupuesto agotado para {ctx.task_id}: {c['tool_calls']}/{max_calls} llamadas. "
                    f"Para y envía: csdd.py send --to {core.LEAD} --type BLOCKER --task {ctx.task_id} "
                    "--summary '<qué falta y por qué>'.")
    if cls == "shell" and command:
        h = hashlib.sha256(" ".join(command.split()).encode()).hexdigest()[:16]
        e = c["cmds"].get(h, {"n": 0, "w": -1})
        e = {"n": e["n"] + 1, "w": c["writes"]} if e["w"] == c["writes"] else {"n": 1, "w": c["writes"]}
        limit = int(ctx.defaults.get("max_repeat_without_change", 4))
        if e["n"] > limit:
            raise Block(f"posible bucle: el mismo comando {e['n']} veces sin cambiar ningún archivo. "
                        "Cambia de estrategia o envía un BLOCKER al Jefe Maestro.")
        c["cmds"][h] = e
    c["tool_calls"] += 1
    if cls == "write":
        c["writes"] += 1
    return c


# --------------------------------------------------------------------- main ---
def evaluate(payload: dict) -> tuple[int, str, dict]:
    name = str(payload.get("tool_name") or payload.get("tool") or payload.get("name") or "")
    tin = payload.get("tool_input") or payload.get("input") or payload.get("arguments") or payload.get("params") or {}
    if isinstance(tin, str):
        try:
            tin = json.loads(tin)
        except json.JSONDecodeError:
            tin = {"command": tin}
    cls = tool_class(name)
    if cls == "other":
        return 0, "", {}
    ctx = Ctx(payload)
    gate = session_gate(ctx, cls, tin)
    event = {"kind": "tool", "tool": name, "class": cls, "role": ctx.role, "role_source": ctx.role_source,
             "task": ctx.task_id}
    try:
        if gate:
            raise Block(gate)
        counters = None
        if cls == "read":
            raw = first(tin, PATH_KEYS)
            if raw:
                ctx.check_read_path(raw)
            return 0, "", {}
        if cls == "write":
            raws = [first(tin, PATH_KEYS)] if first(tin, PATH_KEYS) else []
            for e in tin.get("edits", []) if isinstance(tin.get("edits"), list) else []:
                if isinstance(e, dict) and first(e, PATH_KEYS):
                    raws.append(first(e, PATH_KEYS))
            if not raws:
                raise Block("no pude identificar la ruta de escritura (fail-secure).")
            event["paths"] = [ctx.check_write_path(r) for r in raws]
            counters = budget_and_loops(ctx, cls, None)
        if cls == "shell":
            command = first(tin, CMD_KEYS) or ""
            event["command"] = core.redact(command)
            notes = ctx.check_shell(command)
            if notes:
                event["notes"] = notes
            counters = budget_and_loops(ctx, cls, command)
        if counters is not None:
            core.write_json_atomic(counters_path(ctx), counters)
        event["decision"] = "allow"
        core.log_event(ctx.coord, event)
        return 0, "", event
    except Block as b:
        event.update(decision="block", reason=str(b))
        core.log_event(ctx.coord, event)
        return 2, f"[CSDD guard · {ctx.rcfg.get('alias', ctx.role)}] BLOQUEADO: {b}", event


def record_payload_keys(payload: dict) -> None:
    """Solo NOMBRES de campos (nunca valores) para que `csdd.py doctor` sepa si llega agent_type."""
    try:
        coord = core.coordination_root(Path(payload.get("cwd") or os.getcwd()))
        path = core.project_dir(coord) / "log" / "hook-payload-keys.jsonl"
        if path.exists() and path.stat().st_size > 20000:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"ts": core.now_iso(), "keys": sorted(payload.keys()),
                                 "tool": payload.get("tool_name") or payload.get("tool")}) + "\n")
    except OSError:
        pass


def main() -> int:
    core.ensure_utf8_stdio()
    raw = sys.stdin.read()
    try:
        payload = json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError:
        print("[CSDD guard] payload ilegible: bloqueado por fail-secure (Art. VI).", file=sys.stderr)
        return 2
    if not isinstance(payload, dict):
        print("[CSDD guard] payload inesperado: bloqueado por fail-secure (Art. VI).", file=sys.stderr)
        return 2
    record_payload_keys(payload)
    name = str(payload.get("tool_name") or payload.get("tool") or payload.get("name") or "")
    try:
        code, msg, _ = evaluate(payload)
    except Exception as exc:  # noqa: BLE001 — fail-secure deliberado
        if tool_class(name) in ("write", "shell"):
            print(f"[CSDD guard] error interno ({type(exc).__name__}: {exc}). Bloqueado por "
                  "fail-secure (Art. VI). Revisa .csdd/config/roles.toml o ejecuta csdd.py doctor.",
                  file=sys.stderr)
            return 2
        return 0
    if msg:
        print(msg, file=sys.stderr)
    return code


if __name__ == "__main__":
    sys.exit(main())

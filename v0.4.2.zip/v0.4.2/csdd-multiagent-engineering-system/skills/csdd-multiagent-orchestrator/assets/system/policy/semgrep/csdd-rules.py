# Fixtures para `semgrep --test`. No es código del producto.
import hashlib, subprocess, os, jwt, requests

# ruleid: csdd-art1-weak-hash-python
hashlib.md5(b"x")
# ok: csdd-art1-weak-hash-python
hashlib.sha256(b"x")

# ruleid: csdd-art1-jwt-decode-no-verify
jwt.decode(tok, options={"verify_signature": False})

def q(cur, user):
    # ruleid: csdd-art3-sql-fstring
    cur.execute(f"SELECT * FROM u WHERE id = {user}")
    # ruleid: csdd-art3-sql-concat
    cur.execute("SELECT * FROM u WHERE id = " + user)
    # ok: csdd-art3-sql-fstring
    cur.execute("SELECT * FROM u WHERE id = %s", (user,))

# ruleid: csdd-art3-subprocess-shell-true
subprocess.run("ls " + os.getcwd(), shell=True)
# ok: csdd-art3-subprocess-shell-true
subprocess.run(["ls", os.getcwd()])

# ruleid: csdd-art3-eval-python
eval(user_input)

# ruleid: csdd-art5-requests-verify-false
requests.get("https://x", verify=False)

def f():
    # ruleid: csdd-art6-bare-except-pass
    try:
        g()
    except:
        pass

# ruleid: csdd-art8-hardcoded-credential
DB_PASSWORD = "hunter2hunter2"
# ok: csdd-art8-hardcoded-credential
DB_PASSWORD = "changeme"

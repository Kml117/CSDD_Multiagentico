// Fixtures para `semgrep --test`. No es código del producto.
const crypto = require("crypto");
// ruleid: csdd-art1-weak-hash-js
crypto.createHash("md5");
// ok: csdd-art1-weak-hash-js
crypto.createHash("sha256");
// ruleid: csdd-art3-js-eval
eval(userInput);
// ruleid: csdd-art3-innerhtml
el.innerHTML = userInput;
// ok: csdd-art3-innerhtml
el.innerHTML = "";
function h() {
  // ruleid: csdd-art6-js-empty-catch
  try { risky(); } catch (e) {}
}

# Decision Record / ADR: [título]

- ID: ADR-XXXX
- Fecha:
- Estado: proposed / accepted / rejected / superseded
- Decisor autorizado: (propietario para decisiones reservadas)
- Artículos constitucionales afectados:

## Contexto
## Opciones (al menos dos, con costo y riesgo)
## Decisión
## Justificación
## Consecuencias y riesgos
## Controles ejecutables que cambian (constitution-controls.toml, roles.toml, CI)
## Artefactos afectados
## Aprobación / referencia (commit RATIFY o ADR firmado)

# Siguiente sesión

> Se **reescribe** al cerrar cada sesión (no se acumula; máximo una página). La historia va en la bitácora.
> Lo reescribe Jefe Maestro (o quien cierre en el worktree principal).

## Qué sigue, en orden
1. <tarea> · <tramo de RUTA-CRITICA> · <qué falta exactamente> · <entrada del propietario que necesita, si alguna>
2. …

## Bloqueos y entradas pendientes del propietario
- …

## PR de limpieza de documentos (se vacía UNA vez por gate, en un PR solo de documentos)
- <archivo:línea> · <contradicción en una línea>

# <Proyecto> · Ejecución por ruta crítica

**Versión:** 1.0 · **Fecha de cálculo:** AAAA-MM-DD · **Calcula:** Jefe Maestro (o Aurora en chat) · **Aprueba:** el propietario
**Estado:** BORRADOR | APROBADO por <propietario> el <fecha>
**Cálculo automático:** `python .csdd/tools/csdd.py ruta --out docs/ruta-critica-calculo.md` (no se edita a mano)
**Plan de entrada:** `.project/ruta-critica.toml`

> Este documento guarda **decisiones, supuestos y reglas**. Las fechas salen del cálculo; el estado del repo, de `csdd.py estado`.

## 0. Estado a <fecha>
| Tramo | Estado | Evidencia (commit, PR, comando) |
|---|---|---|

- Horas reales: … (de la bitácora) · Semáforo: … (de `csdd.py estado`)
- Riesgos nuevos: …

## 1. Idea en tres líneas
1. Recurso que limita: <H> h/semana de <quién>. Reordenar no acorta el trabajo: <horas pendientes> ÷ <H> ≈ <semanas>.
2. Lo que hace perder semanas son las esperas de calendario (<relojes>). Si quedan al final, se suman al final.
3. Por eso: arrancar temprano lo que dispara un reloj y repartir el resto en tramos, cada uno cerrado con un bloque de deuda.

## 2. Qué dice el cálculo
| Escenario | Fin | Nota |
|---|---|---|
| Orden anterior | | |
| **Propuesto/aprobado** | | |
| Cota inferior (sin límite de horas) | | |

- Ruta crítica en dependencias puras: `…`
- Regla dura: <hito> antes de <fecha> (acumulado ≈ <rojo> h). Cada semana de retraso mueve el final una semana.
- Último día para empezar la cadena del hito: <fecha>.

## 3. Calendario (tramos)
| Tramo | Tareas | Horas | Termina (aprox.) | Cierra con | Estado |
|---|---|---|---|---|---|

### 3.1 Tareas sin estimar o nuevas
| Tarea | Por qué existe | Dónde va | Estimación |
|---|---|---|---|

## 4. Bloques de deuda
Regla: cada tramo cierra con un bloque corto. **Tope: 1 h por ítem y 2 ítems por bloque.** Lo que no cabe se agenda como tarea con estimación propia. El PR de limpieza de documentos vive aquí (uno por gate).
| Bloque | Cuándo | Contenido |
|---|---|---|

## 5. Entradas del propietario, con fecha límite
Se hacen **en una sola tanda corta** antes del tramo que las necesita: una espera sin horas es la forma más barata de perder una semana.
| Antes de | Fecha límite | Qué aporta | Estado |
|---|---|---|---|

## 6. Reglas de sesión y de recálculo
1. Una sesión = una tarea del tramo vigente + su parte del bloque de deuda. Al empezar: `csdd.py session start` y declarar tramo.
2. No se adelantan tareas de tramos posteriores, salvo bloqueo y autorización escrita del propietario.
3. La bitácora lleva siempre horas (`csdd.py session end --horas X`).
4. Semáforo del hito (lo calcula `csdd.py estado`): verde ≤ amarillo; amarillo hasta rojo (sube la cadena del hito); rojo (> rojo sin el hito: recalcular).
5. Recálculo: tras cada gate con horas reales, y en el momento si una tarea supera su estimación en > 50 %.
6. El orden vive aquí; el estado de tareas en <sistema de seguimiento>; el estado del repo lo calcula `csdd.py estado`.

## 7. Decisiones del propietario
1. …

## 8. Supuestos y límites
- Origen de estimaciones y dependencias; qué no está estimado; buffers que no incluye la fecha.

# AGENTS.md — CSDD Multi-Agent v0.4.2

Lo leen Claude Code (vía CLAUDE.md), Kimi Code y cualquier agente compatible. Corto a propósito:
el detalle está en las Skills (`.claude/skills/` o `.agents/skills/`) y en `.csdd/`.

## Autoridad
El propietario del repo es la autoridad final. Jefe Maestro coordina dentro del alcance aprobado.
Nadie se autoaprueba, nadie cambia la constitución ni rebaja un MUST, nadie inventa resultados.

## Protocolo de sesión (anti-retrabajo · obligatorio para todo rol)
- **Al empezar:** `python .csdd/tools/csdd.py session start [--tarea T --tramo Tn]`. Lee la salida: es el estado real (rama, cambios, PR/CI, tareas, migraciones, alertas, horas, semáforo, qué sigue). Sin sesión, el guard no te deja modificar nada. Si hay ALERTA o cambios sin commitear que no son tuyos: **detente y pregunta**.
- **Durante:** nada se da por hecho sin comando y salida, tampoco lo que diga otro agente o un documento ("ya se aplicó" se comprueba). Un agente por árbol de trabajo. Solo `git add <ruta exacta>` (nunca `-A` ni `.`). Las contradicciones entre documentos no se corrigen sobre la marcha: se anotan en la lista de limpieza de `docs/SIGUIENTE-SESION.md`. No crees documentos nuevos sin que el propietario lo pida.
- **Al terminar:** `python .csdd/tools/csdd.py session end --resultado completado|parcial|detenido --horas X [--verificado "…"] [--no-verificado "…"] [--pide "…"]`. Escribe el bloque de bitácora (máx. 10 líneas). Las horas son obligatorias: si no las sabes, pregúntaselas al propietario. Mensaje final: hecho, falta, qué necesitas (máx. 5 líneas).

## Quién eres (lo decide el guard, no tú)
Tu rol sale de: identidad de subagente → `CSDD_ROLE` → `.csdd-task` del worktree → Jefe Maestro.
Compruébalo con `python .csdd/tools/csdd.py status`.

| Rol (ID estable) | Alias | Escribe en | Shell |
|---|---|---|---|
| csdd-executive-supervisor | Jefe Maestro | `.project/**`, `docs/**`, `specs/**` (incl. SIGUIENTE-SESION, RUTA-CRITICA) | git (merge solo con `csdd.py merge`) |
| csdd-software-architect | Jarvis (+ modo Tráiler) | `specs/**`, `docs/adr/**`, `docs/architecture/**`, `docs/requirements/**` | solo lectura |
| csdd-implementation-engineer | El Hombre de la Bolsa | `allowed_paths` de su tarea, en su worktree | pruebas, build, add/commit |
| csdd-qa-verification | Cortana | `tests/{acceptance,property,e2e,integration}/**`, evidencia | pruebas, add/commit en review/ |
| csdd-security-reviewer | El Portero | `docs/security/**`, evidencia | escáneres, solo lectura |

Protegido para todos: `constitution.md`, `AGENTS.md`, `CLAUDE.md`, `.csdd/`, `.claude/`, `.agents/`,
`.kimi-code/`, `.github/workflows/`, aprobaciones. Secretos (`.env`, `*.pem`…): ni leer ni escribir.

## Cómo se trabaja
1. Lee la Skill de tu rol y el contrato: `python .csdd/tools/csdd.py task show <TAREA>`.
2. Comunícate SOLO por el buzón: `csdd.py send --to <rol> --type QUESTION|ANSWER|BLOCKER --task <T> --summary "..."`.
   El Jefe Maestro enruta (`csdd.py route`). Revisa tu bandeja con `csdd.py inbox`.
3. Implementador: `csdd.py task start <T>` → pruebas primero → commits con `[REQ-…][Art. …]` → `csdd.py handoff <T> ...`.
4. Revisores: re-ejecutan todo y registran `csdd.py result <T> --status PASS|FAIL|NOT_RUN|NOT_APPLICABLE|UNKNOWN --evidence <archivo>`.
5. Solo el Jefe Maestro integra: `csdd.py merge <T>` (exige PASS independiente).
6. Si el guard te bloquea, no lo rodees: envía un BLOCKER explicando qué necesitas.

## Verificación
`python .csdd/tools/csdd.py verify` (lo mismo que CI). NOT_RUN nunca es PASS.

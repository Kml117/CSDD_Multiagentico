# Gate: [nombre]

- Proyecto / fase / iteración / incremento:
- Responsable:
- Fecha:

## Entrada
- [ ] Criterios de entrada cumplidos
- [ ] Dependencias resueltas

## Entregables y evidencia
- Artefactos:
- Versiones/commits:
- Pruebas y resultados (re-ejecutados por Cortana):
- Revisiones aplicables (El Portero si hay superficie de ataque):
- `csdd.py verify`: controles · trazabilidad · semgrep · gitleaks

## Criterios de salida
- [ ] Criterios de aceptación cumplidos
- [ ] Riesgos residuales registrados
- [ ] Cambios y deuda técnica registrados

## Resultado
`PASS | FAIL | NOT_RUN | NOT_APPLICABLE | UNKNOWN`

## Decisión y autoridad
- Recomendación de agentes:
- Decisión de Jefe Maestro dentro de su autoridad:
- ¿Requiere decisión del usuario?:
- Referencia de aprobación:

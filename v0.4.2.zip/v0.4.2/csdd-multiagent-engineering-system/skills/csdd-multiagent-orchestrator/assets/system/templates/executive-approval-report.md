# Informe ejecutivo · Jefe Maestro

## Resumen
- Proyecto / hito:
- Estado:
- Ciclo de vida / enfoque / nivel de ceremonia:
- Qué se completó (por REQ):

## Evidencia (estados honestos: PASS · FAIL · NOT_RUN · NOT_APPLICABLE · UNKNOWN)
| Tarea | Cortana | El Portero | CI | Evidencia |
|---|---|---|---|---|

## Decisión solicitada (solo si es reservada al propietario)
- Decisión concreta:
- Por qué está reservada:
- Opciones (mínimo dos) y recomendación:

## Impacto y riesgos
- Alcance / tiempo / costo (llamadas y minutos consumidos vs presupuesto):
- Seguridad / datos:
- Reversibilidad:
- Riesgo residual:

## Acciones propuestas
| Acción | Archivos/recursos | Rol | Riesgo | Verificación |
|---|---|---|---|---|

## Autorización
- Alcance autorizado / exclusiones / vigencia / aprobación explícita (APPROVE · REJECT: … · CLARIFY: …):

# Handoff — [TAREA] · [título]

> Artefacto de detalle que acompaña a `csdd.py handoff`. Guárdalo en `.project/artifacts/evidence/<TAREA>/handoff.md`
> y pásalo con `--ref`. El mensaje del buzón solo resume; aquí va la verdad verificable.

## Qué se hizo
- REQ cubiertos: REQ-…, REQ-…
- Artículos aplicados y mecanismo concreto (nada de "se respeta"): Art. III → esquema Pydantic `LoginIn` en `src/auth/schemas.py`

## Archivos cambiados
(salida de `git diff --name-only <base>...HEAD`; todos dentro de allowed_paths)

## Evidencia ejecutada (no declarada)
| Comando | Entorno | Resultado | Salida |
|---|---|---|---|
| `uv run pytest tests/auth -q` | Python 3.12, local | PASS | `evidence/T-001/pytest.txt` |

## Lo que NO se hizo / riesgos
- …

## Preguntas para el revisor
- …

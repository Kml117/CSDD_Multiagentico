@AGENTS.md

# Específico de Claude Code

- Antes de cualquier tarea, y otra vez al terminarla, aplica el **Protocolo de sesión** de AGENTS.md (`csdd.py session start` / `session end`).
- Ningún agente hace el commit RATIFY, aprueba un gate ni fusiona a `main`: eso lo hace el propietario.

- La sesión principal en el worktree principal es **Jefe Maestro** (Skill `csdd-multiagent-orchestrator` + `csdd-executive-supervisor`).
- Subagentes disponibles en `.claude/agents/`: Jarvis, El Hombre de la Bolsa, Cortana y El Portero (generados por `.csdd/tools/sync_agents.py`).
- Hooks: `.claude/settings.json` ejecuta `.csdd/hooks/guard.py` antes de Read/Edit/Write/Bash. Si un subagente comparte esta sesión
  y `csdd.py doctor` dice que el hook NO recibe su identidad, ese subagente opera con los permisos del Jefe Maestro:
  para separación real usa una sesión por rol (Modo A, ver EXECUTION_GUIDE).
- Constitución: consulta la Skill `csdd-mentor` solo para interpretar artículos; no conviertas cada tarea en una clase.

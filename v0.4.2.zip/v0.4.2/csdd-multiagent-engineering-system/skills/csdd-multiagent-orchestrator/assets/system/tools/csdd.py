#!/usr/bin/env python3
"""csdd — CLI del CSDD Multi-Agent v0.4.2 (solo librería estándar, Python 3.11+).

Coordinación por archivos con enrutador explícito (Alternativa B):
  los agentes escriben en SU outbox; solo el Jefe Maestro ejecuta `route`.
Todo vive en .project/ del worktree PRINCIPAL (compartido por todos los worktrees).

Uso rápido (ver EXECUTION_GUIDE.md):
  csdd.py init
  csdd.py task new --id T-001 --title "..." --role csdd-implementation-engineer --paths "src/api/**" --paths "tests/api/**" --req REQ-001
  csdd.py worktree new T-001          # rama task/T-001 + worktree + .csdd-task
  csdd.py task start T-001            # (implementador)
  csdd.py handoff T-001 --summary "..." --ref tests/api/test_x.py
  csdd.py route                       # (líder) mueve outbox -> inbox
  csdd.py worktree review T-001       # rama review/T-001 para Cortana
  csdd.py result T-001 --status PASS --summary "..." --evidence .project/artifacts/evidence/T-001/qa.txt
  csdd.py merge T-001                 # (líder) solo con PASS independiente
  csdd.py status | watchdog | verify | doctor
"""
from __future__ import annotations

import argparse
import json
import os
import secrets
import shutil
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True  # no ensuciar .csdd/ (ruta protegida) con __pycache__
HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parent.parent / "lib"))
import csdd_core as core  # noqa: E402
sys.path.insert(0, str(HERE.parent))
import ruta_critica  # noqa: E402
import sesion  # noqa: E402

MSG_TYPES = ("TASK", "HANDOFF", "QUESTION", "ANSWER", "RESULT", "BLOCKER")
RESULT_STATES = ("PASS", "FAIL", "NOT_RUN", "NOT_APPLICABLE", "UNKNOWN")
TASK_STATES = ("QUEUED", "IN_PROGRESS", "IN_REVIEW", "REWORK", "STUCK", "DONE", "CANCELLED")


class CliError(Exception):
    pass


# ------------------------------------------------------------------ contexto ---
class Env:
    def __init__(self, as_role: str | None = None):
        self.root = core.repo_root()
        self.coord = core.coordination_root(self.root)
        cfg_root = self.root if (self.root / ".csdd").exists() else self.coord
        self.cfg = core.load_roles(cfg_root)
        self.system = core.load_system(cfg_root)
        self.roles = self.cfg["roles"]
        if as_role:
            as_role = self.cfg.get("legacy", {}).get(as_role, as_role)
            if as_role not in self.roles:
                raise CliError(f"rol desconocido: {as_role}")
            self.role, self.role_source = as_role, "--as"
        else:
            self.role, self.role_source = core.resolve_role(self.root, self.cfg)
        self.p = core.project_dir(self.coord)

    def alias(self, role: str) -> str:
        return self.roles.get(role, {}).get("alias", role)

    def require(self, *roles: str) -> None:
        if self.role not in roles:
            names = ", ".join(self.alias(r) for r in roles)
            raise CliError(f"esta acción es de {names}; tu rol resuelto es {self.alias(self.role)} "
                           f"({self.role}, fuente: {self.role_source}).")

    def task(self, task_id: str) -> dict:
        t = core.load_task(self.coord, task_id)
        if not t:
            raise CliError(f"tarea no encontrada: {task_id}")
        return t

    def orch(self, key: str, default):
        return self.system.get("orchestration", {}).get(key, default)

    def event(self, **kw) -> None:
        core.log_event(self.coord, {"kind": "cli", "role": self.role, **kw})


def git(args: list[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess:
    cp = subprocess.run(["git", *args], cwd=str(cwd), capture_output=True, text=True, encoding="utf-8", errors="replace")
    if check and cp.returncode != 0:
        raise CliError(f"git {' '.join(args)} falló: {cp.stderr.strip() or cp.stdout.strip()}")
    return cp


def new_id(prefix: str, role: str) -> str:
    short = role.replace("csdd-", "")[:12]
    return f"{prefix}{core.now().strftime('%Y%m%dT%H%M%S')}-{short}-{secrets.token_hex(2)}"


# ---------------------------------------------------------------------- init ---
def cmd_init(env: Env, a) -> None:
    dirs = ["mailbox/user", "mailbox/rejected", "mailbox/archive", "state/tasks", "state/acks",
            "state/counters", "state/approvals", "log", "artifacts/specs", "artifacts/evidence",
            "artifacts/reports"]
    for r in env.roles:
        dirs += [f"mailbox/outbox/{r}", f"mailbox/inbox/{r}"]
    for d in dirs:
        (env.p / d).mkdir(parents=True, exist_ok=True)
    gi = env.coord / ".gitignore"
    lines = gi.read_text(encoding="utf-8").splitlines() if gi.exists() else []
    want = ["# CSDD runtime (no versionar)", ".project/mailbox/", ".project/state/", ".project/log/", ".csdd-task",
            "__pycache__/", "*.pyc"]
    add = [w for w in want if w not in lines]
    if add:
        with open(gi, "a", encoding="utf-8") as fh:
            fh.write(("\n" if lines and lines[-1] else "") + "\n".join(add) + "\n")
    exc = git(["rev-parse", "--git-path", "info/exclude"], env.coord, check=False)
    if exc.returncode == 0:
        ex = (env.coord / exc.stdout.strip()).resolve()
        ex.parent.mkdir(parents=True, exist_ok=True)
        cur = ex.read_text(encoding="utf-8") if ex.exists() else ""
        if ".csdd-task" not in cur.split():
            ex.write_text(cur + ("\n" if cur and not cur.endswith("\n") else "") + ".csdd-task\n", encoding="utf-8")
    tpl = env.coord / ".csdd" / "templates"
    for f in ("project-profile.yaml", "lifecycle-profile.yaml"):
        dst = env.p / f
        if not dst.exists() and (tpl / f).exists():
            shutil.copy(tpl / f, dst)
    sig = env.coord / sesion.cfg_session(env.system)["siguiente_file"]
    if not sig.exists() and (tpl / "SIGUIENTE-SESION.md").exists():
        sig.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(tpl / "SIGUIENTE-SESION.md", sig)
    env.event(action="init")
    print(f"OK coordinación lista en {env.p}")


# --------------------------------------------------------------------- tareas ---
def _validate_paths(env: Env, paths: list[str]) -> None:
    protected = env.cfg["defaults"]["protected_paths"] + env.cfg["defaults"]["secret_paths"]
    for p in paths:
        sp = core.static_prefix(p)
        if not sp.strip("/"):
            raise CliError(f"allowed_paths demasiado amplio: '{p}'. Sé específico (p. ej. src/api/**).")
        for prot in protected:
            pp = core.static_prefix(prot)
            if pp and (pp.startswith(sp) or sp.startswith(pp)):
                raise CliError(f"'{p}' choca con ruta protegida/secreta '{prot}'.")


def cmd_task(env: Env, a) -> None:
    if a.action == "new":
        env.require(core.LEAD)
        if not a.id or not a.title or not a.role:
            raise CliError("task new requiere --id, --title y --role")
        if core.load_task(env.coord, a.id):
            raise CliError(f"ya existe la tarea {a.id}")
        role = env.cfg.get("legacy", {}).get(a.role, a.role)
        if role not in env.roles:
            raise CliError(f"rol desconocido: {a.role}")
        paths = a.paths or []
        if role == core.IMPL and not paths:
            raise CliError("una tarea de implementación necesita --paths (allowed_paths).")
        _validate_paths(env, paths)
        if paths and not a.allow_overlap:
            for t in core.all_tasks(env.coord):
                if t.get("status") in core.ACTIVE_STATES and t.get("allowed_paths"):
                    hits = core.globs_overlap(paths, t["allowed_paths"])
                    if hits:
                        raise CliError(f"choque de rutas con {t['task_id']}: {hits[:3]}. Serializa, "
                                       "parte distinto o usa --allow-overlap si es intencional.")
        task = {
            "task_id": a.id, "title": a.title, "objective": a.objective or a.title,
            "owner_role": role, "runtime": a.runtime, "status": "QUEUED",
            "req_ids": a.req or [], "articles": a.article or [], "allowed_paths": paths,
            "dependencies_allowed": a.dep or [], "acceptance_criteria": a.accept or [],
            "depends_on": a.depends_on or [],
            "verification": {"qa_required": not a.no_qa, "security_review_required": bool(a.security),
                             "commands": a.verify_cmd or []},
            "budget": {"max_tool_calls": a.budget_calls or env.orch("default_budget_tool_calls", 150),
                       "max_minutes": a.budget_minutes or env.orch("default_budget_minutes", 90),
                       "max_retries": a.retries if a.retries is not None else env.orch("default_max_retries", 2)},
            "worktree": {}, "results": [], "retries": 0,
            "created_at": core.now_iso(), "created_by": env.role,
        }
        core.save_task(env.coord, task)
        env.event(action="task.new", task=a.id, owner=role)
        print(f"OK tarea {a.id} creada para {env.alias(role)} · rutas {paths or '—'}")
    elif a.action == "show":
        print(json.dumps(env.task(a.id), ensure_ascii=False, indent=2))
    elif a.action == "list":
        for t in core.all_tasks(env.coord):
            print(f"{t['task_id']:<10} {t['status']:<12} {env.alias(t['owner_role']):<22} {t['title']}")
    elif a.action == "start":
        t = env.task(a.id)
        env.require(t["owner_role"])
        if t["status"] not in ("QUEUED", "REWORK"):
            raise CliError(f"no se puede iniciar desde {t['status']}")
        for dep in t.get("depends_on", []):
            d = core.load_task(env.coord, dep)
            if not d or d.get("status") != "DONE":
                raise CliError(f"dependencia {dep} no está DONE")
        t["status"] = "IN_PROGRESS"
        t.setdefault("started_at", core.now_iso())
        t["last_started_at"] = core.now_iso()
        core.save_task(env.coord, t)
        env.event(action="task.start", task=a.id)
        print(f"OK {a.id} IN_PROGRESS · presupuesto {t['budget']}")
    elif a.action == "set-status":
        env.require(core.LEAD)
        if a.status not in TASK_STATES:
            raise CliError(f"estado inválido. Usa: {TASK_STATES}")
        t = env.task(a.id)
        t["status"] = a.status
        core.save_task(env.coord, t)
        env.event(action="task.set-status", task=a.id, status=a.status)
        print(f"OK {a.id} -> {a.status}")
    elif a.action == "cancel":
        env.require(core.LEAD)
        t = env.task(a.id)
        t["status"] = "CANCELLED"
        core.save_task(env.coord, t)
        env.event(action="task.cancel", task=a.id)
        print(f"OK {a.id} CANCELLED")


# ------------------------------------------------------------------ worktrees ---
def _wt_dir(env: Env, task_id: str, suffix: str = "") -> Path:
    base = Path(env.orch("worktrees_dir", "")) if env.orch("worktrees_dir", "") else \
        env.coord.parent / f"{env.coord.name}-wt"
    return (base / f"{task_id}{suffix}").resolve()


def _write_task_file(path: Path, task_id: str, role: str) -> None:
    core.write_json_atomic(path / core.TASK_FILE, {"task_id": task_id, "role": role,
                                                   "created_at": core.now_iso()})


def cmd_worktree(env: Env, a) -> None:
    env.require(core.LEAD)
    t = env.task(a.id)
    wt = t.setdefault("worktree", {})
    if a.action == "new":
        if wt.get("path") and Path(wt["path"]).exists():
            raise CliError(f"ya existe worktree para {a.id}: {wt['path']}")
        active = [x for x in core.all_tasks(env.coord) if x["owner_role"] == core.IMPL
                  and x["status"] in ("IN_PROGRESS", "REWORK") and x["task_id"] != a.id]
        limit = int(env.orch("max_parallel_write_tasks", 2))
        if t["owner_role"] == core.IMPL and len(active) >= limit and not a.force:
            raise CliError(f"ya hay {len(active)} tareas de escritura activas (límite {limit}). "
                           "Termina una o usa --force conscientemente.")
        base = a.base or git(["rev-parse", "--abbrev-ref", "HEAD"], env.coord).stdout.strip()
        path = Path(a.dir).resolve() if a.dir else _wt_dir(env, a.id)
        branch = f"task/{a.id}"
        path.parent.mkdir(parents=True, exist_ok=True)
        git(["worktree", "add", "-b", branch, str(path), base], env.coord)
        _write_task_file(path, a.id, t["owner_role"])
        wt.update(path=str(path), branch=branch, base=base,
                  base_commit=git(["rev-parse", base], env.coord).stdout.strip())
        core.save_task(env.coord, t)
        env.event(action="worktree.new", task=a.id, path=str(path), branch=branch)
        print(f"OK worktree {path} (rama {branch}, base {base}) para {env.alias(t['owner_role'])}")
        if not (path / ".csdd" / "hooks" / "guard.py").exists():
            print("AVISO: el worktree no tiene .csdd/hooks/guard.py. Commitea .csdd/, .claude/ y AGENTS.md en "
                  f"la rama {base} ANTES de crear worktrees; si no, el guard no protege allí.")
    elif a.action == "review":
        if not wt.get("branch"):
            raise CliError("la tarea no tiene rama task/; crea primero 'worktree new'.")
        rbranch = f"review/{a.id}"
        rpath = Path(wt["review_path"]) if wt.get("review_path") else _wt_dir(env, a.id, "-review")
        if rpath.exists():
            cp = git(["merge", "--no-edit", wt["branch"]], rpath, check=False)
            if cp.returncode != 0:
                git(["merge", "--abort"], rpath, check=False)
                raise CliError(f"no pude actualizar {rbranch} con {wt['branch']}: {cp.stderr.strip()}")
            print(f"OK {rbranch} actualizado con {wt['branch']}")
        else:
            git(["worktree", "add", "-b", rbranch, str(rpath), wt["branch"]], env.coord)
            print(f"OK worktree de revisión {rpath} (rama {rbranch})")
        _write_task_file(rpath, a.id, core.QA)
        wt.update(review_path=str(rpath), review_branch=rbranch)
        core.save_task(env.coord, t)
        env.event(action="worktree.review", task=a.id, path=str(rpath))
    elif a.action == "remove":
        for key in ("review_path", "path"):
            p = wt.get(key)
            if p and Path(p).exists():
                args = ["worktree", "remove", p] + (["--force"] if a.force else [])
                git(args, env.coord)
                print(f"OK eliminado {p}")
        env.event(action="worktree.remove", task=a.id)


# --------------------------------------------------------------------- buzón ---
def _write_message(env: Env, msg: dict) -> Path:
    path = env.p / "mailbox" / "outbox" / msg["from"] / f"{msg['message_id']}.json"
    core.write_json_atomic(path, msg)
    env.event(action="send", message_id=msg["message_id"], to=msg["to"], type=msg["type"], task=msg.get("task_id"))
    return path


def build_message(env: Env, to: str, mtype: str, task_id: str | None, summary: str, refs=None,
                  reply_to=None, needs_user=False, extra=None) -> dict:
    max_chars = int(env.system.get("communication", {}).get("max_summary_chars", 600))
    if mtype not in MSG_TYPES:
        raise CliError(f"tipo inválido {mtype}. Usa: {MSG_TYPES}")
    if len(summary) > max_chars:
        raise CliError(f"summary de {len(summary)} caracteres (máx {max_chars}). El detalle va en un artefacto (--ref).")
    if to != "user" and to not in env.roles:
        raise CliError(f"destinatario desconocido: {to}")
    msg = {"message_id": new_id("M", env.role), "created_at": core.now_iso(), "from": env.role, "to": to,
           "type": mtype, "task_id": task_id, "summary": summary, "refs": refs or [],
           "reply_to": reply_to, "needs_user": bool(needs_user), "schema": "csdd-message/0.4"}
    if extra:
        msg.update(extra)
    return msg


def cmd_send(env: Env, a) -> None:
    if a.task:
        env.task(a.task)
    msg = build_message(env, a.to, a.type, a.task, a.summary, a.ref, a.reply_to, a.needs_user)
    path = _write_message(env, msg)
    print(f"OK {msg['message_id']} en outbox ({path.parent.name}). El Jefe Maestro lo enruta con 'route'.")


def _validate_for_route(env: Env, msg: dict, owner_dir: str, seen: set) -> str | None:
    need = ("message_id", "from", "to", "type", "summary", "created_at")
    if any(k not in msg for k in need):
        return "faltan campos obligatorios"
    if msg["message_id"] in seen:
        return "message_id duplicado"
    if msg["from"] != owner_dir:
        return f"'from' ({msg['from']}) no coincide con el outbox ({owner_dir})"
    if msg["type"] not in MSG_TYPES:
        return "tipo inválido"
    if msg["to"] != "user" and msg["to"] not in env.roles:
        return "destinatario desconocido"
    if msg["type"] == "TASK" and msg["from"] != core.LEAD:
        return "solo el Jefe Maestro asigna TASK"
    if msg["type"] == "RESULT" and not env.roles.get(msg["from"], {}).get("can_record_results"):
        return "solo Cortana/El Portero envían RESULT"
    if msg.get("task_id"):
        t = core.load_task(env.coord, msg["task_id"])
        if not t:
            return "task_id inexistente"
        if msg["type"] == "HANDOFF" and msg["from"] != t["owner_role"]:
            return "HANDOFF solo del dueño de la tarea"
    return None


def cmd_route(env: Env, a) -> None:
    env.require(core.LEAD)
    seen_file = env.p / "state" / "seen_message_ids.txt"
    seen = set(seen_file.read_text(encoding="utf-8").split()) if seen_file.exists() else set()
    routed = rejected = 0
    outbox = env.p / "mailbox" / "outbox"
    for d in sorted(outbox.glob("*")) if outbox.exists() else []:
        for f in sorted(d.glob("*.json")):
            msg = core.read_json(f)
            reason = "JSON ilegible" if not isinstance(msg, dict) else _validate_for_route(env, msg, d.name, seen)
            if reason:
                dst = env.p / "mailbox" / "rejected" / f.name
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(f), dst)
                dst.with_suffix(".reason.txt").write_text(reason + "\n", encoding="utf-8")
                env.event(action="route.reject", file=f.name, reason=reason)
                rejected += 1
                continue
            target = env.p / "mailbox" / ("user" if msg["to"] == "user" else f"inbox/{msg['to']}")
            target.mkdir(parents=True, exist_ok=True)
            shutil.move(str(f), target / f.name)
            seen.add(msg["message_id"])
            env.event(action="route", message_id=msg["message_id"], to=msg["to"], type=msg["type"])
            routed += 1
    seen_file.parent.mkdir(parents=True, exist_ok=True)
    seen_file.write_text("\n".join(sorted(seen)) + "\n", encoding="utf-8")
    print(f"OK enrutados {routed} · rechazados {rejected} (ver mailbox/rejected/*.reason.txt)")


def _acked(env: Env, mid: str) -> dict | None:
    return core.read_json(env.p / "state" / "acks" / f"{mid}.json")


def cmd_inbox(env: Env, a) -> None:
    who = a.agent or env.role
    box = env.p / "mailbox" / ("user" if who == "user" else f"inbox/{who}")
    msgs = [core.read_json(f) for f in sorted(box.glob("*.json"))] if box.exists() else []
    msgs = [m for m in msgs if isinstance(m, dict) and (a.all or not _acked(env, m["message_id"]))]
    if not msgs:
        print(f"(inbox de {env.alias(who) if who != 'user' else 'usuario'} vacía)")
    for m in msgs:
        ack = _acked(env, m["message_id"])
        state = "ACK" if ack else "NUEVO"
        print(f"[{state}] {m['message_id']} {m['type']:<8} de {env.alias(m['from'])} · {m.get('task_id') or '-'}\n"
              f"        {m['summary']}" + (f"\n        refs: {', '.join(m['refs'])}" if m.get("refs") else ""))


def cmd_ack(env: Env, a) -> None:
    box = env.p / "mailbox" / f"inbox/{env.role}"
    f = box / f"{a.message_id}.json"
    if not f.exists():
        raise CliError(f"no está en tu inbox: {a.message_id}")
    core.write_json_atomic(env.p / "state" / "acks" / f"{a.message_id}.json",
                           {"message_id": a.message_id, "by": env.role, "at": core.now_iso(), "done": a.done})
    if a.done:
        arch = env.p / "mailbox" / "archive" / core.now().strftime("%Y-%m")
        arch.mkdir(parents=True, exist_ok=True)
        shutil.move(str(f), arch / f.name)
    env.event(action="ack", message_id=a.message_id, done=a.done)
    print(f"OK {a.message_id} {'cerrado' if a.done else 'acusado'}")


# ----------------------------------------------------------- handoff/gates ---
def _changed_files(t: dict) -> list[str]:
    wt = t.get("worktree", {})
    if not wt.get("path") or not wt.get("base_commit"):
        return []
    cp = git(["diff", "--name-only", f"{wt['base_commit']}...HEAD"], Path(wt["path"]), check=False)
    st = git(["status", "--porcelain"], Path(wt["path"]), check=False)
    files = set(cp.stdout.split()) if cp.returncode == 0 else set()
    for line in st.stdout.splitlines():
        if line[3:] and not line[3:].endswith(core.TASK_FILE):
            files.add(line[3:].split(" -> ")[-1])
    return sorted(files)


def cmd_handoff(env: Env, a) -> None:
    t = env.task(a.id)
    env.require(t["owner_role"])
    if t["status"] not in ("IN_PROGRESS", "REWORK"):
        raise CliError(f"handoff desde {t['status']} no tiene sentido")
    allowed = t.get("allowed_paths", []) + [p for ap in core.active_approvals(env.coord, a.id, env.role)
                                            for p in ap.get("scope", {}).get("paths", [])]
    changed = _changed_files(t)
    outside = [f for f in changed if allowed and not core.match_any(f, allowed)]
    if outside:
        raise CliError(f"cambios fuera de allowed_paths: {outside}. Reviértelos o pide ampliación.")
    st = git(["status", "--porcelain"], Path(t["worktree"]["path"]), check=False) if t.get("worktree", {}).get("path") else None
    dirty = [l for l in (st.stdout.splitlines() if st else []) if not l.endswith(core.TASK_FILE)]
    if dirty:
        raise CliError("hay cambios sin commit en el worktree. Commitea con mensaje que cite REQ y artículos.")
    t["status"] = "IN_REVIEW"
    t["handoff"] = {"at": core.now_iso(), "summary": a.summary, "refs": a.ref or [], "changed_files": changed}
    core.save_task(env.coord, t)
    msg = build_message(env, core.LEAD, "HANDOFF", a.id, a.summary, a.ref,
                        extra={"changed_files": changed})
    _write_message(env, msg)
    print(f"OK handoff {a.id} -> IN_REVIEW · {len(changed)} archivos · mensaje {msg['message_id']}")


def cmd_result(env: Env, a) -> None:
    t = env.task(a.id)
    if not env.roles[env.role].get("can_record_results"):
        raise CliError("solo Cortana o El Portero registran RESULT")
    if env.role == t["owner_role"]:
        raise CliError("nadie se autoaprueba: el dueño de la tarea no registra su RESULT")
    if a.status not in RESULT_STATES:
        raise CliError(f"estado inválido. Usa: {RESULT_STATES}")
    if a.status == "PASS" and not a.evidence:
        raise CliError("PASS sin evidencia no existe: pasa --evidence (archivo con comando, entorno y salida).")
    if a.blocking and not env.roles[env.role].get("can_block"):
        raise CliError("solo El Portero emite bloqueos de seguridad")
    res = {"by": env.role, "status": a.status, "summary": a.summary, "evidence": a.evidence or [],
           "blocking": bool(a.blocking), "at": core.now_iso(),
           "commit": git(["rev-parse", "HEAD"], env.root, check=False).stdout.strip()}
    t.setdefault("results", []).append(res)
    max_retries = int(t.get("budget", {}).get("max_retries", 2))
    if a.status == "FAIL":
        t["retries"] = int(t.get("retries", 0)) + 1
        t["status"] = "STUCK" if t["retries"] > max_retries else "REWORK"
    core.save_task(env.coord, t)
    _write_message(env, build_message(env, core.LEAD, "RESULT", a.id, a.summary, a.evidence,
                                      extra={"status": a.status, "blocking": bool(a.blocking)}))
    if t["status"] == "STUCK":
        _system_blocker(env, a.id, f"{a.id} superó {max_retries} reintentos. Cambia estrategia o escala al propietario.")
    env.event(action="result", task=a.id, status=a.status, blocking=bool(a.blocking))
    print(f"OK RESULT {a.status} para {a.id} · tarea {t['status']}")


def _latest(t: dict, role: str) -> dict | None:
    rs = [r for r in t.get("results", []) if r["by"] == role]
    return rs[-1] if rs else None


def merge_preconditions(t: dict) -> list[str]:
    problems = []
    if t["status"] != "IN_REVIEW":
        problems.append(f"estado {t['status']} (se requiere IN_REVIEW)")
    v = t.get("verification", {})
    qa = _latest(t, core.QA)
    if v.get("qa_required", True) and (not qa or qa["status"] != "PASS"):
        problems.append("falta RESULT PASS de Cortana")
    sec = _latest(t, core.SEC)
    if v.get("security_review_required") and (not sec or sec["status"] != "PASS"):
        problems.append("falta RESULT PASS de El Portero")
    if sec and sec.get("blocking") and sec["status"] != "PASS":
        problems.append("bloqueo de seguridad vigente de El Portero")
    for r in (qa, sec):
        if r and r["by"] == t["owner_role"]:
            problems.append("autoaprobación detectada")
    return problems


def cmd_merge(env: Env, a) -> None:
    env.require(core.LEAD)
    t = env.task(a.id)
    problems = merge_preconditions(t)
    if problems:
        raise CliError("no se integra: " + "; ".join(problems))
    dirty = git(["status", "--porcelain", "--untracked-files=no"], env.coord, check=False).stdout.strip()
    if dirty:
        raise CliError("el worktree principal tiene cambios sin commit; límpialo antes de integrar.")
    wt = t.get("worktree", {})
    branch = wt.get("review_branch") if wt.get("review_branch") and \
        git(["rev-parse", "--verify", wt["review_branch"]], env.coord, check=False).returncode == 0 else wt.get("branch")
    if not branch:
        raise CliError("no hay rama que integrar")
    msg = f"merge({a.id}): {t['title']}"
    if t.get("req_ids"):
        msg += f" [{', '.join(t['req_ids'])}]"
    if t.get("articles"):
        msg += f" [Art. {', '.join(t['articles'])}]"
    cp = git(["merge", "--no-ff", "-m", msg, branch], env.coord, check=False)
    if cp.returncode != 0:
        git(["merge", "--abort"], env.coord, check=False)
        t["status"] = "REWORK"
        core.save_task(env.coord, t)
        _system_blocker(env, a.id, f"conflicto al integrar {branch}; tarea a REWORK. Detalle: {cp.stdout[-300:]}")
        raise CliError(f"conflicto de merge; abortado y tarea en REWORK")
    t["status"] = "DONE"
    t["merged"] = {"at": core.now_iso(), "branch": branch,
                   "commit": git(["rev-parse", "HEAD"], env.coord).stdout.strip()}
    core.save_task(env.coord, t)
    env.event(action="merge", task=a.id, branch=branch)
    print(f"OK {branch} integrada ({t['merged']['commit'][:8]}). Corre las pruebas de integración y 'csdd.py verify'.")


def _system_blocker(env: Env, task_id: str, summary: str) -> None:
    msg = {"message_id": new_id("S", "system"), "created_at": core.now_iso(), "from": "system",
           "to": core.LEAD, "type": "BLOCKER", "task_id": task_id, "summary": summary[:600], "refs": [],
           "reply_to": None, "needs_user": False, "schema": "csdd-message/0.4"}
    core.write_json_atomic(env.p / "mailbox" / f"inbox/{core.LEAD}" / f"{msg['message_id']}.json", msg)
    env.event(action="system.blocker", task=task_id, summary=summary[:200])


def cmd_watchdog(env: Env, a) -> None:
    flagged = 0
    for t in core.all_tasks(env.coord):
        if t["status"] != "IN_PROGRESS" or not t.get("last_started_at"):
            continue
        minutes = (core.now() - core.parse_iso(t["last_started_at"])).total_seconds() / 60
        limit = int(t.get("budget", {}).get("max_minutes", 90))
        if minutes > limit:
            t["status"] = "STUCK"
            core.save_task(env.coord, t)
            _system_blocker(env, t["task_id"], f"{t['task_id']} lleva {int(minutes)} min (límite {limit}). Marcada STUCK.")
            flagged += 1
    print(f"OK watchdog: {flagged} tareas marcadas STUCK")


# --------------------------------------------------------------- aprobaciones ---
def _toml(v) -> str:
    return json.dumps(v, ensure_ascii=False)


def cmd_approval(env: Env, a) -> None:
    d = env.p / "state" / "approvals"
    d.mkdir(parents=True, exist_ok=True)
    if a.action == "new":
        max_h = float(env.system.get("comunista", {}).get("max_hours", 8))
        hours = min(float(a.hours), max_h)
        if not a.task or not a.purpose:
            raise CliError("approval new requiere --task y --purpose")
        if a.paths:
            _validate_paths(env, a.paths)
        aid = new_id("APR-", "owner")
        start = core.now()
        exp = start.timestamp() + hours * 3600
        import datetime as _d
        expires = _d.datetime.fromtimestamp(exp, _d.timezone.utc).replace(microsecond=0).isoformat()
        body = "\n".join([
            "# Autorización Comunista — creada por el PROPIETARIO (ningún agente puede escribir aquí)",
            "[approval]",
            f"approval_id = {_toml(aid)}", f"task_id = {_toml(a.task)}", f"role = {_toml(a.role)}",
            'status = "APPROVED"', 'approved_by = "project_owner"', f"purpose = {_toml(a.purpose)}",
            f"valid_from = {_toml(start.isoformat())}", f"expires_at = {_toml(expires)}",
            f"risk_assessment = {_toml(a.risk or '')}", f"rollback = {_toml(a.rollback or '')}",
            f"required_reviews = {_toml(a.review or [core.QA])}", "",
            "[approval.scope]",
            f"paths = {_toml(a.paths or [])}", f"dependencies = {_toml(a.deps or [])}",
            f"commands_regex = {_toml(a.commands or [])}",
            "# Nunca desbloquea: rutas protegidas, secretos, comandos prohibidos, autoaprobación ni merge sin PASS.",
            ""])
        (d / f"{aid}.toml").write_text(body, encoding="utf-8")
        env.event(action="approval.new", approval_id=aid, task=a.task, role=a.role, hours=hours)
        print(f"OK {aid} vigente hasta {expires} · {a.role} en {a.task}")
    elif a.action == "list":
        for f in sorted(d.glob("*.toml")):
            ap = core.load_toml(f).get("approval", {})
            print(f"{ap.get('approval_id')} {ap.get('status')} {ap.get('task_id')} {ap.get('role')} hasta {ap.get('expires_at')}")
    elif a.action == "revoke":
        f = d / f"{a.id}.toml"
        if not f.exists():
            raise CliError(f"no existe {a.id}")
        f.write_text(f.read_text(encoding="utf-8").replace('status = "APPROVED"', 'status = "REVOKED"'), encoding="utf-8")
        env.event(action="approval.revoke", approval_id=a.id)
        print(f"OK {a.id} revocada")


# ------------------------------------------------------- estado / verificación ---
def cmd_status(env: Env, a) -> None:
    print(f"Rol resuelto: {env.alias(env.role)} ({env.role}, {env.role_source}) · coordinación: {env.coord}")
    print("\nTAREAS")
    for t in core.all_tasks(env.coord):
        last = (t.get("results") or [{}])[-1]
        print(f"  {t['task_id']:<10} {t['status']:<12} {env.alias(t['owner_role']):<22} "
              f"último RESULT: {last.get('status', '-')} ({env.alias(last['by']) if last.get('by') else '-'})")
    print("\nBUZÓN (sin acusar)")
    for r in list(env.roles) + ["user"]:
        box = env.p / "mailbox" / ("user" if r == "user" else f"inbox/{r}")
        n = sum(1 for f in box.glob("*.json") if not _acked(env, f.stem)) if box.exists() else 0
        out = env.p / "mailbox" / "outbox" / r
        o = len(list(out.glob("*.json"))) if out.exists() else 0
        if n or o:
            print(f"  {env.alias(r) if r != 'user' else 'Usuario':<22} inbox {n} · outbox sin enrutar {o}")
    log = env.p / "log" / "events.jsonl"
    if log.exists():
        blocks = [json.loads(l) for l in log.read_text(encoding="utf-8").splitlines()[-400:]
                  if '"decision": "block"' in l]
        if blocks:
            print("\nÚLTIMOS BLOQUEOS DEL GUARD")
            for b in blocks[-5:]:
                print(f"  {b['ts']} {b.get('role')}: {b.get('reason', '')[:140]}")


def _run(cmd: list[str], cwd: Path) -> tuple[str, str]:
    if not shutil.which(cmd[0]):
        return "NOT_RUN", f"{cmd[0]} no instalado"
    cp = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, encoding="utf-8", errors="replace")
    return ("PASS" if cp.returncode == 0 else "FAIL"), (cp.stdout + cp.stderr).strip()[-1500:]


def cmd_verify(env: Env, a) -> None:
    root = env.root
    tools = root / ".csdd" / "tools"
    checks = [
        ("Controles constitucionales", [sys.executable, str(tools / "check_constitution_controls.py")]),
        ("Trazabilidad REQ→test", [sys.executable, str(tools / "check_traceability.py")] + ([] if a.strict else ["--warn-only"])),
        ("Semgrep (reglas CSDD)", ["semgrep", "--config", str(root / ".csdd" / "policy" / "semgrep" / "csdd-rules.yml"),
                                   "--error", "--quiet", "--exclude", ".csdd", "."]),
        ("Gitleaks", ["gitleaks", "detect", "--no-banner", "--redact", "--config", str(root / ".csdd" / "integrations" / "gitleaks" / "gitleaks.toml"), "--source", "."]),
    ]
    worst = 0
    for name, cmd in checks:
        state, out = _run(cmd, root) if cmd[0] != sys.executable else \
            (lambda cp: ("PASS" if cp.returncode == 0 else "FAIL", (cp.stdout + cp.stderr).strip()[-1500:]))(
                subprocess.run(cmd, cwd=str(root), capture_output=True, text=True, encoding="utf-8", errors="replace"))
        if state == "PASS" and "NOT_APPLICABLE" in out:
            state = "NOT_APPLICABLE"
        print(f"[{state}] {name}")
        if state != "PASS" and out:
            print("   " + out.replace("\n", "\n   ")[:1200])
        worst = max(worst, 1 if state == "FAIL" else 0)
    print("\nNOT_RUN no es PASS: instala la herramienta o deja que CI la ejecute.")
    sys.exit(worst)


def cmd_doctor(env: Env, a) -> None:
    ok = True

    def line(state, text):
        nonlocal ok
        ok = ok and state != "FAIL"
        print(f"[{state}] {text}")

    line("PASS" if sys.version_info >= (3, 11) else "FAIL", f"Python {sys.version.split()[0]} (mín. 3.11)")
    for rel in (".csdd/hooks/guard.py", ".csdd/config/roles.toml", ".csdd/config/constitution-controls.toml",
                "AGENTS.md", "CLAUDE.md", ".claude/settings.json", ".github/workflows/csdd-gate.yml"):
        line("PASS" if (env.root / rel).exists() else "FAIL", rel)
    s = env.root / ".claude" / "settings.json"
    if s.exists():
        line("PASS" if "guard.py" in s.read_text(encoding="utf-8") else "FAIL", "settings.json invoca guard.py")
    agents = list((env.root / ".claude" / "agents").glob("csdd-*.md"))
    line("PASS" if len(agents) >= 4 else "FAIL", f"subagentes Claude generados: {len(agents)}/4")
    hp = git(["config", "--get", "core.hooksPath"], env.root, check=False).stdout.strip()
    line("PASS" if hp == ".csdd/git-hooks" else "UNKNOWN", f"core.hooksPath = {hp or '(sin definir)'}")
    keys = env.p / "log" / "hook-payload-keys.jsonl"
    if keys.exists():
        rows = [json.loads(l) for l in keys.read_text(encoding="utf-8").splitlines() if l.strip()]
        has = any(set(r["keys"]) & {"agent_type", "subagent_type", "agent_name"} for r in rows)
        line("PASS" if has else "UNKNOWN",
             "el hook recibe identidad de subagente (Modo B disponible)" if has else
             "el hook NO recibe identidad de subagente: usa Modo A (una sesión por rol)")
    else:
        line("UNKNOWN", "aún no hay llamadas al hook registradas (abre Claude Code y ejecuta algo)")
    print(f"\nRol resuelto aquí: {env.alias(env.role)} ({env.role_source})")
    sys.exit(0 if ok else 1)


# ------------------------------------------------- sesión / estado / ruta ---
def cmd_estado(env: Env, a) -> None:
    text, alerts, _ = sesion.estado(env.root, env.coord, env.cfg, env.system)
    print(text)


def cmd_session(env: Env, a) -> None:
    s = sesion.cfg_session(env.system)
    if a.action == "start":
        text, alerts, info = sesion.estado(env.root, env.coord, env.cfg, env.system)
        print(text)
        if alerts and not a.acepto_alertas:
            print("\nDETENTE: hay ALERTAS. No se abre la sesión. Avisa al propietario; solo él puede abrirla con "
                  "--acepto-alertas después de revisarlas.", file=sys.stderr)
            sys.exit(3)
        wt = core.worktree_task(env.root)
        data = {"root": str(env.root), "role": env.role, "task": a.tarea or wt.get("task_id"),
                "tramo": a.tramo, "started_at": core.now_iso(),
                "start_head": git(["rev-parse", "HEAD"], env.root, check=False).stdout.strip(),
                "alerts": alerts, "alerts_acknowledged": bool(alerts and a.acepto_alertas),
                "dirty_at_start": len(info.get("dirty", [])), "closed": False}
        sesion.marker_write(env.coord, env.root, data)
        env.event(action="session.start", task=data["task"], tramo=a.tramo, dirty=data["dirty_at_start"], alerts=len(alerts))
        print(f"\nSESIÓN ABIERTA ({env.alias(env.role)}) · vence en {s['ttl_hours']} h")
        print("  1. Lee la salida de arriba: es la fuente del estado; no la copies a documentos.")
        print("  2. Declara tu tarea y, si es de la ruta crítica, el tramo (--tarea/--tramo).")
        if data["dirty_at_start"]:
            print("  3. AVISO: hay cambios sin commitear. Si no son tuyos, DETENTE y pregunta antes de tocar nada.")
    elif a.action == "status":
        m = sesion.active_session(env.coord, env.root, s["ttl_hours"])
        print(sesion.json_dump(m) if m else "Sin sesión vigente en este árbol de trabajo. Ejecuta: csdd.py session start")
    elif a.action == "end":
        m = sesion.active_session(env.coord, env.root, s["ttl_hours"])
        if not m:
            raise CliError("no hay sesión vigente en este árbol de trabajo (session start).")
        if a.horas is None:
            raise CliError("las horas se registran siempre: pasa --horas X. Si no las sabes, pregúntaselas al propietario "
                           "(«sin medir» no vale).")
        if not a.resultado:
            raise CliError("pasa --resultado completado|parcial|detenido")
        resultado, motivo = a.resultado, a.motivo or ""
        changed = sesion.code_changed(env.root, m.get("start_head", ""), s["code_globs"])
        verificado = a.verificado or ""
        if changed:
            if s["verify_command"]:
                ok, out = sesion.run_verify(env.root, s["verify_command"])
                verificado = f"{s['verify_command']} -> {'PASS' if ok else 'FAIL'}" + (f"; {verificado}" if verificado else "")
                if not ok:
                    print(out, file=sys.stderr)
                    if resultado == "completado":
                        resultado, motivo = "parcial", (motivo or f"{s['verify_command']} no pasa")
            elif not verificado:
                raise CliError("tocaste código y no hay verify_command configurado: declara --verificado con comando y salida.")
        _, alerts, _ = sesion.estado(env.root, env.coord, env.cfg, env.system)
        commits = git(["log", "--format=%h", f"{m.get('start_head')}..HEAD"], env.root, check=False).stdout.split() \
            if m.get("start_head") else []
        prev, _ = sesion.hours(env.coord / s["bitacora_file"], s["hours_since"])
        fields = {"tarea": a.tarea or m.get("task") or "sin-tarea", "quien": a.quien or env.alias(env.role),
                  "resultado": resultado, "motivo": motivo,
                  "commits": a.commits or (" ".join(commits[:8]) if commits else "ninguno"),
                  "verificado": verificado or "nada (no se tocó código)", "no_verificado": a.no_verificado or "nada",
                  "horas": a.horas, "acumulado": round(prev + a.horas, 2),
                  "seguimiento": a.seguimiento or "—", "pide": a.pide or "nada"}
        lines = sesion.write_block(env.coord, s, fields)
        m.update(closed=True, ended_at=core.now_iso(), resultado=resultado)
        sesion.marker_write(env.coord, env.root, m)
        env.event(action="session.end", task=fields["tarea"], resultado=resultado, horas=a.horas)
        print("\n".join(lines))
        print(f"\nSESIÓN CERRADA · bloque añadido a {s['bitacora_file']}")
        if alerts:
            print("ALERTA al cerrar: " + "; ".join(alerts))
        print(f"Pendiente: reescribe '## Qué sigue' en {s['siguiente_file']} (Jefe Maestro) y anota contradicciones "
              "en la lista de limpieza. Mensaje final al propietario: hecho, falta, qué necesita (máx. 5 líneas).")


def cmd_ruta(env: Env, a) -> None:
    s = sesion.cfg_session(env.system)
    plan = Path(a.plan) if a.plan else env.coord / env.system.get("critical_path", {}).get("plan_file", ".project/ruta-critica.toml")
    acc, _ = sesion.hours(env.coord / s["bitacora_file"], s["hours_since"])
    args = ["--plan", str(plan), "--horas-reales", str(acc)] + (["--out", a.out] if a.out else [])
    rc = ruta_critica.main(args)
    if rc:
        sys.exit(rc)


# ------------------------------------------------------------------- parser ---
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="csdd.py", description="CSDD Multi-Agent v0.4.2")
    p.add_argument("--as", dest="as_role", help="actuar como rol (el guard lo valida para agentes)")
    sp = p.add_subparsers(dest="cmd", required=True)
    sp.add_parser("init")

    t = sp.add_parser("task")
    t.add_argument("action", choices=["new", "show", "list", "start", "set-status", "cancel"])
    t.add_argument("id", nargs="?")
    t.add_argument("status", nargs="?")
    t.add_argument("--id", dest="id_opt")
    t.add_argument("--title")
    t.add_argument("--objective")
    t.add_argument("--role")
    t.add_argument("--runtime", default="any", choices=["any", "claude-code", "kimi-code"])
    t.add_argument("--paths", action="append")
    t.add_argument("--req", action="append")
    t.add_argument("--article", action="append")
    t.add_argument("--dep", action="append", help="dependencia autorizada (Art. I)")
    t.add_argument("--accept", action="append", help="criterio de aceptación")
    t.add_argument("--depends-on", action="append")
    t.add_argument("--verify-cmd", action="append")
    t.add_argument("--budget-calls", type=int)
    t.add_argument("--budget-minutes", type=int)
    t.add_argument("--retries", type=int)
    t.add_argument("--security", action="store_true", help="exige revisión de El Portero")
    t.add_argument("--no-qa", action="store_true")
    t.add_argument("--allow-overlap", action="store_true")

    w = sp.add_parser("worktree")
    w.add_argument("action", choices=["new", "review", "remove"])
    w.add_argument("id")
    w.add_argument("--base")
    w.add_argument("--dir")
    w.add_argument("--force", action="store_true")

    s = sp.add_parser("send")
    s.add_argument("--to", required=True)
    s.add_argument("--type", required=True, choices=MSG_TYPES)
    s.add_argument("--task")
    s.add_argument("--summary", required=True)
    s.add_argument("--ref", action="append")
    s.add_argument("--reply-to")
    s.add_argument("--needs-user", action="store_true")

    sp.add_parser("route")
    i = sp.add_parser("inbox")
    i.add_argument("--agent")
    i.add_argument("--all", action="store_true")
    k = sp.add_parser("ack")
    k.add_argument("message_id")
    k.add_argument("--done", action="store_true")

    h = sp.add_parser("handoff")
    h.add_argument("id")
    h.add_argument("--summary", required=True)
    h.add_argument("--ref", action="append")

    r = sp.add_parser("result")
    r.add_argument("id")
    r.add_argument("--status", required=True, choices=RESULT_STATES)
    r.add_argument("--summary", required=True)
    r.add_argument("--evidence", action="append")
    r.add_argument("--blocking", action="store_true")

    m = sp.add_parser("merge")
    m.add_argument("id")

    ap = sp.add_parser("approval", help="SOLO el propietario, en su terminal")
    ap.add_argument("action", choices=["new", "list", "revoke"])
    ap.add_argument("id", nargs="?")
    ap.add_argument("--task")
    ap.add_argument("--role", default=core.IMPL)
    ap.add_argument("--purpose")
    ap.add_argument("--paths", action="append")
    ap.add_argument("--deps", action="append")
    ap.add_argument("--commands", action="append", help="regex de comandos extra permitidos")
    ap.add_argument("--hours", default="4")
    ap.add_argument("--risk")
    ap.add_argument("--rollback")
    ap.add_argument("--review", action="append")

    sp.add_parser("watchdog")
    sp.add_parser("status")
    v = sp.add_parser("verify")
    v.add_argument("--strict", action="store_true")
    sp.add_parser("doctor")
    sp.add_parser("estado", help="estado calculado del repo (anti-retrabajo)")
    se = sp.add_parser("session", help="protocolo de sesión: start | end | status")
    se.add_argument("action", choices=["start", "end", "status"])
    se.add_argument("--tarea")
    se.add_argument("--tramo")
    se.add_argument("--acepto-alertas", action="store_true", help="SOLO el propietario")
    se.add_argument("--resultado", choices=["completado", "parcial", "detenido"])
    se.add_argument("--motivo")
    se.add_argument("--horas", type=float)
    se.add_argument("--quien")
    se.add_argument("--commits")
    se.add_argument("--verificado")
    se.add_argument("--no-verificado")
    se.add_argument("--seguimiento", help="p. ej. Notion: T-001 -> En revisión")
    se.add_argument("--pide", help="acción concreta que necesitas del propietario")
    ru = sp.add_parser("ruta", help="ruta crítica adaptable")
    ru.add_argument("--plan")
    ru.add_argument("--out")
    return p


def main(argv=None) -> int:
    core.ensure_utf8_stdio()
    a = build_parser().parse_args(core.decode_argv(sys.argv[1:]) if argv is None else argv)
    if a.cmd == "task" and getattr(a, "id_opt", None):
        a.id = a.id_opt
    try:
        env = Env(a.as_role)
        handler = {"init": cmd_init, "task": cmd_task, "worktree": cmd_worktree, "send": cmd_send,
                   "route": cmd_route, "inbox": cmd_inbox, "ack": cmd_ack, "handoff": cmd_handoff,
                   "result": cmd_result, "merge": cmd_merge, "approval": cmd_approval,
                   "watchdog": cmd_watchdog, "status": cmd_status, "verify": cmd_verify,
                   "doctor": cmd_doctor, "estado": cmd_estado, "session": cmd_session,
                   "ruta": cmd_ruta}[a.cmd]
        handler(env, a)
        return 0
    except CliError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    except FileNotFoundError as e:
        print(f"ERROR: falta un archivo del sistema ({e.filename}). ¿Ejecutaste el instalador?", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())

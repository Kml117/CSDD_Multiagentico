"""Estado calculado y protocolo de sesión anti-retrabajo (CSDD v0.4.1).

Generaliza scripts/estado.sh + PROTOCOLO-SESION.md de Corbeta (2-nov-2026):
  - El estado del repo se CALCULA; no se copia a ningún documento.
  - Toda sesión empieza con `session start` (estado + alertas) y termina con `session end`
    (verificación si se tocó código, estado otra vez, bloque de bitácora de máx. 10 líneas con horas).
  - El guard bloquea escrituras sin sesión vigente: por eso es un MUST operativo real.
Solo lee el repositorio, salvo: marcador de sesión (.project/state/sessions/) y bitácora.
"""
from __future__ import annotations

import hashlib
import json
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve()
sys.path.insert(0, str(HERE.parent.parent / "lib"))
sys.path.insert(0, str(HERE.parent))
import csdd_core as core  # noqa: E402

HOURS_RE = re.compile(r"^- Horas:\s*([0-9]+(?:[.,][0-9]+)?)", re.M)
BLOCK_RE = re.compile(r"^##\s+(\d{4}-\d{2}-\d{2})\b.*$", re.M)


def _git(args, cwd) -> str:
    cp = subprocess.run(["git", *args], cwd=str(cwd), capture_output=True, text=True, encoding="utf-8", errors="replace")
    return cp.stdout.strip() if cp.returncode == 0 else ""


def cfg_session(system: dict) -> dict:
    s = dict(system.get("session", {}))
    s.setdefault("required", False)
    s.setdefault("ttl_hours", 12)
    s.setdefault("base_branch", "main")
    s.setdefault("bitacora_file", "BITACORA.md")
    s.setdefault("siguiente_file", "SIGUIENTE-SESION.md")
    s.setdefault("bitacora_max_lines", 10)
    s.setdefault("private_paths", [])
    s.setdefault("private_allow", [])
    s.setdefault("migrations_globs", [])
    s.setdefault("stale_doc_globs", [])
    s.setdefault("stale_signals", [])
    s.setdefault("code_globs", [])
    s.setdefault("verify_command", "")
    s.setdefault("hours_since", "")
    return s


# --------------------------------------------------------------- marcador ---
def marker_path(coord: Path, root: Path) -> Path:
    key = hashlib.sha1(str(root.resolve()).encode()).hexdigest()[:12]
    return core.project_dir(coord) / "state" / "sessions" / f"{key}.json"


def active_session(coord: Path, root: Path, ttl_hours: float) -> dict | None:
    m = core.read_json(marker_path(coord, root))
    if not isinstance(m, dict) or m.get("closed"):
        return None
    try:
        age = (core.now() - core.parse_iso(m["started_at"])).total_seconds() / 3600
    except (KeyError, ValueError):
        return None
    return m if age <= float(ttl_hours) else None


# ---------------------------------------------------------------- bitácora ---
def hours(bitacora: Path, since: str = "") -> tuple[float, int]:
    if not bitacora.exists():
        return 0.0, 0
    text = bitacora.read_text(encoding="utf-8")
    heads = list(BLOCK_RE.finditer(text))
    total, n = 0.0, 0
    if not heads:
        for m in HOURS_RE.finditer(text):
            total += float(m.group(1).replace(",", "."))
            n += 1
        return total, n
    for i, h in enumerate(heads):
        if since and h.group(1) < since:
            continue
        end = heads[i + 1].start() if i + 1 < len(heads) else len(text)
        m = HOURS_RE.search(text, h.start(), end)
        if m:
            total += float(m.group(1).replace(",", "."))
            n += 1
    return total, n


def last_block(bitacora: Path) -> tuple[str, int, bool] | None:
    if not bitacora.exists():
        return None
    lines = bitacora.read_text(encoding="utf-8").splitlines()
    idx = [i for i, l in enumerate(lines) if re.match(r"^#{2,3} ", l)]
    if not idx:
        return None
    blk = lines[idx[-1]:]
    while blk and not blk[-1].strip():
        blk.pop()
    return blk[0], len(blk), any(HOURS_RE.match(l) for l in blk)


# ------------------------------------------------------------------ estado ---
def estado(root: Path, coord: Path, cfg_roles: dict, system: dict) -> tuple[str, list[str], dict]:
    s = cfg_session(system)
    out, alerts, info = [], [], {}

    def sec(t):
        out.append(f"\n== {t} ==")

    def lin(t):
        out.append(f"  {t}")

    sec("Repo")
    lin(f"Fecha: {core.now().astimezone().strftime('%Y-%m-%d %H:%M %z')}")
    lin(f"Raíz: {root}  (coordinación: {coord})")
    lin(f"Rama actual: {_git(['branch', '--show-current'], root) or '(detached)'}")
    lin(f"HEAD: {_git(['log', '-1', '--format=%h %s'], root) or '(sin commits)'}")
    porcelain = [l for l in _git(["status", "--porcelain"], root).splitlines() if not l.endswith(core.TASK_FILE)]
    info["dirty"] = porcelain
    if not porcelain:
        lin("Árbol de trabajo limpio")
    else:
        lin(f"AVISO: {len(porcelain)} archivos sin commitear (si no son tuyos, detente y pregunta):")
        out += [f"    {l}" for l in porcelain[:20]]

    base = s["base_branch"]
    sec(f"{base} remoto (origin/{base}, según el último git fetch)")
    if _git(["rev-parse", "--verify", "-q", f"origin/{base}"], root):
        lin("Últimos 5 commits · firma: G = válida, N = sin firma, otro = no verificable aquí")
        out += [f"    {l}" for l in _git(["log", f"origin/{base}", "-5", "--format=%h %G? %ad %s", "--date=short"], root).splitlines()]
        lin(f"La rama actual va {_git(['rev-list', '--count', f'HEAD..origin/{base}'], root) or '?'} commits detrás de origin/{base}")
    else:
        lin(f"origin/{base} no disponible: ejecuta git fetch (NO VERIFICADO)")

    sec("Pull requests abiertos y CI")
    gh_ok = shutil.which("gh") and subprocess.run(["gh", "auth", "status"], capture_output=True).returncode == 0
    if gh_ok:
        prs = subprocess.run(["gh", "pr", "list", "--state", "open", "--limit", "30", "--json", "number,title,isDraft,headRefName",
                              "--jq", '.[] | "#\\(.number) \\(if .isDraft then "[borrador] " else "" end)\\(.title) (\\(.headRefName))"'],
                             cwd=str(root), capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip()
        out += [f"    {l}" for l in prs.splitlines()] if prs else ["  Ninguno abierto"]
        ci = subprocess.run(["gh", "run", "list", "--branch", base, "--limit", "1", "--json", "conclusion,status,headSha",
                             "--jq", '.[0] | "\\(.status) / \\(.conclusion) en \\(.headSha[0:7])"'],
                            cwd=str(root), capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip()
        lin(f"Último CI en {base}: {ci or 'sin datos'}")
    else:
        lin("NO VERIFICADO: gh no está instalado o sin sesión (gh auth status)")

    sec("Tareas y worktrees CSDD")
    tasks = core.all_tasks(coord)
    if tasks:
        for t in tasks:
            if t.get("status") not in ("DONE", "CANCELLED"):
                last = (t.get("results") or [{}])[-1].get("status", "-")
                lin(f"{t['task_id']:<10} {t['status']:<12} {t['owner_role']:<30} último RESULT: {last}")
    else:
        lin("Sin tareas registradas")
    wts = _git(["worktree", "list"], root).splitlines()
    if len(wts) > 1:
        lin(f"{len(wts)} worktrees (un agente por árbol de trabajo):")
        out += [f"    {l}" for l in wts]

    sec("Migraciones en esta rama")
    migs = sorted({p.relative_to(root).as_posix() for g in s["migrations_globs"] for p in root.glob(g)})
    if migs:
        out += [f"    {m}" for m in migs[-15:]]
        lin("Que una migración esté en el repo NO significa que esté aplicada. Compruébalo en la base antes de afirmarlo.")
    else:
        lin("Ninguna (o migrations_globs no coincide con tu stack)")

    sec("Archivos rastreados que no deberían estar en git")
    tracked = _git(["ls-files"], root).splitlines()
    d = cfg_roles.get("defaults", {})
    bad_pats = d.get("secret_paths", []) + s["private_paths"]
    ok_pats = d.get("secret_allow", []) + s["private_allow"]
    bad = [f for f in tracked if core.match_any(f, bad_pats) and not core.match_any(f, ok_pats)]
    if bad:
        alerts.append(f"{len(bad)} archivos sensibles/privados rastreados en git")
        lin("ALERTA, detén la sesión y avisa al propietario:")
        out += [f"    {f}" for f in bad[:20]]
    else:
        lin("Ninguno")

    sec("Documentos posiblemente desfasados (van a la lista de limpieza; no se corrigen sobre la marcha)")
    if s["stale_signals"]:
        rx = re.compile("|".join(f"(?:{x})" for x in s["stale_signals"]))
        hits = []
        for g in s["stale_doc_globs"]:
            for p in sorted(root.glob(g)):
                if p.is_file() and ".csdd" not in p.parts:
                    for i, l in enumerate(p.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                        if rx.search(l):
                            hits.append(f"{p.relative_to(root).as_posix()}:{i}: {l.strip()[:100]}")
        hits = sorted(set(hits))
        lin(f"{len(hits)} líneas con señales. Pueden ser citas históricas. Primeras 10:")
        out += [f"    {h}" for h in hits[:10]]
    else:
        lin("Sin señales configuradas ([session] stale_signals en .csdd/config/system.toml)")

    sec(f"Bitácora ({s['bitacora_file']})")
    bit = coord / s["bitacora_file"]
    lb = last_block(bit)
    if lb:
        title, length, has_h = lb
        lin(f"Último bloque: {title}")
        lin(f"Largo: {length} líneas")
        if length > int(s["bitacora_max_lines"]) + 2:
            lin(f"AVISO: supera el tope de {s['bitacora_max_lines']} líneas")
        if not has_h:
            lin("AVISO: el último bloque no registra horas. Pregúntaselas al propietario.")
    elif bit.exists():
        lin("Sin bloques todavía")
    else:
        lin(f"No existe {s['bitacora_file']} (se crea con el primer session end)")
    acc, n = hours(bit, s["hours_since"])
    info["hours"] = acc
    lin(f"Horas registradas: {acc:.1f} h en {n} sesiones" + (f" (desde {s['hours_since']})" if s["hours_since"] else ""))

    plan = coord / system.get("critical_path", {}).get("plan_file", ".project/ruta-critica.toml")
    sec("Ruta crítica (semáforo)")
    if plan.exists():
        try:
            import ruta_critica as rc
            r = rc.compute(rc.load_plan(plan), acc)
            lin(f"Fin con tus horas: {r['fin_recurso']} · cota inferior: {r['fin_cpm']}")
            for h in r["hitos"]:
                if "semaforo" in h:
                    lin(f"{h['id']} ({h['nombre']}): {h['semaforo']}")
            for k, real, te in r["desvios"]:
                lin(f"RECALCULAR: {k} lleva {real:g} h de {te:.1f} h estimadas (> {(r['ratio'] - 1) * 100:.0f} %)")
            for w in r["cola_reloj"]:
                lin(f"AVISO: espera de {(w['hasta'] - w['desde']) / 7:.1f} semanas por {', '.join(w['por'])}; arranca antes esa cadena")
        except Exception as e:  # noqa: BLE001 — el estado nunca debe caerse por el plan
            lin(f"Plan inválido: {e}")
    else:
        lin(f"Sin plan ({plan.relative_to(coord).as_posix()}). Ver la referencia ruta-critica.md del orquestador.")

    sec(f"Qué sigue ({s['siguiente_file']})")
    sig = coord / s["siguiente_file"]
    if sig.exists():
        txt = sig.read_text(encoding="utf-8").splitlines()
        start = next((i for i, l in enumerate(txt) if l.startswith("## Qué sigue")), None)
        if start is not None:
            body = []
            for l in txt[start + 1:]:
                if l.startswith("## "):
                    break
                body.append(l)
            out += [f"    {l}" for l in body[:14]]
        else:
            lin("Sin sección '## Qué sigue'")
    else:
        lin(f"No existe {s['siguiente_file']}")
    out.append("\nFin. Este resumen es la fuente del estado del repo: no lo copies a otros documentos.")
    return "\n".join(out), alerts, info


# ---------------------------------------------------------------- sesión ---
def code_changed(root: Path, start_head: str, globs: list[str]) -> list[str]:
    files = set()
    if start_head:
        files |= set(_git(["diff", "--name-only", f"{start_head}..HEAD"], root).split())
    for l in _git(["status", "--porcelain"], root).splitlines():
        if l[3:]:
            files.add(l[3:].split(" -> ")[-1])
    return sorted(f for f in files if globs and core.match_any(f, globs))


def write_block(coord: Path, s: dict, fields: dict) -> list[str]:
    lines = [f"## {core.now().astimezone().strftime('%Y-%m-%d')} · {fields['tarea']} · {fields['quien']}",
             f"- Resultado: {fields['resultado']}" + (f" ({fields['motivo']})" if fields.get("motivo") else ""),
             f"- PR y commits: {fields['commits']}",
             f"- Verificado: {fields['verificado']}",
             f"- No verificado: {fields['no_verificado']}",
             f"- Horas: {fields['horas']:g} (sesión del propietario) · Acumulado: {fields['acumulado']:g}",
             f"- Seguimiento: {fields['seguimiento']}",
             f"- Pide al propietario: {fields['pide']}"]
    lines = [core.redact(l.replace("\n", " "), 240) for l in lines]
    if len(lines) > int(s["bitacora_max_lines"]):
        raise ValueError("el bloque supera el tope de líneas")
    bit = coord / s["bitacora_file"]
    if not bit.exists():
        bit.write_text("# Bitácora de sesiones\n\nUn bloque de máximo 10 líneas por sesión. Lo escribe `csdd.py session end`.\n",
                       encoding="utf-8")
    with open(bit, "a", encoding="utf-8") as fh:
        fh.write("\n" + "\n".join(lines) + "\n")
    return lines


def run_verify(root: Path, command: str) -> tuple[bool, str]:
    try:
        cp = subprocess.run(shlex.split(command), cwd=str(root), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=1800)
    except (OSError, subprocess.SubprocessError) as e:
        return False, str(e)
    return cp.returncode == 0, (cp.stdout + cp.stderr)[-800:]


def marker_write(coord: Path, root: Path, data: dict) -> None:
    core.write_json_atomic(marker_path(coord, root), data)


def json_dump(x) -> str:
    return json.dumps(x, ensure_ascii=False, indent=2, default=str)

#!/usr/bin/env python3
"""Verifica que la constitución 'muerde': cada MUST tiene control automatizado o justificación.

Lee .csdd/config/constitution-controls.toml. Comprueba además que las reglas Semgrep
citadas existan en el archivo de reglas. Imprime el % de MUST automatizados.
Salida: 0 = conforme · 1 = hay MUST sin control ni justificación o reglas inexistentes.
"""
from __future__ import annotations

import re
import sys
import tomllib
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):  # UTF-8 también en consolas heredadas (Windows) o LANG=C
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError, OSError):
        pass


def main(argv: list[str]) -> int:
    root = Path(argv[1]).resolve() if len(argv) > 1 else Path.cwd()
    cfg_path = root / ".csdd" / "config" / "constitution-controls.toml"
    if not cfg_path.exists():
        print(f"FAIL: no existe {cfg_path}")
        return 1
    cfg = tomllib.loads(cfg_path.read_text(encoding="utf-8"))
    rules_file = root / cfg.get("semgrep_rules_file", ".csdd/policy/semgrep/csdd-rules.yml")
    rule_ids = set(re.findall(r"^\s*-\s*id:\s*(\S+)", rules_file.read_text(encoding="utf-8"), re.M)) \
        if rules_file.exists() else set()
    errors, must_total, must_auto = [], 0, 0
    print(f"{'Art.':<5} {'Nivel':<7} {'Auto':>4} {'Manual':>6}  Título")
    for art, data in cfg.get("articles", {}).items():
        level = data.get("level", "?")
        controls = data.get("controls", [])
        auto = [c for c in controls if c.get("automated")]
        manual = [c for c in controls if not c.get("automated")]
        print(f"{art:<5} {level:<7} {len(auto):>4} {len(manual):>6}  {data.get('title', '')}")
        for c in controls:
            if c.get("tool") == "semgrep" and c.get("id") not in rule_ids:
                errors.append(f"Art. {art}: la regla Semgrep '{c.get('id')}' no existe en {rules_file.name}")
        if level == "MUST":
            must_total += 1
            if auto:
                must_auto += 1
            elif not data.get("manual_justification"):
                errors.append(f"Art. {art} es MUST y no tiene control automatizado ni manual_justification")
        if level not in ("MUST", "SHOULD", "MAY"):
            errors.append(f"Art. {art}: nivel inválido '{level}'")
    pct = (100 * must_auto / must_total) if must_total else 100.0
    print(f"\nMUST con al menos un control automatizado: {must_auto}/{must_total} ({pct:.0f} %)")
    if errors:
        print("\nFAIL")
        for e in errors:
            print(f"  - {e}")
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

#!/usr/bin/env python3
"""Ruta crítica adaptable (CSDD v0.4.1) — solo librería estándar, Python 3.11+.

Generaliza la práctica de Corbeta (RUTA-CRITICA.md v1.1, nov-2026):
  1. Las horas del propietario son el recurso que limita: reordenar no acorta el trabajo.
  2. Lo que hace perder semanas son las ESPERAS DE CALENDARIO (relojes) que no consumen horas;
     si quedan al final, se suman al final. Hay que arrancarlas temprano.
  3. Se ejecuta por tramos, cada uno cerrado con un bloque corto de deuda.

Calcula, a partir de .project/ruta-critica.toml:
  A. CPM sin límite de horas (cota inferior) con holguras y ruta crítica por dependencias.
  B. Programa con UN recurso de H h/semana en el orden del archivo (list scheduling),
     relojes en paralelo, esperas sin trabajo disponible y fecha de fin.
  C. Hitos: fecha límite, horas disponibles, umbrales del semáforo y probabilidad PERT.
  D. Desvíos (> overrun_ratio) que obligan a recalcular, y horizonte rodante para enfoques adaptativos.

Uso: python .csdd/tools/ruta_critica.py [--plan .project/ruta-critica.toml] [--out archivo.md] [--horas-reales X]
"""
from __future__ import annotations

import argparse
import datetime as dt
import math
import sys
import tomllib
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):  # UTF-8 también en consolas heredadas (Windows) o LANG=C
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError, OSError):
        pass

EPS = 1e-9
MODOS = {
    "predictivo": "Ruta completa con línea base. Se recalcula en cada gate de fase y cuando una tarea se desvía.",
    "iterativo": "Ruta por iteración: detalle solo de la iteración en curso; el resto, como bloques estimados.",
    "incremental": "Ruta por incremento entregable; cada incremento cierra con su bloque de deuda.",
    "adaptativo": "Ruta rodante: detalle solo dentro del horizonte; fuera de él, backlog priorizado con horas gruesas. Lo crítico son relojes y dependencias externas.",
    "hibrido": "CPM con línea base para lo estable + ruta rodante para lo incierto; los relojes mandan el orden.",
}


class PlanError(Exception):
    pass


def _date(v) -> dt.date:
    if isinstance(v, dt.date):
        return v
    return dt.date.fromisoformat(str(v))


def load_plan(path: Path) -> dict:
    if not path.exists():
        raise PlanError(f"no existe {path}. Copia .csdd/templates/ruta-critica.toml y complétalo.")
    return tomllib.loads(path.read_text(encoding="utf-8"))


def te_var(t: dict) -> tuple[float, float]:
    if all(k in t for k in ("o", "m", "p")):
        o, m, p = float(t["o"]), float(t["m"]), float(t["p"])
        if not o <= m <= p:
            raise PlanError(f"{t['id']}: se requiere o <= m <= p")
        return (o + 4 * m + p) / 6, ((p - o) / 6) ** 2
    if "horas" in t:
        return float(t["horas"]), 0.0
    raise PlanError(f"{t.get('id')}: falta 'horas' o el trío o/m/p")


def remaining(t: dict, te: float) -> float:
    estado = t.get("estado", "pendiente")
    if estado == "hecha":
        return 0.0
    if "restante" in t:
        return max(float(t["restante"]), 0.0)
    if estado == "en_curso":
        return max(te - float(t.get("horas_reales", 0)), 0.0)
    return te


def compute(plan: dict, horas_reales_acumuladas: float | None = None) -> dict:
    pj = plan.get("proyecto", {})
    H = float(pj.get("horas_por_semana", 0))
    if H <= 0:
        raise PlanError("proyecto.horas_por_semana debe ser > 0")
    inicio = _date(pj.get("calculo_desde") or pj.get("inicio") or dt.date.today())
    ratio = float(pj.get("umbral_desvio", 1.5))
    horizonte = float(pj.get("horizonte_semanas", 0) or 0)
    ciclo = str(pj.get("ciclo_de_vida", "predictivo")).lower().replace("í", "i")
    d_per_h = 7.0 / H

    tasks = plan.get("tarea", [])
    clocks = plan.get("reloj", [])
    ids = [t["id"] for t in tasks] + [c["id"] for c in clocks]
    if len(ids) != len(set(ids)):
        raise PlanError("ids duplicados entre tareas y relojes")
    known = set(ids)
    info, warnings = {}, []
    for t in tasks:
        te, var = te_var(t)
        rem = remaining(t, te)
        info[t["id"]] = {"kind": "tarea", "nombre": t.get("nombre", t["id"]), "te": te, "var": var, "rem": rem,
                         "pred": list(t.get("pred", [])), "tramo": t.get("tramo", "-"),
                         "estado": t.get("estado", "pendiente"), "horas_reales": float(t.get("horas_reales", 0))}
    for c in clocks:
        info[c["id"]] = {"kind": "reloj", "nombre": c.get("nombre", c["id"]), "dias": float(c["dias"]),
                         "pred": list(c.get("pred", [])), "tramo": c.get("tramo", "-"), "estado": c.get("estado", "pendiente")}
    for k, v in info.items():
        for p in v["pred"]:
            if p not in known:
                raise PlanError(f"{k}: predecesora desconocida '{p}'")

    # orden topológico (detecta ciclos)
    indeg = {k: 0 for k in info}
    succ = {k: [] for k in info}
    for k, v in info.items():
        for p in v["pred"]:
            indeg[k] += 1
            succ[p].append(k)
    queue = [k for k in ids if indeg[k] == 0]
    topo = []
    while queue:
        n = queue.pop(0)
        topo.append(n)
        for s in succ[n]:
            indeg[s] -= 1
            if indeg[s] == 0:
                queue.append(s)
    if len(topo) != len(info):
        raise PlanError(f"hay un ciclo de dependencias entre: {sorted(set(info) - set(topo))}")

    def dur(k):
        v = info[k]
        if v["kind"] == "reloj":
            return 0.0 if v["estado"] == "hecha" else v["dias"]
        return v["rem"] * d_per_h

    # ---- A. CPM sin límite de horas (cota inferior)
    es, ef = {}, {}
    for k in topo:
        es[k] = max((ef[p] for p in info[k]["pred"]), default=0.0)
        ef[k] = es[k] + dur(k)
    end_cpm = max(ef.values(), default=0.0)
    lf, ls = {}, {}
    for k in reversed(topo):
        lf[k] = min((ls[s] for s in succ[k]), default=end_cpm)
        ls[k] = lf[k] - dur(k)
    slack = {k: ls[k] - es[k] for k in info}
    critical = [k for k in topo if slack[k] < 1e-6 and dur(k) > EPS]

    # ---- B. Un recurso (el propietario), orden del archivo, relojes en paralelo
    finish = {k: 0.0 for k, v in info.items() if (v["kind"] == "tarea" and v["rem"] <= EPS) or
              (v["kind"] == "reloj" and v["estado"] == "hecha")}
    start = {}
    pending = [t["id"] for t in tasks if info[t["id"]]["rem"] > EPS]
    pending_clocks = [c["id"] for c in clocks if c["id"] not in finish]
    t_now, idle, busy_hours = 0.0, [], 0.0
    cum_hours = {}

    def settle_clocks():
        changed = True
        while changed:
            changed = False
            for c in list(pending_clocks):
                if all(p in finish for p in info[c]["pred"]):
                    start[c] = max((finish[p] for p in info[c]["pred"]), default=0.0)
                    finish[c] = start[c] + info[c]["dias"]
                    pending_clocks.remove(c)
                    changed = True

    while pending:
        settle_clocks()
        ready = [k for k in pending if all(p in finish and finish[p] <= t_now + EPS for p in info[k]["pred"])]
        if ready:
            k = ready[0]
            start[k] = t_now
            finish[k] = t_now + dur(k)
            busy_hours += info[k]["rem"]
            cum_hours[k] = busy_hours
            t_now = finish[k]
            pending.remove(k)
            continue
        nxt = [max(finish[p] for p in info[k]["pred"]) for k in pending
               if all(p in finish for p in info[k]["pred"])]
        if not nxt:
            raise PlanError("ninguna tarea pendiente puede empezar: revisa predecesoras y relojes")
        target = min(nxt)
        blockers = sorted({p for k in pending for p in info[k]["pred"]
                           if p in finish and abs(finish[p] - target) < 1e-6 and info[p]["kind"] == "reloj"})
        idle.append({"desde": t_now, "hasta": target, "por": blockers})
        t_now = target
    settle_clocks()
    end_res = max(finish.values(), default=0.0)
    last_work = max((finish[k] for k in info if info[k]["kind"] == "tarea" and k in start), default=0.0)

    def day(x):
        return inicio + dt.timedelta(days=round(x))

    tramos = {}
    for k in start:
        tr = info[k]["tramo"]
        tramos.setdefault(tr, {"inicio": start[k], "fin": finish[k], "horas": 0.0, "tareas": []})
        tramos[tr]["inicio"] = min(tramos[tr]["inicio"], start[k])
        tramos[tr]["fin"] = max(tramos[tr]["fin"], finish[k])
        if info[k]["kind"] == "tarea":
            tramos[tr]["horas"] += info[k]["rem"]
        tramos[tr]["tareas"].append(k)

    # ---- C. Hitos
    hitos = []
    for h in plan.get("hito", []):
        hid = h["id"]
        if hid not in info:
            raise PlanError(f"hito sobre id desconocido: {hid}")
        done = info[hid]["estado"] == "hecha"
        fin = finish.get(hid, 0.0)
        r = {"id": hid, "nombre": h.get("nombre", info[hid]["nombre"]), "hecho": done, "fin_plan": day(fin)}
        if "fecha_limite" in h:
            lim = _date(h["fecha_limite"])
            weeks = (lim - inicio).days / 7.0
            disponibles = max(weeks * H, 0.0)
            ref = hid if info[hid]["kind"] == "tarea" else next((p for p in info[hid]["pred"] if info[p]["kind"] == "tarea"), hid)
            chain = tramos.get(info[ref]["tramo"], {}).get("horas", 0.0) if ref in info else 0.0
            rojo = float(h.get("rojo_horas", disponibles))
            amarillo = float(h.get("amarillo_horas", max(rojo - chain, 0.0)))
            mean = cum_hours.get(ref, 0.0)
            var = sum(info[k]["var"] for k in cum_hours if cum_hours[k] <= mean + EPS)
            prob = None
            if var > EPS:
                z = (disponibles - mean) / math.sqrt(var)
                prob = 0.5 * (1 + math.erf(z / math.sqrt(2)))
            r.update(fecha_limite=lim, holgura_dias=(lim - day(fin)).days, horas_disponibles=disponibles,
                     horas_planeadas=mean, amarillo=amarillo, rojo=rojo, prob=prob,
                     ultimo_inicio_cadena=day(max(0.0, (lim - inicio).days - chain * d_per_h)) if chain else None)
            if horas_reales_acumuladas is not None:
                acc = horas_reales_acumuladas
                r["semaforo"] = ("VERDE (hito cumplido)" if done else
                                 f"VERDE (≤ {amarillo:.0f} h)" if acc <= amarillo else
                                 f"AMARILLO ({amarillo:.0f}–{rojo:.0f} h: sube la cadena del hito de prioridad)" if acc <= rojo else
                                 f"ROJO (> {rojo:.0f} h sin el hito: la fecha final se mueve, recalcula)")
        hitos.append(r)

    # ---- D. Desvíos y horizonte
    desvios = [(k, v["horas_reales"], v["te"]) for k, v in info.items()
               if v["kind"] == "tarea" and v["horas_reales"] > ratio * v["te"] + EPS]
    if ciclo in ("adaptativo",) and not horizonte:
        warnings.append("Ciclo adaptativo sin horizonte_semanas: usa 4–6 semanas de detalle y backlog para el resto.")
    fuera = []
    if horizonte:
        lim_h = horizonte * 7
        fuera = [k for k in start if info[k]["kind"] == "tarea" and start[k] > lim_h]
    tail = [w for w in idle if w["por"]]
    return {
        "proyecto": pj.get("nombre", "proyecto"), "inicio": inicio, "H": H, "ciclo": ciclo,
        "modo": MODOS.get(ciclo, MODOS["predictivo"]), "enfoque": pj.get("enfoque", "-"),
        "horas_pendientes": sum(v["rem"] for v in info.values() if v["kind"] == "tarea"),
        "fin_cpm": day(end_cpm), "critica": critical, "slack": slack, "es": es, "ef": ef,
        "fin_recurso": day(end_res), "ultimo_trabajo": day(last_work), "start": start, "finish": finish,
        "info": info, "tramos": tramos, "idle": idle, "cola_reloj": tail, "hitos": hitos,
        "desvios": desvios, "fuera_horizonte": fuera, "horizonte": horizonte, "warnings": warnings,
        "day": day, "ratio": ratio,
    }


def render(r: dict) -> str:
    day, info = r["day"], r["info"]
    L = [f"# Ruta crítica · {r['proyecto']} (cálculo automático)", "",
         f"- Calculado desde: **{r['inicio'].isoformat()}** · Recurso limitante: **{r['H']:g} h/semana** · "
         f"Ciclo de vida: **{r['ciclo']}** · Enfoque: **{r['enfoque']}**",
         f"- Modo de ruta: {r['modo']}",
         f"- Horas pendientes: **{r['horas_pendientes']:.1f} h** ≈ {r['horas_pendientes'] / r['H']:.1f} semanas de trabajo", ""]
    for w in r["warnings"]:
        L.append(f"> AVISO: {w}")
    L += ["## 1. Fechas de fin", "",
          "| Escenario | Fin | Nota |", "|---|---|---|",
          f"| Con tus horas como límite (orden del archivo) | **{r['fin_recurso'].isoformat()}** | Último trabajo: {r['ultimo_trabajo'].isoformat()} |",
          f"| Cota inferior (sin límite de horas, solo dependencias) | {r['fin_cpm'].isoformat()} | Solo si hubiera más horas por semana |", ""]
    if r["critica"]:
        L += ["**Ruta crítica en dependencias puras:** `" + " → ".join(r["critica"]) + "`", ""]
    if r["cola_reloj"]:
        L += ["## 2. Esperas de calendario que frenan el trabajo", ""]
        for w in r["cola_reloj"]:
            L.append(f"- {day(w['desde']).isoformat()} → {day(w['hasta']).isoformat()} "
                     f"({(w['hasta'] - w['desde']) / 7:.1f} semanas) esperando a {', '.join(w['por'])}. "
                     "**Arranca antes la cadena que dispara ese reloj** o llena la espera con tareas independientes.")
        L.append("")
    relojes = [k for k, v in info.items() if v["kind"] == "reloj"]
    if relojes:
        L += ["## 3. Relojes (no consumen horas)", "", "| Reloj | Arranca | Termina | Días |", "|---|---|---|---|"]
        for k in relojes:
            s = r["start"].get(k)
            L.append(f"| {k} · {info[k]['nombre']} | {day(s).isoformat() if s is not None else 'hecho'} | "
                     f"{day(r['finish'][k]).isoformat() if k in r['finish'] else '-'} | {info[k]['dias']:g} |")
        L.append("")
    L += ["## 4. Tramos", "", "| Tramo | Horas | Empieza | Termina | Tareas |", "|---|---|---|---|---|"]
    for tr, v in sorted(r["tramos"].items(), key=lambda x: x[1]["inicio"]):
        L.append(f"| {tr} | {v['horas']:.1f} | {day(v['inicio']).isoformat()} | {day(v['fin']).isoformat()} | {', '.join(v['tareas'])} |")
    L += ["", "Cada tramo cierra con un bloque de deuda (tope: 2 ítems de 1 h). Lo que no cabe se agenda como tarea.", ""]
    if r["hitos"]:
        L += ["## 5. Hitos y semáforo", "",
              "| Hito | Fin plan | Fecha límite | Holgura | Horas disponibles | Planeadas | Amarillo | Rojo | P(cumplir) | Semáforo |",
              "|---|---|---|---|---|---|---|---|---|---|"]
        for h in r["hitos"]:
            if "fecha_limite" in h:
                p = f"{100 * h['prob']:.0f} %" if h["prob"] is not None else "n/d (sin o/m/p)"
                L.append(f"| {h['id']} · {h['nombre']} | {h['fin_plan'].isoformat()} | {h['fecha_limite'].isoformat()} | "
                         f"{h['holgura_dias']} d | {h['horas_disponibles']:.0f} h | {h['horas_planeadas']:.0f} h | "
                         f"{h['amarillo']:.0f} h | {h['rojo']:.0f} h | {p} | {h.get('semaforo', '—')} |")
            else:
                L.append(f"| {h['id']} · {h['nombre']} | {h['fin_plan'].isoformat()} | — | — | — | — | — | — | — | — |")
        L.append("")
    if r["desvios"]:
        L += ["## 6. Recalcular YA (desvío > " f"{(r['ratio'] - 1) * 100:.0f} %)", ""]
        for k, real, te in r["desvios"]:
            L.append(f"- {k}: {real:g} h reales vs {te:.1f} h estimadas")
        L.append("")
    if r["horizonte"]:
        L += [f"## 7. Horizonte rodante ({r['horizonte']:g} semanas)", "",
              f"Fuera del horizonte: {len(r['fuera_horizonte'])} tareas · "
              f"{sum(info[k]['rem'] for k in r['fuera_horizonte']):.1f} h. Sus fechas son orientativas; se detallan al acercarse.", ""]
    L += ["## Holguras (CPM)", "", "| Id | Tipo | Duración (días) | Inicio temprano | Holgura (días) |", "|---|---|---|---|---|"]
    for k in sorted(info, key=lambda x: r["es"][x]):
        dd = r["ef"][k] - r["es"][k]
        if dd > EPS:
            L.append(f"| {k} | {info[k]['kind']} | {dd:.1f} | {day(r['es'][k]).isoformat()} | {r['slack'][k]:.1f} |")
    L += ["", "_Cálculo automático: no lo edites a mano. Las decisiones, supuestos y entradas del propietario viven en RUTA-CRITICA.md._"]
    return "\n".join(L) + "\n"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Ruta crítica adaptable CSDD")
    ap.add_argument("--plan", default=".project/ruta-critica.toml")
    ap.add_argument("--out")
    ap.add_argument("--horas-reales", type=float, help="horas reales acumuladas (para el semáforo)")
    a = ap.parse_args(argv)
    try:
        r = compute(load_plan(Path(a.plan)), a.horas_reales)
    except (PlanError, KeyError, ValueError, tomllib.TOMLDecodeError) as e:
        print(f"ERROR en el plan: {e}", file=sys.stderr)
        return 1
    text = render(r)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(text, encoding="utf-8")
        print(f"OK escrito {a.out} · fin con tus horas: {r['fin_recurso']} · cota inferior: {r['fin_cpm']}")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

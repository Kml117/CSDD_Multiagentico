#!/usr/bin/env python3
"""Trazabilidad REQ -> test (Art. II y IX).

Busca IDs de requisito (REQ-001, REQ-AUTH-02...) en specs y verifica que algún test
los cite (docstring, nombre o comentario). Reporta también tests que citan REQ inexistentes.
  --specs DIR   (por defecto: specs, docs/requirements)
  --tests DIR   (por defecto: tests, src, app)
  --warn-only   no falla, solo informa (útil al adoptar CSDD en un repo existente)
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):  # UTF-8 también en consolas heredadas (Windows) o LANG=C
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError, OSError):
        pass

REQ = re.compile(r"\bREQ-[A-Z0-9]+(?:-[A-Z0-9]+)*\b")
TEST_FILE = re.compile(r"(^test_.*\.py$|.*_test\.py$|.*\.(test|spec)\.(js|jsx|ts|tsx|mjs|cjs)$)")


def collect(dirs: list[Path], pred) -> dict[str, set[Path]]:
    found: dict[str, set[Path]] = {}
    for d in dirs:
        if not d.exists():
            continue
        for f in d.rglob("*"):
            if not f.is_file() or any(p in f.parts for p in ("node_modules", ".git", ".venv", "dist")):
                continue
            if not pred(f):
                continue
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for r in set(REQ.findall(text)):
                found.setdefault(r, set()).add(f)
    return found


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--specs", action="append")
    ap.add_argument("--tests", action="append")
    ap.add_argument("--warn-only", action="store_true")
    a = ap.parse_args(argv)
    root = Path(a.root).resolve()
    spec_dirs = [root / d for d in (a.specs or ["specs", "docs/requirements"])]
    test_dirs = [root / d for d in (a.tests or ["tests", "src", "app"])]
    reqs = collect(spec_dirs, lambda f: f.suffix in (".md", ".txt", ".yaml", ".yml"))
    tests = collect(test_dirs, lambda f: bool(TEST_FILE.match(f.name)))
    if not reqs:
        print("NOT_APPLICABLE: no se encontraron REQ-IDs en specs (¿specs escritos en EARS con IDs?).")
        return 0
    missing = sorted(r for r in reqs if r not in tests)
    orphan = sorted(r for r in tests if r not in reqs)
    covered = len(reqs) - len(missing)
    print(f"REQ en specs: {len(reqs)} · con test: {covered} ({100 * covered / len(reqs):.0f} %)")
    for r in missing:
        print(f"  SIN TEST  {r}  ({', '.join(str(p.relative_to(root)) for p in sorted(reqs[r]))})")
    for r in orphan:
        print(f"  HUÉRFANO  {r}  citado en tests pero no existe en specs")
    if (missing or orphan) and not a.warn_only:
        print("FAIL")
        return 1
    print("PASS" if not (missing or orphan) else "WARN (modo --warn-only)")
    return 0


if __name__ == "__main__":
    sys.exit(main())

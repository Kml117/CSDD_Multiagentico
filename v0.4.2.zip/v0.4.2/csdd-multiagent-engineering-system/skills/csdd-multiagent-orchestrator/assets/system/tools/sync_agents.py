#!/usr/bin/env python3
"""Genera definiciones de agentes desde roles.toml + el 'Núcleo operativo' de cada Skill de rol.

Salidas (sobrescribe solo archivos generados por este script):
  .claude/agents/<rol>.md   subagentes de Claude Code (frontmatter: name, description, tools, model)
  .agents/agents/<rol>.md   definición compartible para Kimi Code y otros (FORMATO A VERIFICAR)
Fuente del núcleo: el bloque entre <!-- core:start --> y <!-- core:end --> del SKILL.md del rol,
buscado en .claude/skills/<rol>/ o .agents/skills/<rol>/.
"""
from __future__ import annotations

import re
import sys
import tomllib
from pathlib import Path

for _stream in (sys.stdout, sys.stderr):  # UTF-8 también en consolas heredadas (Windows) o LANG=C
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError, OSError):
        pass

MARK = "<!-- generado por .csdd/tools/sync_agents.py — edita roles.toml o la Skill del rol, no este archivo -->"


def core_block(root: Path, role: str) -> str:
    for base in (".claude/skills", ".agents/skills", "skills"):
        f = root / base / role / "SKILL.md"
        if f.exists():
            m = re.search(r"<!-- core:start -->(.*?)<!-- core:end -->", f.read_text(encoding="utf-8"), re.S)
            if m:
                return m.group(1).strip()
    return f"Sigue la Skill `{role}` y AGENTS.md."


def write(path: Path, text: str) -> str:
    if path.exists() and MARK not in path.read_text(encoding="utf-8"):
        return f"OMITIDO (editado a mano): {path}"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return f"OK {path}"


def main(argv: list[str]) -> int:
    root = Path(argv[1]).resolve() if len(argv) > 1 else Path.cwd()
    cfg = tomllib.loads((root / ".csdd/config/roles.toml").read_text(encoding="utf-8"))
    for role, rc in cfg["roles"].items():
        perms = (f"Puedes escribir: {', '.join(rc.get('write_paths') or ['allowed_paths de tu tarea'])}. "
                 f"Clase de shell: {rc.get('shell_class')}. El guard (.csdd/hooks/guard.py) bloquea lo demás.")
        body = core_block(root, role)
        proto = root / ".csdd/templates/protocolo-sesion-core.md"
        if proto.exists():
            body = proto.read_text(encoding="utf-8").strip() + "\n\n" + body
        desc = f"{rc['alias']} — {rc['mission']} Úsalo para tareas de su rol dentro del sistema CSDD."
        desc = desc.replace("\n", " ").replace('"', "'")
        if rc.get("claude_subagent"):
            model = {"opus": "opus", "sonnet": "sonnet", "haiku": "haiku"}.get(rc.get("model_hint"), "inherit")
            text = (f"---\nname: {role}\ndescription: \"{desc}\"\ntools: {', '.join(rc['claude_tools'])}\n"
                    f"model: {model}\n---\n{MARK}\n\n# {rc['alias']} ({role})\n\n{perms}\n\n{body}\n")
            print(write(root / ".claude/agents" / f"{role}.md", text))
        text = (f"---\nname: {role}\ndescription: \"{desc}\"\n---\n{MARK}\n"
                f"<!-- Formato para Kimi Code: VERIFICAR contra la documentación oficial de agentes de Kimi. -->\n\n"
                f"# {rc['alias']} ({role})\n\n{perms}\n\n{body}\n")
        print(write(root / ".agents/agents" / f"{role}.md", text))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

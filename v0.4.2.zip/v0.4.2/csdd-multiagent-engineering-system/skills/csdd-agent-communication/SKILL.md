---
name: csdd-agent-communication
description: "Protocolo de comunicación entre agentes del sistema CSDD multiagente v0.4.0: buzón por archivos con enrutador explícito (solo Jefe Maestro enruta), seis tipos de mensaje, artefactos como fuente de verdad, inmutabilidad, deduplicación y reglas de quién puede enviar qué. Úsala SIEMPRE que un agente necesite preguntar, responder, entregar trabajo (handoff), reportar un resultado de verificación, escalar un bloqueo o asignar una tarea, o cuando el usuario pregunte cómo se comunican Claude Code y Kimi entre sí, cómo funciona el buzón, csdd.py send/route/inbox/ack, o por qué un mensaje fue rechazado."
metadata:
  version: "0.4.0"
  system: "CSDD Multi-Agent Engineering System"
  decision: "Alternativa B (ADR-0003): Jefe Maestro es el enrutador explícito"
---

# Protocolo de comunicación entre agentes (v0.4.0)

## Arquitectura de tres capas

1. **Buzón de mensajes:** canal de coordinación y handoffs. Mensajes pequeños, estructurados, direccionados y vinculados a tareas.
2. **Repositorio de artefactos:** fuente de verdad versionada: specs, decisiones, código, planes, resultados, informes y evidencias.
3. **Orquestador / enrutador:** **Jefe Maestro** (`csdd-executive-supervisor`) con `csdd.py route`. Valida, enruta, rechaza, deduplica y mantiene el estado.

No confundir el buzón con un chat libre ni con el repositorio. El mensaje apunta a artefactos; no transporta documentos completos (máximo 600 caracteres en `summary`; el detalle va en `refs`).

## Por qué un enrutador explícito (Alternativa B)

Claude Code y Kimi Code son procesos aislados: no comparten memoria ni se llaman entre sí. En v0.3.0 el diseño era "outbox → el orquestador enruta", pero nadie era el orquestador. En v0.4.0 ese papel es de **Jefe Maestro**, y la CLI y el guard lo hacen cumplir:

- Cualquier agente escribe **solo en su outbox** (`csdd.py send`, `handoff`, `result`).
- **Solo Jefe Maestro** ejecuta `csdd.py route` (el guard bloquea a los demás).
- Al enrutar se valida que `from` coincida con el outbox, que el tipo sea legítimo para ese emisor, que el `task_id` exista y que el `message_id` no se repita. Lo inválido va a `mailbox/rejected/` con un `.reason.txt`.
- Un agente no puede escribir directamente en la inbox de otro: las escrituras fuera de su worktree están bloqueadas y `.project/` compartido solo se toca vía CLI.

Costo honesto: los mensajes esperan a que Jefe Maestro enrute (latencia humana o de la sesión principal). Para dos o tres agentes locales es aceptable y elimina la coordinación libre, que es la principal fuente de fallos en sistemas multiagente.

## Tipos de mensaje (seis)

| Tipo | Quién lo envía | Para qué |
|---|---|---|
| `TASK` | Solo Jefe Maestro | Asignar o reasignar una tarea (el contrato completo está en `.project/state/tasks/<T>.json`) |
| `HANDOFF` | Solo el dueño de la tarea (vía `csdd.py handoff`) | Entregar trabajo listo para revisión, con archivos cambiados |
| `QUESTION` | Cualquiera | Pregunta concreta y bloqueante sobre una tarea |
| `ANSWER` | Cualquiera (con `--reply-to`) | Respuesta a una pregunta |
| `RESULT` | Solo Cortana o El Portero (vía `csdd.py result`) | Resultado de verificación: PASS · FAIL · NOT_RUN · NOT_APPLICABLE · UNKNOWN |
| `BLOCKER` | Cualquiera (y el sistema) | No se puede avanzar: guard, presupuesto, ambigüedad, conflicto, decisión del propietario (`--needs-user`) |

Equivalencias con los 14 tipos de v0.3.0: `TASK_ASSIGNMENT`→TASK; `HANDOFF`, `ARTIFACT_PUBLISHED`, `INTEGRATION_REQUEST`→HANDOFF; `QUESTION`; `ANSWER`; `REVIEW_FINDING`, `GATE_RESULT`→RESULT; `BLOCKER`, `DECISION_REQUEST`→BLOCKER (`needs_user`); `REVIEW_REQUEST`, `STATUS_UPDATE`→estado de la tarea + `csdd.py worktree review`; `APPROVAL_GRANTED/DENIED`→registro de autorización (`csdd.py approval`), nunca un mensaje (un texto en el buzón no habilita operaciones privilegiadas).

## Campos del mensaje (`schema: csdd-message/0.4`)

`message_id`, `created_at`, `from`, `to` (rol o `user`), `type`, `task_id`, `summary`, `refs` (rutas a artefactos), `reply_to`, `needs_user`. `RESULT` añade `status` y `blocking`; `HANDOFF` añade `changed_files`. Plantilla: `.csdd/templates/agent-message.json`.

## Estados (derivados, no editados)

`QUEUED` (en outbox) → `ROUTED` (en inbox) → `ACKNOWLEDGED` (`csdd.py ack <id>`) → `DONE` (`ack --done`, se archiva en `mailbox/archive/AAAA-MM/`); o `REJECTED` (en `mailbox/rejected/`). El archivo del mensaje nunca se reescribe: el estado sale de su ubicación y de `.project/state/acks/`.

## Flujo normal

1. Jefe Maestro crea el contrato (`csdd.py task new`) y, si conviene, un `TASK` con contexto adicional.
2. El agente lo lee (`csdd.py inbox`, `csdd.py task show <T>`), acusa (`ack`) y trabaja sobre artefactos de fuente de verdad.
3. Si algo bloquea: `QUESTION` o `BLOCKER`, concreto y con la referencia al artefacto en duda.
4. Al terminar: `csdd.py handoff <T>` (la CLI exige commits y alcance correcto).
5. Jefe Maestro enruta, abre `worktree review` y asigna a Cortana/El Portero.
6. El revisor devuelve `RESULT` con evidencia.
7. Jefe Maestro actualiza estado, integra (`merge`) o devuelve a REWORK y activa dependencias.

## Comunicación directa

Se permite que un agente escriba a otro rol si existe una dependencia o contrato claro (por ejemplo, El Hombre de la Bolsa pregunta a Jarvis por un requisito). El mensaje pasa por el buzón y por el enrutamiento de Jefe Maestro, que así queda informado. No se permiten cadenas de conversación sin objetivo, sin límite o sin vínculo a tarea: más de tres intercambios QUESTION/ANSWER sobre lo mismo es señal de que el contrato está mal y Jefe Maestro debe reescribirlo.

## Concurrencia y conflictos

- `.project/` vive en el worktree principal y lo comparten todos (la CLI lo resuelve con `git rev-parse --git-common-dir`).
- Escrituras atómicas (archivo temporal + `os.replace`); `message_id` único con marca de tiempo y sufijo aleatorio; consumidores idempotentes por `message_id`.
- Un artefacto mutable tiene un único responsable (`allowed_paths` sin solapamiento; la CLI lo verifica).
- El buzón no otorga permisos de escritura: los da `roles.toml` + el contrato + (excepcionalmente) una autorización Comunista.
- Las decisiones se registran en Decision Records, no se infieren de conversaciones.
- Para ejecución concurrente en varias máquinas, una carpeta compartida no basta: migrar a cola o base de datos con autenticación, autorización, transacciones y auditoría (y entonces sí evaluar A2A/MCP).

## Política de comunicación

- Mensaje breve y accionable; el detalle vive en el artefacto referenciado.
- Una pregunta al usuario solo si falta una decisión o dato que no puede inferirse con seguridad: `BLOCKER --to user --needs-user`, y Jefe Maestro la consolida.
- No enviar mensajes rutinarios al usuario: Jefe Maestro consolida.
- Nunca incluir secretos ni datos personales en `summary` o `refs` (Art. VIII); la bitácora redacta patrones `token=`, `password=`, etc., pero no es una red de seguridad.
- Si el guard te bloquea, el mensaje correcto es un `BLOCKER` que diga qué necesitas, no un intento de rodearlo.

## Comandos

```bash
python .csdd/tools/csdd.py send --to csdd-software-architect --type QUESTION --task T-001 \
  --summary "REQ-AUTH-01: ¿el token expira a los 15 min o al cerrar sesión?" --ref specs/auth.md
python .csdd/tools/csdd.py inbox                 # tu bandeja (sin acusar); --all para ver todo
python .csdd/tools/csdd.py ack <message_id> [--done]
python .csdd/tools/csdd.py route                 # solo Jefe Maestro
python .csdd/tools/csdd.py send --to user --type BLOCKER --needs-user --task T-001 --summary "…"
```

## En claude.ai (web)

No hay buzón ejecutable. Usa este protocolo para redactar mensajes y contratos con el formato correcto, simular el enrutamiento en una planeación o revisar un `events.jsonl` que el usuario suba.

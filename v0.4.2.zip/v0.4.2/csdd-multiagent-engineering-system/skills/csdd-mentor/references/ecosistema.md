# Ecosistema: skills, recursos y herramientas — CSDD Mentor

> Referencia de `csdd-mentor` v1.6.0. Contenido trasladado sin recortes desde `SKILL.md` v1.5.0; vuelve a `SKILL.md` para modos, artículos, reglas y arranque.

## 📚 Ecosistema: skills, recursos y herramientas

Esta skill complementa pero no reemplaza la ruta SDD del usuario. Los recursos se agrupan por tipo. Las skills se activan junto a esta; los recursos son fuentes de consulta; las herramientas se ejecutan en CI o local; el modelo es quien opera la skill.

| Recurso | Tipo | Cuándo activarlo |
|---|---|---|
| `mentor-sdd-prompt` | skill | Para SDD general sin componente de seguridad. Si la pregunta no es CSDD, dirige a ese prompt. |
| `modern-dev-stack` | skill | Para el diagnóstico técnico y selección de stack de cualquier proyecto — se activa siempre, incluso cuando esta skill también está activa. En proyectos Simple/Media, cubre el trabajo completo sin necesitar CSDD. |
| `saas-architect` | skill | Cuando el proyecto es multi-tenant. Sus decisiones de aislamiento alimentan directamente los Artículos III, IV, VI y VII de esta skill. |
| `cybersecurity` | skill | Para auditoría automatizada de código existente (Modo B retrofit) — 8 agentes en paralelo, mapea a CWE Top 25 y ahora también a los 9 artículos si detecta un `constitution.md`. También en Modo C cuando la spec incluya código existente que requiera escaneo. |
| `🗄️ Archivos Fundamentales` | recurso | Antes de usar esta skill por primera vez, asegúrate de tener `Constitutional_Spec-Driven_Development.pdf` en NotebookLM. |
| `🗺️ Mapeo Módulos SDD ↔ Archivos` | recurso | Para consultar qué archivo de la base de conocimiento respalda cada concepto. |
| NotebookLM | recurso | Para citas verbatim del paper original o del estudio Liu et al. Además, para verificar afirmaciones de esta skill contra la fuente original antes de citarlas en una auditoría. |
| `create-saltic` (npm, "Saltic") | herramienta | Framework SDD constitucional con plantillas Angular y React. Existe en npm (v0.1.24); su repositorio declarado es un placeholder, sin verificar. Referencia de plantillas, no estándar. |
| `@protonspy/csdd-mcp` (npm) | herramienta | Servidor MCP que expone el CLI `csdd` como herramientas; requiere el binario instalado. Gate en CI. Existe en npm (v0.13.0). No confundir con el paquete `csdd`, que es otro proyecto. |
| OPA/Conftest | herramienta | Policy as Code para bloquear violaciones en CI (ver Fase 6). |
| Semgrep | herramienta | Reglas personalizadas que mapean hallazgos a artículos (ver Fase 6). |
| Pact | herramienta | Contract testing en límites constitucionales (ver Fase 6). |
| gitleaks / trufflehog | herramienta | Detección de secretos. Ver Artículo VIII. |
| Claude (yo) | modelo | Para interactividad, generación de artefactos, debate socrático, verification gates. |

---

**Sistema multiagente v0.4.0:** `csdd-multiagent-orchestrator` (entrada de ejecución), `csdd-agent-communication` (buzón) y los cinco roles (`csdd-executive-supervisor`, `csdd-software-architect`, `csdd-implementation-engineer`, `csdd-qa-verification`, `csdd-security-reviewer`). En claude.ai, si está instalada `gestion-proyectos-aplicada`, úsala para charter, WBS y cronograma del plan de dirección.

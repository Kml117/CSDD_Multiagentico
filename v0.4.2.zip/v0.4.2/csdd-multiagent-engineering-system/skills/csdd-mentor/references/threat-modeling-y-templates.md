# Threat modeling continuo y templates — CSDD Mentor

> Referencia de `csdd-mentor` v1.6.0. Contenido trasladado sin recortes desde `SKILL.md` v1.5.0; vuelve a `SKILL.md` para modos, artículos, reglas y arranque.

## 🎯 Threat Modeling Continuo

El threat model inicial de Fase 1 envejece. Se mantiene vivo así:

- **Por feature relevante:** STRIDE (o PASTA si el dominio es de alto riesgo) sobre cada feature que toque datos sensibles, identidad o límites de confianza. No solo al inicio del proyecto.
- **Traducción de hallazgos.** Cada amenaza termina en una de tres salidas: (a) un artículo nuevo de dominio, (b) un ajuste a un artículo existente, o (c) una excepción documentada en `constitutional-exception-doc.md`.
- **Cadencia.** Revisión trimestral (la misma del Quarterly Constitutional Review de Fase 6), más revisión obligatoria tras cualquier incidente o cambio en el modelo de datos.
- **Attack trees** para las 3 superficies de mayor riesgo (p. ej. autenticación, ingesta de datos, integraciones). Cada hoja enlaza a un test de Fase 5 o a una excepción.

---

## 🎨 Templates que esta skill genera

Cuando el usuario los pida, la skill produce estos artefactos calibrados a su dominio:

1. **`constitution.md`** — Documento completo de 9-14 artículos, versionado, con rationale por artículo.
2. **`CWE-mapping.md`** — Tabla CWE → artículo → mecanismo de mitigación.
3. **`traceability-matrix.md`** — La matriz de Fase 5, regenerable.
4. **`spec-constitutional-check.md`** — Plantilla para el bloque constitucional de cada spec.
5. **`pr-constitutional-review.md`** — Checklist para revisar PRs contra la constitución.
6. **`compliance-audit-report.md`** — Reporte ejecutivo de 1-2 páginas para auditores externos.
7. **`constitutional-exception-doc.md`** — Plantilla para documentar excepciones justificadas.
8. **`PRD.md`** — Solo Compleja/Enterprise: problema de negocio, historias de usuario, criterios de aceptación en lenguaje no técnico.
9. **`SRS.md`** — Solo Compleja/Enterprise: requisitos técnicos en notación EARS + bloque Constitutional Compliance.
10. **`ADR.md`** — Architecture Decision Record constitucional.
11. **`constitutional-amendments-log.md`** — Registro de enmiendas con fecha, artículo, cambio, ADR, aprobador y hash.
12. **`compliance-metrics.md`** — Métricas de cumplimiento con umbrales.
13. **`red-team-constitution.md`** — Reporte del ejercicio adversarial contra la constitución.
14. **`policy-as-code-rules.md`** — Mapeo artículo → regla OPA/Semgrep.

**Importante:** Estos templates **no son genéricos**. La skill los personaliza al dominio del usuario antes de entregarlos. Si el usuario los quiere genéricos, le explica por qué eso degrada el valor de CSDD.

---

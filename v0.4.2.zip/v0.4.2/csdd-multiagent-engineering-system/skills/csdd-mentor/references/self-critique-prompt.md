# Prompt de autocrítica constitucional (Constitutional AI aplicado a CSDD)

> Úsalo **antes de proponer** cualquier artefacto (spec, plan, código, configuración de agentes).
> Es un filtro previo, **no evidencia**: la evidencia es ejecutable (Regla 6, Antipatrón 6).
> Inspirado en Constitutional AI (Bai et al., 2022): criticar el propio borrador contra principios explícitos y revisarlo.

## Instrucción para el agente

Antes de entregar, toma tu borrador y responde por escrito, solo para los artículos que aplican a esta tarea
(según el bloque Constitutional Compliance de la spec o el campo `articles` del contrato de tarea):

| Artículo | Pregunta de autocrítica | Señal de alarma |
|---|---|---|
| I Library-First | ¿Implementé yo algo de criptografía, hashing, autenticación o validación que una librería auditada ya resuelve? ¿Añadí una dependencia nueva no autorizada? | `hashlib.md5`, JWT casero, regex propia para emails/URLs, `npm install` fuera de `dependencies_allowed` |
| II Test-First | ¿Existe un test que falla sin mi cambio y pasa con él, por cada REQ que toco? ¿Lo escribí antes? | Tests escritos después que solo reflejan la implementación; REQ sin test |
| III Input Validation | ¿Todo dato externo (HTTP, archivos, mensajes, env) pasa por un esquema declarativo en el límite? ¿Las mutaciones tienen protección CSRF? | `dict`/`any` sin esquema; SQL con f-string; `shell=True`; HTML sin escapar |
| IV Least Privilege | ¿Pedí o di más permisos de los necesarios (archivos, rutas, roles, scopes, herramientas)? | Rutas `**` amplias; endpoints sin chequeo de autorización por recurso |
| V Defense in Depth | ¿Cuál es la segunda capa si la primera falla? | Una sola validación protege todo |
| VI Fail Secure | Si algo lanza una excepción inesperada, ¿el sistema niega o abre? | `except: pass`; caer a modo permisivo; 200 tras error |
| VII Auditability | ¿Las acciones críticas dejan evento con quién/qué/cuándo/desde dónde/resultado, sin datos sensibles? | Log en texto plano con tokens; acción crítica sin evento |
| VIII No Secrets | ¿Hay algún secreto en código, config versionada, logs, mensajes del buzón o evidencias? | Literales con aspecto de clave; `.env` leído o citado |
| IX Reproducible | ¿Un tercero puede reproducir mi verificación con un comando? | "Lo probé y funciona" sin comando ni salida |

## Formato de salida de la autocrítica

```
AUTOCRÍTICA [tarea/artefacto]
Artículos revisados: II, III, VI
- Art. III: RIESGO → el handler /login acepta dict sin esquema. CORRECCIÓN → LoginIn (Pydantic) en src/auth/schemas.py.
- Art. II: OK → tests/auth/test_login.py::test_rejects_malformed_body (REQ-AUTH-02) falla sin el cambio.
- Art. VI: OK → excepción de validación devuelve 422; no hay except vacío.
Pendiente de evidencia ejecutable: pytest tests/auth -q (lo corre Cortana).
```

Reglas: no declares "cumple" sin señalar el mecanismo concreto; si dudas, márcalo como RIESGO y corrígelo o escálalo; nunca cuentes esta autocrítica como PASS.

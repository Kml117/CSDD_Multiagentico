# Medición, auditoría de cumplimiento y métricas de éxito — CSDD Mentor

> Referencia de `csdd-mentor` v1.6.0. Contenido trasladado sin recortes desde `SKILL.md` v1.5.0; vuelve a `SKILL.md` para modos, artículos, reglas y arranque.

## 📊 Medición y Auditoría de Cumplimiento

**Métricas obligatorias** (los umbrales se fijan por proyecto en `compliance-metrics.md`):
- **Cobertura de trazabilidad:** % de artículos con implementación verificada y test asociado.
- **Densidad de defectos de seguridad por release:** hallazgos confirmados en cada release.
- **MTTR de violaciones constitucionales:** tiempo medio desde que se detecta una violación hasta que se remedia.
- **Deriva constitucional:** % de archivos críticos con anotación vigente (definición en Fase 6).

**Generación automática de evidencia:** SBOM por release, reporte de cumplimiento generado en CI e historial de cambios de la constitución con firmas (ver Gobernanza).

**Mapeo regulatorio:** la matriz de Fase 5 suma una columna "control regulatorio" (p. ej. PCI-DSS 3.4, GDPR Art. 32) para reutilizar evidencia en auditorías externas.

**Advertencia:** Claude prepara evidencia, no certifica. Una auditoría oficial requiere auditor certificado (ver Modo D).

---
- **Retrabajo (v1.6.1):** horas de la bitácora dedicadas a reconciliar estado o rehacer trabajo dado por hecho, y % de sesiones cerradas con horas registradas (meta: 100 %). Fuente: bloques de `session end`.
- **MUST con control automatizado (v1.6.0):** % de artículos MUST con al menos un control en `constitution-controls.toml` marcado `automated = true`. Lo imprime `check_constitution_controls.py`. Un MUST sostenido solo por revisión manual cuenta aparte y debe tener `manual_justification`.

---

## 🎯 Métricas de éxito de la skill

Esta skill funciona bien si, después de 4-6 sesiones de uso real, el usuario puede:

- [ ] Redactar un artículo constitucional desde cero para un dominio nuevo, sin ayuda
- [ ] Detectar Spec Theater en specs ajenas
- [ ] Generar la matriz de trazabilidad de su proyecto y mantenerla actualizada
- [ ] Justificar cada artículo de su constitución con escenarios reales
- [ ] Identificar 3 antipatrones en una constitución que le muestren
- [ ] Hacer una auditoría de cumplimiento básica sin ayuda externa
- [ ] Mapear al menos 5 CWEs a artículos específicos de su constitución
- [ ] Defender CSDD ante un dev senior escéptico con datos del paper (73 % menos violaciones CWE y 4x menos ciclos de revisión; n=1, citar siempre con esa limitación)
- [ ] Documentar una enmienda constitucional con ADR y propagarla a specs y código sin ayuda
- [ ] Ejecutar un red team básico de su constitución y documentar los hallazgos
- [ ] Configurar Policy as Code en CI mapeando al menos 3 artículos
- [ ] Detectar y cuantificar deriva constitucional

Si después de 6 sesiones el usuario no puede hacer al menos 8 de estos, la skill (o el aprendizaje) está fallando. Diagnostica y reajusta.

---

# Workflow fase por fase — CSDD Mentor

> Referencia de `csdd-mentor` v1.6.0. Contenido trasladado sin recortes desde `SKILL.md` v1.5.0; vuelve a `SKILL.md` para modos, artículos, reglas y arranque.

## 🏗️ Workflow Fase por Fase

### Fase 1 — Constitution Draft (8-16 horas distribuidas en 2-3 sesiones)

**Objetivo:** Producir `constitution.md` versionado y ratificado.

**Pasos:**
1. **Diagnóstico de dominio** (15 min): ¿qué hace el sistema?, ¿qué datos maneja?, ¿qué regulación aplica?, ¿cuál es el peor caso de fallo?
2. **Threat modeling inicial** (45 min) con STRIDE o PASTA: top 10 OWASP aplicable + amenazas específicas del dominio, mapeadas a flujos de datos.
3. **Adopción de los 9 artículos base** (1h): los explico uno por uno, el usuario confirma comprensión, ajustamos enunciado al dominio. Documentamos la decisión en `ADR-0001-constitution-adoption.md`: adoptados tal cual o modificados, y por qué.
4. **Artículos adicionales del dominio** (1-2h): 2-5 artículos específicos (ej. "Inmutabilidad de auditoría fiscal", "Tokenización de PAN antes de persistencia").
5. **Ratificación** (15 min): el usuario firma (literalmente: commit con mensaje "RATIFY: Constitution v1.0") y se versiona. Antes de firmar, se crea `constitutional-amendments-log.md` con su encabezado, aunque esté vacío.

**Verification Gate Fase 1:**
> *"Antes de pasar a Fase 2, respóndeme estas 5 preguntas. Si fallas una, repasamos:*
> 1. *¿Cuál es la diferencia operacional entre MUST y SHOULD en tu constitución?*
> 2. *Si un dev senior te dice 'este artículo es overkill', ¿cómo defiendes la decisión?*
> 3. *¿Cuál es el artículo más restrictivo para tu equipo y por qué?*
> 4. *¿Qué pasa si un PR viola un MUST? ¿Y un SHOULD?*
> 5. *Entrégame tu `constitutional-amendments-log.md` (aunque esté vacío) y el `ADR-0001-constitution-adoption.md` que documenta por qué adoptaste los 9 artículos base tal cual, o qué modificaste y por qué."*

Si el usuario no puede responder, regresamos a explicar — no avanzamos. Sin el artefacto de la pregunta 5, el gate no pasa aunque las 4 primeras estén bien respondidas.

---

### Fase 2 — Spec with Constitutional Check (por feature)

**Objetivo:** Cada `spec.md` declara qué artículos aplica, con requisitos escritos en un formato que un agente no puede malinterpretar.

**Pasos:**
1. Escribir spec normal (siguiendo `mentor-sdd-prompt` si está activo). Cada requisito de la sección "Requirements" se escribe en **notación EARS**, no en prosa libre — ver tabla abajo. Esto no es burocracia: cada patrón EARS implica directamente su forma de implementación y de test (ubicuo→invariante, evento→handler+test de integración, estado→máquina de estados, no deseado→ruta de error), así que escribir en EARS deja media Fase 4 ya decidida.
2. Sección obligatoria "Constitutional Compliance":
   - Lista de artículos relevantes para esta feature
   - Por cada artículo: cómo lo respeta la spec, con qué mecanismo concreto
3. Identificar conflictos con artículos (si un artículo es MUST pero el negocio pide excepción, documentar en sección "Constitutional Exceptions" con justificación firmada).
4. **Si Complejidad = 🟠 Compleja o 🔴 Enterprise** (taxonomía de la tabla de Complejidad de la sección de integración con Notion): separar en dos documentos en vez de uno solo — ver "PRD vs SRS" abajo. Para Simple/Media, un solo `spec.md` mezclando ambos niveles es correcto; no fuerces la separación ahí.

**Output:** spec aumentada con bloque constitucional verificable, requisitos en EARS.

**Verification Gate Fase 2:** revisar 3 specs aleatorias. Si 1 omite el bloque constitucional, o tiene requisitos en prosa libre en vez de EARS, todas se devuelven a rework.

#### Notación EARS (obligatoria en la sección Requirements)

| Patrón | Plantilla | Cuándo usarlo |
|---|---|---|
| Ubicuo | El `<sistema>` deberá `<respuesta>` | Propiedad siempre activa, sin condición |
| Basado en evento | Cuando `<disparador>`, el `<sistema>` deberá `<respuesta>` | Reacción a una acción puntual |
| Basado en estado | Mientras `<estado>`, el `<sistema>` deberá `<respuesta>` | Comportamiento activo durante un estado |
| Comportamiento no deseado | Si `<condición>`, entonces el `<sistema>` deberá `<respuesta>` | Manejo de errores/fallos |
| Característica opcional | Donde `<característica>`, el `<sistema>` deberá `<respuesta>` | Solo aplica si esa feature existe |

**Cuándo NO forzar EARS**: requisitos con más de 3 precondiciones, o inherentemente matemáticos (una fórmula de pricing, un modelo estadístico) — ahí EARS degrada la claridad en vez de mejorarla. Úsalo para el resto, que es la mayoría.

#### PRD vs SRS (solo Compleja/Enterprise)

En Simple/Media, `spec.md` mezcla ambos niveles y está bien así. En Compleja/Enterprise, sepáralos porque suelen tener audiencias distintas — un stakeholder de negocio (ej. alguien del lado del cliente en un engagement de Cifra) necesita poder aprobar el alcance sin leer arquitectura:

- **`PRD.md`** (Product Requirements Document): el problema de negocio, para quién es, historias de usuario, criterios de aceptación en lenguaje de negocio. Lo revisa quien decide si esto vale la pena construir.
- **`SRS.md`** (Software Requirements Specification): stack técnico, arquitectura, requisitos de interfaz, requisitos no funcionales (rendimiento, seguridad, escalabilidad) — todo en EARS. Lo consume el agente que va a implementar. Deliberadamente conciso: define QUÉ construir sin reexplicar patrones que el proyecto ya usa.

El bloque "Constitutional Compliance" vive en `SRS.md`, no en `PRD.md` — ese bloque es técnico por naturaleza. Ambos documentos se registran en la base de Notion `📐 Documentos CSDD` con `Tipo de documento` = `PRD.md` o `SRS.md` respectivamente, relacionados al mismo desarrollo.

---

### Fase 3 — Plan with Compliance Verification

**Objetivo:** El plan técnico (`plan.md`) demuestra **cómo** se implementa cada artículo, no solo que aplica.

**Pasos:**
1. Sección "Constitution Implementation Map" en plan.md:
   ```
   Article III (Input Validation) → Pydantic schemas en src/schemas/, validados en src/middleware/validation.py
   Article VIII (No Secrets) → HashiCorp Vault, accedido via src/config/secrets.py
   ```
2. Cada decisión técnica que afecta artículo cita el artículo en su justificación.

**Verification Gate Fase 3:** correr `/speckit.analyze` (o equivalente) y verificar que no hay "Constitutional Check FAILED" en el plan.

---

### Fase 4 — Implementation with CWE Mapping

**Objetivo:** Cada commit con implicación de seguridad referencia el artículo que cumple.

**Pasos:**
1. Convención de commit messages: `feat: add login endpoint [Article III, Article VII]`
2. Headers de archivo crítico:
   ```python
   """
   src/auth/login.py
   Constitutional Compliance: Article II (Test-First), Article III (Input Validation),
                              Article VI (Fail Secure), Article VII (Auditability)
   """
   ```
3. Tests anotados con artículo verificado:
   ```python
   def test_login_rejects_sql_injection():
       """Verifies Article III (Input Validation at Boundaries)."""
       ...
   ```

---

### Fase 5 — Traceability Matrix

**Objetivo:** Matriz auditable que mapea artículo → archivos → tests → evidencia ejecutable.

**Template generable por la skill:**

| Artículo | Archivos | Tests | Última verificación | Estado |
|---|---|---|---|---|
| I — Library-First | `pyproject.toml`, `package.json` | `test_no_forbidden_libs.py` | 2026-04-29 | ✅ |
| II — Test-First | (todos los `tests/`) | CI coverage report | 2026-04-29 | ⚠️ 87% |
| III — Input Validation | `src/schemas/*`, `src/middleware/validation.py` | `tests/test_validation.py` | 2026-04-29 | ✅ |
| ... | | | | |

**Mantenimiento:** la matriz se regenera automáticamente (script en `/scripts/generate-traceability.py`) y se commitea diariamente.

---

### Fase 6 — Continuous Verification y Automatización

**Objetivo:** La constitución vive y respira. No es un documento muerto.

**Mecanismos:**
1. **Quarterly Constitutional Review** (cada 3 meses): equipo revisa si los artículos siguen aplicables, si surgieron nuevas amenazas, si algún SHOULD debería subir a MUST.
2. **Post-Incident Constitutional Update**: tras cualquier incidente de seguridad, sesión obligatoria de "¿qué artículo faltaba o falló?".
3. **Constitutional Drift Detection**: extensión CI Guard (si está disponible) detecta archivos que dejaron de cumplir. Se operacionaliza en la subsección de deriva abajo.

#### Policy as Code

- **Controles por artículo (v1.6.0):** la tabla de `SKILL.md` → "Controles ejecutables por artículo" y su versión de máquina `.csdd/config/constitution-controls.toml` (verificada por `check_constitution_controls.py`) son la fuente operativa; las reglas Semgrep base viven en `.csdd/policy/semgrep/csdd-rules.yml`, cada una con `metadata.csdd_article`.

- **OPA/Conftest o Semgrep** con reglas que mapean cada hallazgo a un artículo (`Art-III`). Mapeo propuesto de los principios SEC-xxx del paper (revisar con el equipo antes de usarlo en una auditoría):

| Principio del paper | CWE | Artículo de esta skill |
|---|---|---|
| SEC-001 Encoding de salida | CWE-79 | III |
| SEC-002 Consultas parametrizadas | CWE-89 | III |
| SEC-003 Protección anti-CSRF | CWE-352 | III (corregido en v1.6.0; antes V) |
| SEC-004 Autenticación en endpoints | CWE-306 | IV |
| SEC-005 Credenciales fuera del código | CWE-798 | VIII |
| SEC-006 Validación con schemas | CWE-20 | III |
| SEC-007 Montos con tipo Decimal | CWE-190 | III |
| SEC-008 OAuth2 con JWT | CWE-287 | I |
| SEC-009 Hash de contraseñas (bcrypt ≥ 12) | CWE-522 | I |
| SEC-010 Autorización por recurso | CWE-862/863 | IV |
| SEC-011 Expiración de tokens ≤ 15 min | CWE-613 | IV |
| SEC-012 Cifrado en reposo | CWE-312 | Dominio (Privacidad) |
| SEC-013 TLS ≥ 1.2 | CWE-319 | V ⚠️ propuesta de subir a MUST en ADR-0002 (pendiente de ratificación) |
| SEC-014 Errores sin detalles internos | CWE-200 | VI (corregido en v1.6.0; antes VIII) |
| SEC-015 Logs sin credenciales | CWE-532 | VII |

- **CLI `csdd` + servidor MCP `@protonspy/csdd-mcp`** como gate en CI. Valida el contrato del workflow SDD de Claude Code, no los artículos: esos los verifican OPA o Semgrep. Requiere el binario `csdd` en el runner.
- **SAST, DAST y SCA** configurados para etiquetar cada hallazgo con un ID de artículo. El build falla ante un hallazgo MUST confirmado; los falsos positivos pasan por triage, no bloquean por defecto.
- **SBOM** generado en cada release y archivado como evidencia.

#### Pruebas más allá de Test-First

- **Contract testing** (Pact o equivalente) en las interfaces que cruzan límites constitucionales, por ejemplo entre API pública y servicio interno.
- **Property-based testing** para invariantes de los Artículos I, III y VI. Ejemplo: cualquier input malformado produce un 4xx, nunca un 5xx ni datos parciales.
- **Mutation testing** sobre los tests de seguridad. Si mutar el código de validación no hace fallar ningún test, ese test no protege nada.
- **Design by Contract:** precondiciones, postcondiciones e invariantes como reflejo directo de los artículos en código.

#### Deriva constitucional

- **Definición operativa:** porcentaje de archivos críticos cuya anotación de artículo es anterior al último commit que modificó ese artículo en `constitution.md`, y que lleva más de 30 días en esa situación.
- **Detección:** script en CI que compara la fecha de cada anotación de header (Fase 4) con la del último commit del artículo referenciado.
- **Acción:** bloquear merge si la deriva supera el umbral (sugerido: 5 %). Durante una enmienda, la ventana de relajación se declara en su ADR.
- Esta subsección extiende el mecanismo 3 de arriba; no es un check independiente.

---

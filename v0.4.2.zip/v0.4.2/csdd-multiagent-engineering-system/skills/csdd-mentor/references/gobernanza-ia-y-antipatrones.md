# Gobernanza de IA y antipatrones — CSDD Mentor

> Referencia de `csdd-mentor` v1.6.0. Contenido trasladado sin recortes desde `SKILL.md` v1.5.0; vuelve a `SKILL.md` para modos, artículos, reglas y arranque.

## 🤖 Gobernanza de IA en CSDD

- **Autocrítica contra la constitución.** Inspirada en Constitutional AI (Bai et al., 2022). El agente evalúa su output contra un checklist por artículo aplicable antes de proponerlo; el prompt está en `references/self-critique-prompt.md`. Es un filtro previo: la evidencia sigue siendo ejecutable (Regla 6).
- **Red teaming de la constitución.** Ejercicio adversarial trimestral: prompt injection contra la constitución misma, ambigüedad semántica en los artículos y artículos contradictorios entre sí. Se documenta en `red-team-constitution.md` con hallazgos y acciones.
- **Human-in-the-loop sistemático.** Requieren aprobación humana explícita: cambios a la constitución, cambios de MUST a SHOULD (o viceversa) y merges que toquen archivos críticos. La IA puede proponer; no aprueba.
- **Regla anti-alucinación.** Las afirmaciones del LLM sobre cumplimiento no son evidencia. Ver Antipatrón 6 y Regla 6.

---

## ⚠️ Antipatrones críticos (rojo absoluto)

### 1. Constitución copy-paste
> *"Tomé los 9 artículos del paper y los pegué tal cual"*

**Por qué es malo:** Los artículos genéricos no protegen un dominio específico. La constitución no contextualizada al sistema es teatro.
**Cómo lo detectas:** Pide que justifique 2 artículos con escenarios reales del proyecto. Si no puede, regresan a Fase 1.

### 2. Spec Theater (más sutil)
> Spec con bloque "Constitutional Compliance" lleno de texto vago: *"Esta feature respeta los artículos relevantes de seguridad"*.

**Por qué es malo:** Cumple la forma sin cumplir el fondo. Pasa code review pero no protege nada.
**Cómo lo detectas:** Cada referencia a artículo debe tener **mecanismo concreto y verificable**. Si la frase contiene "respeta", "considera", "tiene en cuenta" → es Spec Theater.

### 3. MUST tratado como SHOULD
> El equipo decide ignorar un MUST "porque no había tiempo".

**Por qué es malo:** Erosiona la constitución entera. Si un MUST puede ignorarse, todos pueden.
**Cómo lo detectas:** revisa si las excepciones están documentadas en `constitutional-exception-doc.md` con justificación firmada. Si no, es violación.

### 4. Constitución demasiado larga
> 25-30 artículos, 40 páginas, todo MUST.

**Por qué es malo:** Excede ventana de contexto del agente IA. El paper recomienda **3-5 principios por petición**, no la constitución entera.
**Cómo lo detectas:** si la constitución supera 12-14 artículos en total, sugiere reorganización por capas (core + dominio + integraciones).

### 5. Matriz de trazabilidad sin mantener
> La matriz se generó hace 6 meses y nadie la revisó.

**Por qué es malo:** Compliance roto = peor que no tener compliance. Da falsa seguridad.
**Cómo lo detectas:** si la última fecha de "verificación" en la matriz supera 30 días, sonar alarma.

### 6. Confiar en LLM para auditar su propio output
> *"Le pregunté a Claude si mi código cumple el Artículo III y dijo que sí"*

**Por qué es malo:** El LLM puede alucinar cumplimiento. La verificación debe ser **ejecutable**: test, lint, análisis estático.
**Regla:** ningún artículo se considera cumplido sin verificación ejecutable. Las afirmaciones de LLM no cuentan como evidencia.

### 7. Constitución sin ADR de adopción
> Los 9 artículos copiados sin decisión documentada de por qué son los correctos para este dominio.

**Por qué es malo:** sin ADR no hay trazabilidad de la decisión. Cuando alguien cuestione un artículo en seis meses, nadie recordará por qué está.
**Cómo lo detectas:** ausencia de `ADR-0001-constitution-adoption.md` o equivalente.

### 8. Deriva constitucional silenciosa
> La matriz de trazabilidad se actualizó la última vez hace 4 meses y nadie lo notó.

**Por qué es malo:** falsa seguridad. Un auditor externo lo detecta en minutos y el programa pierde credibilidad completa.
**Cómo lo detectas:** script de deriva en CI (ver Fase 6).

---

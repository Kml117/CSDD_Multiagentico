# Roadmap de desarrollo · CSDD Multi-Agent Engineering System

**De la v0.4.2 (hoy) a la v1.0** · Escrito el 3-nov-2026, actualizado el 4-nov-2026 (Windows y v0.4.2) · Para: quien ayude a Camilo a terminar de construirlo · Autora del borrador: Aurora (Claude)

> **Cómo leer las etiquetas.** Cada afirmación lleva su estatus: **[VALIDADO]** = lo comprobé con una prueba, un comando o leyendo el código; **[HIPÓTESIS]** = plausible, pero toca verificarlo en tu máquina; **[PROPUESTA]** = recomendación de diseño mía, discutible. Las horas son estimaciones **[HIPÓTESIS]** para alguien que ya programa en Python.

---

## 0. Empieza aquí (30 minutos)

1. Necesitas **Python 3.11 o más nuevo** y **git**. Comprueba: `python3 --version`. (En macOS el `python3` del sistema suele ser 3.9: instala 3.11+ con `brew install python@3.12` o `uv`. **[HIPÓTESIS]**, verifícalo.) **En Windows** necesitas además **Git para Windows** (trae `bash`, que usan `install.sh` y las pruebas) y un Python real: un `python3` que solo abre la Tienda de Microsoft es un alias vacío. Desde la 0.4.2 el instalador lo detecta solo; si tu Python está en otra ruta usa `CSDD_PYTHON`. **[VALIDADO por Claude Code en Windows, 3-nov]**
2. Descomprime el paquete y, desde su raíz, corre las pruebas:
   ```bash
   python3 -m unittest discover -s tests
   ```
   Resultado esperado: `Ran 24 tests … OK (expected failures=10)`; en **Windows** `OK (skipped=1, expected failures=10)` (`test_14` se omite allí). **[VALIDADO en Linux; en Windows lo corrió Claude Code con 12 pruebas, antes de las dos nuevas]**
   - **14 pruebas pasan** (13 en Windows): son lo que ya funciona (incluye `test_13` y `test_14`, que cubren consolas sin UTF-8 y el instalador con un Python roto).
   - **10 fallan a propósito** (`expectedFailure`, en `tests/test_known_gaps.py`): cada una es un paquete de trabajo de este roadmap. Cuando implementes uno, su prueba pasará, unittest dirá *"unexpected success"* y entonces **quitas el decorador** y queda como prueba de regresión.
3. Prueba el sistema en un repo de juguete (no en el de Camilo):
   ```bash
   mkdir /tmp/demo && cd /tmp/demo && git init -b main && git commit --allow-empty -m init
   bash <ruta-al-paquete>/scripts/install.sh .
   python3 .csdd/tools/csdd.py doctor
   python3 .csdd/tools/csdd.py session start
   ```
4. Lee **§1 y §3** de este documento, y luego el flujo diario en `EXECUTION_GUIDE.md` §7. Con eso entiendes el 90 %.
5. El trabajo empieza en **§5, versión v0.5** (verificar lo que hoy son hipótesis). No te saltes esa parte: lo demás se apoya en ella.

**El código que vas a tocar** vive en `skills/csdd-multiagent-orchestrator/assets/system/` (se instala como `.csdd/` en los repos). **No edites el `.csdd/` de un repo instalado**: está protegido por diseño y se pisa en la próxima instalación.

---

## 1. Qué se quiere lograr (en palabras de Camilo)

Camilo usa dos agentes de código, **Kimi Code** y **Claude Code**, desde VS Code. Quiere que en un mismo proyecto:

1. **Varios agentes trabajen a la vez**, cada uno en una pieza distinta de código.
2. **Se comuniquen entre ellos** (preguntas, entregas, bloqueos).
3. **Tengan roles** (quién planea, quién implementa, quién revisa) con límites reales.
4. **Nada llegue a producción** sin verificación independiente y sin su aprobación.

Ese es el criterio de éxito. Todo el roadmap se juzga contra esas cuatro frases.

### Lo que ya existe y funciona **[VALIDADO]**
| Parte | Qué hace hoy |
|---|---|
| **Roles con permisos reales** | 5 roles (Jefe Maestro, Jarvis, El Hombre de la Bolsa, Cortana, El Portero). Un *guard* (hook) bloquea escrituras, comandos y lecturas que su rol no permite. |
| **Contratos de tarea** | `csdd.py task new` con rutas permitidas (`allowed_paths`), requisitos, artículos, presupuesto y dependencias. Rechaza tareas que se pisan. |
| **Aislamiento** | Un `git worktree` por tarea de escritura y otro de revisión. |
| **Buzón** | Mensajes en archivos (6 tipos). Cada agente escribe solo en su bandeja; **solo el Jefe Maestro enruta**. |
| **Gate de integración** | `csdd.py merge` se niega sin un RESULT PASS de otro rol, con evidencia. |
| **Protocolo de sesión** | Sin `session start` no se modifica nada; `session end` deja bitácora con horas. |
| **Ruta crítica** | `csdd.py ruta`: recurso limitado, relojes, tramos, semáforo (reproduce las cifras de Corbeta). |
| **CI y constitución ejecutable** | Reglas Semgrep, gitleaks, `check_constitution_controls.py`, workflow `csdd-gate.yml`. |

### Lo que NO existe (y es la distancia hasta lo que Camilo quiere)
**Nada de lo anterior hace que los agentes *actúen solos*.** Hoy cada agente es una sesión que **Camilo abre a mano**, y un mensaje en el buzón **espera** a que alguien ejecute `csdd.py route` y a que otro agente decida mirar su bandeja. Concretamente faltan:

1. Quien **enrute** el buzón sin intervención (el "enrutador").
2. Que un agente **se entere** de que tiene un mensaje.
3. Que alguien **lance** los agentes de cada tarea (hoy se abren a mano).
4. Que alguien **decida qué tareas lanzar ahora** (el DAG, los límites, los choques de rutas).
5. Que **cuente tokens y costo**. Hoy solo cuenta llamadas a herramientas.
6. Que **mida** si todo esto de verdad rinde más que un solo agente.
7. Cerrar **brechas de seguridad** que conozco y están demostradas (§8).

---

## 2. Estado real hoy

| Componente | Estado | Evidencia |
|---|---|---|
| Guard, CLI, buzón, merge con gate, Comunista, presupuestos, bucles, sesión, ruta crítica, instalador (bash) | **PASS** | `tests/test_system.py`: 14 pruebas end-to-end en repos git temporales (Linux) |
| Reglas Semgrep (14) | **NOT_RUN** | Escritas con fixtures `# ruleid:`/`# ok:`; falta correr `semgrep --test` |
| gitleaks y pre-commit | **NOT_RUN** | No había gitleaks en el entorno de construcción |
| Hook de Claude Code | **PARCIAL** | Probado invocando `guard.py` con el JSON documentado; **no probado dentro de Claude Code real** |
| Identidad de subagente en el hook (`agent_type`) | **HIPÓTESIS** | `csdd.py doctor` lo detecta; falta verlo en una versión real |
| Hooks y nombres de herramientas de Kimi Code | **HIPÓTESIS** | Plantilla `integrations/kimi/hooks.example.toml`; esquema por verificar |
| Formato de agentes en `.agents/agents/` (Kimi) | **HIPÓTESIS** | Generado por `sync_agents.py` sin verificar contra la documentación |
| Windows: instalador, `doctor`, `session start` | **PARCIAL** | Claude Code (3-nov): `Install.ps1` OK; `doctor` 11 PASS y 1 UNKNOWN esperado; 12 pruebas OK con Git portátil y `PYTHONUTF8=1`. Sin esa variable fallaban 3 por tildes rotas: **corregido en 0.4.2** (UTF-8 forzado, validado emulando una consola heredada en Linux; **falta reconfirmar en Windows real**) |
| Windows: `Install.ps1` y `settings.json` sin BOM | **NO PROBADO** | Cambio de 0.4.2 sin PowerShell disponible para ejecutarlo. Por probar en Windows |
| Guard con comandos de PowerShell | **NO CUBIERTO** | El guard analiza sintaxis bash (`Set-Content`, `Remove-Item` no se ven): WP-V3 |
| macOS (bash 3.2, Python del sistema) | **NO PROBADO** | Camilo tiene un Mac (Corbeta) y hoy trabaja también en Windows; el Mac está por probar |
| Workflow de CI (`csdd-gate.yml`) | **NO PROBADO** | Se valida en el primer PR real |

---

## 3. Arquitectura en una página

```text
                 ┌───────────────── PROPIETARIO (Camilo) ─────────────────┐
                 │ aprueba gates · crea autorizaciones · ratifica ·       │
                 │ fusiona a main · abre sesiones con ALERTAS             │
                 └────────────────────────────┬───────────────────────────┘
                                              │
 ┌────────────────────────────────────────────▼───────────────────────────────────────────┐
 │ MOTOR (código determinista, proceso del propietario)        ← AQUÍ ESTÁ EL HUECO       │
 │ router (watch) · dispatcher · runner · cola de integración                             │
 │ usa las MISMAS funciones de reglas que la CLI (csdd_core, csdd.py)                     │
 └────────────┬───────────────────────────────┬───────────────────────────────┬───────────┘
              │ lanza                         │ lanza                         │ lanza
              │                               │                               │
      ┌───────▼───────┐               ┌───────▼───────┐               ┌───────▼───────┐
      │  Jefe Maestro │               │ H. de la Bolsa│               │    Cortana    │
      │ (Claude Code) │               │  (Kimi Code)  │               │ (Claude Code) │
      └───────┬───────┘               └───────┬───────┘               └───────┬───────┘
              │                               │                               │
              └───────────────────────────────┬───────────────────────────────┘
                                              │ cada llamada a herramienta pasa por el guard
                                 ┌────────────────────────┐
                                 │ GUARD (hooks/guard.py) │
                                 └────────────────────────┘
                                              │
              .project/ (en el worktree principal, compartido por todos):
              mailbox/ · state/tasks · state/approvals · state/sessions · log/events.jsonl

 Los AGENTES (LLM) son sesiones de Claude Code o Kimi Code, cada una en su worktree.
 El GUARD lee roles.toml y bloquea o permite cada llamada. El MOTOR no existe todavía.
```

**La idea central del roadmap [PROPUESTA]:** separar **MOTOR** (código determinista: enruta, decide qué se lanza, integra) de **AGENTES** (LLM: piensan y escriben). Hoy "Jefe Maestro" mezcla las dos cosas en una sesión de LLM, y por eso todo depende de que alguien la ejecute a mano. Si el motor es código, el Jefe Maestro-LLM queda para lo que de verdad necesita razonar: planear, cortar tareas, resolver bloqueos e informar.

**Por qué el motor es seguro de automatizar [VALIDADO]:** el guard restringe a los **agentes** (llamadas a herramientas dentro de Claude Code/Kimi), no a un proceso que Camilo corre en su terminal. Por eso `route` y `merge` están prohibidos para agentes pero un motor del propietario sí puede ejecutarlos. **Pero** el motor hereda la obligación de cumplir las mismas reglas: debe **importar** las funciones existentes (`merge_preconditions`, `_validate_for_route`, etc.), no reimplementarlas. Una sola fuente de reglas.

---

## 4. Invariantes: lo que NO se puede romper

Cada cambio debe conservar esto. Las 14 pruebas de `test_system.py` ya vigilan casi todo; si una falla, tu cambio rompió una garantía.

| # | Invariante | Dónde se hace cumplir |
|---|---|---|
| I-1 | **Fail-secure:** si el guard falla evaluando una escritura o un comando, **bloquea**. | `guard.py main()` · `test_09` |
| I-2 | **Nadie se autoaprueba:** el dueño de una tarea no registra su propio RESULT. | `csdd.py cmd_result`, `merge_preconditions` · `test_05` |
| I-3 | **Sin PASS independiente no hay merge** (y El Portero puede bloquear). | `merge_preconditions` · `test_05` |
| I-4 | **Rutas protegidas** (constitución, hooks, CI, `.csdd/`, `.claude/`, aprobaciones, `roles.toml`) no las escribe ningún agente, ni con autorización Comunista. | `roles.toml [defaults]`, `Ctx.check_write_path` · `test_02`, `test_07` |
| I-5 | **Secretos** (`.env`, `*.pem`, claves): ningún agente los lee ni escribe. | `secret_paths` · `test_03` |
| I-6 | **Solo el propietario** crea autorizaciones y abre sesiones con ALERTAS. | `check_cli` · `test_05`, `test_10`, `test_11` |
| I-7 | **Un contrato no se pisa con otro:** `allowed_paths` sin solapamiento entre tareas activas. | `cmd_task new` · `test_05` |
| I-8 | **`NOT_RUN` y `UNKNOWN` nunca son `PASS`;** PASS exige evidencia. | `cmd_result` · `test_05` |
| I-9 | **Sin sesión vigente no se modifica nada.** | `session_gate` · `test_10` |
| I-10 | **El motor nunca fusiona a `main`.** (Hoy es una brecha: ver WP-R6.) | — |
| I-11 | **Cero dependencias externas:** solo librería estándar de Python 3.11+. Extras opcionales (SDK de un agente) van en módulos que se importan solo si se usan. | decisión de diseño |

---

## 5. Hoja de ruta por versiones

Cada **WP** (paquete de trabajo) tiene: objetivo, por qué, diseño sugerido, **criterios de aceptación** (qué debe pasar para darlo por hecho), esfuerzo y riesgos. Las pruebas `test_gap_*` ya existen para la mayoría.

### Resumen

| Versión | Nombre | Qué da | Horas (HIPÓTESIS) | ¿Camilo necesita que esté? |
|---|---|---|---|---|
| **v0.5** | Probar lo que falta | Convierte hipótesis en hechos; funciona en Mac, Windows y CI | 10–14 h (más hasta 12 h si se decide cubrir PowerShell) | Sí, antes de seguir |
| **v0.6** | El enrutador vivo | Agentes que se enteran, se lanzan y trabajan en paralelo solos | 37–58 h | **Sí: es lo que pidió** |
| **v0.7** | Cerrar la puerta | Seguridad demostrada | 33–69 h (el rango lo domina WP-S1: parche 6 h, sandbox 25 h) | Antes de usarlo con datos reales |
| **v0.8** | Ver y medir | Costos, panel y evaluación contra un solo agente | 24–38 h | Para decidir con datos |
| **v1.0** | Empaquetar | `pipx install`, documentación, MCP opcional | 24–40 h (14–24 h sin el MCP opcional) | Cuando se vaya a compartir |

**Ruta mínima hacia "funciona como quiero": v0.5 + v0.6 ≈ 47–72 h.** Con 8 h/semana son unas 6–9 semanas. **[HIPÓTESIS]**: el runner (WP-R3) es la parte más incierta.

---

### v0.5 · Probar lo que falta

#### WP-V0 · Verificar las hipótesis con herramientas reales (4–6 h) · prioridad **P0**
- **Por qué:** media arquitectura depende de supuestos sobre Claude Code y Kimi Code que no pude probar sin ellos.
- **Qué comprobar y dejar documentado en `references/runtime-claude-code-kimi.md`:**
  1. Claude Code: ¿el JSON del hook trae la identidad del subagente (`agent_type` u otro)? `csdd.py doctor` ya lo detecta si hay llamadas registradas en `.project/log/hook-payload-keys.jsonl`. Esto decide **Modo A o Modo B**.
  2. Claude Code: ¿los hooks `UserPromptSubmit`/`SessionStart` pueden **inyectar contexto** con su salida? (necesario para WP-R2).
  3. Kimi Code: esquema real de `[hooks]` en `~/.kimi-code/config.toml`, **nombres exactos** de sus herramientas (`ReadFile`, `WriteFile`, `StrReplaceFile`, `Shell` son suposiciones), y si pasa `cwd`.
  4. Kimi Code: formato real de definición de agentes y si hay **modo no interactivo** (para WP-R3).
  5. Correr `semgrep --test .csdd/policy/semgrep/` y arreglar las reglas que fallen. Instalar gitleaks y correr el pre-commit.
- **Aceptación:** tabla "supuesto → resultado → fecha → versión de la herramienta" en el documento; `semgrep --test` en verde; `csdd.py doctor` sin UNKNOWN en una máquina real.
- **Riesgo:** necesitas Claude Code y Kimi Code instalados con la cuenta de Camilo. **[Pide acceso en una sesión conjunta]**

#### WP-V1 · CI del propio paquete y matriz de sistemas (3–4 h) · **P0**
- **Qué:** workflow que corra `python3 -m unittest discover -s tests` en Ubuntu y macOS, con Python 3.11, 3.12 y 3.13, más `semgrep --test` y `build_claude_web.py`.
- **Aceptación:** badge verde en las 6 combinaciones. Si macOS falla (bash 3.2, `sed`, rutas), arréglalo aquí.

#### WP-V2 · Que no se rompa con Python < 3.11 (3–4 h) · **P1**
- **Problema:** todo usa `tomllib` (3.11+). En Macs con Python 3.9 falla con un error poco claro. **Parcialmente resuelto en 0.4.2:** los instaladores ya prueban cada Python candidato (descartan el alias vacío de la Tienda en Windows y los < 3.11) y muestran un error claro; falta el lanzador `csdd` de la Alternativa A (por eso baja de 3–4 h a 1–2 h).
- **Alternativa A:** un lanzador `csdd` (shell) que busque `python3.11+` y, si no hay, explique cómo instalarlo. *Pro:* cero código nuevo en el runtime. *Contra:* sigue exigiendo instalar Python.
- **Alternativa B:** dependencia opcional `tomli` como respaldo en 3.9/3.10. *Pro:* funciona en más máquinas. *Contra:* rompe I-11 (aunque sea opcional) y hay que probar 3.9.
- **[PROPUESTA]** A.

#### WP-V3 · Windows (decidir nivel de soporte) (0–12 h) · **P3**
- **Hecho [VALIDADO por Claude Code en Windows, 3-nov]:** lo básico funciona (instalador, `doctor`, sesión, 12 pruebas con Git para Windows). **Hecho [VALIDADO por lectura de código]:** el guard analiza sintaxis **bash**; en PowerShell (`Set-Content`, `Remove-Item`) no ve las escrituras. Quien use Claude Code en Windows con una terminal PowerShell queda con un guard parcial. Camilo ya usa Windows para el paquete, así que **sube de prioridad a P2** si el sistema se va a usar ahí con agentes reales.
- **Alternativa A:** declarar en el README que en Windows los agentes deben usar **Git Bash** como terminal (hoy lo único probado) y que PowerShell no está cubierto por el guard (0 h). **Alternativa B:** analizar también sintaxis PowerShell (≈12 h, y el análisis de comandos ya es el punto débil: ver WP-S1). **[PROPUESTA]** A; B solo si se usa Claude Code con PowerShell de verdad.

---

### v0.6 · El enrutador vivo (el corazón del roadmap)

> Objetivo de la versión: **un comando lanza todo el flujo y los agentes trabajan en paralelo sin que Camilo abra sesiones a mano.** Demo de aceptación al final de esta sección.

#### WP-R1 · `csdd.py watch`: enrutar el buzón en continuo (4–6 h) · **P0** · prueba: `test_gap_router_watch_exists`
- **Qué:** proceso que cada N segundos (o con eventos del sistema de archivos) ejecuta la lógica de `cmd_route`: valida, mueve de outbox a inbox, rechaza lo inválido con su `.reason.txt`. `--once` hace una pasada y sale (para pruebas y cron).
- **Diseño [PROPUESTA]:** **extrae** la lógica de `cmd_route` a una función pura en `csdd_core` (o un módulo `engine/router.py`) y haz que `cmd_route` y `watch` la llamen. No dupliques validaciones.
- **Se ejecuta como proceso del propietario**, nunca desde una sesión de agente. El guard seguirá bloqueando `route` a los agentes.
- **Aceptación:** (1) `watch --once` rutea lo mismo que `route`; (2) un mensaje inválido (TASK que no viene del líder, RESULT de quien no puede) se rechaza igual que hoy; (3) dos `watch` simultáneos no duplican mensajes (bloqueo de archivo o `seen_message_ids` atómico); (4) la prueba `test_gap_router_watch_exists` pasa y se agregan pruebas de los puntos 2 y 3.
- **Riesgo:** condiciones de carrera con `os.replace`/mover archivos. **Alternativa A:** `fcntl.flock` en un archivo de bloqueo (solo Unix). **Alternativa B:** pasar el estado a SQLite (ver D-4).

#### WP-R2 · Que el agente **se entere** del mensaje (hook de bandeja) (3–5 h) · **P0** · prueba: `test_gap_inbox_is_injected_into_agent_context`
- **Problema:** un mensaje en una inbox no sirve si el agente no la mira.
- **Diseño [PROPUESTA]:** `hooks/inbox_hook.py` que, en `SessionStart` y `UserPromptSubmit`, imprima un resumen corto de la bandeja pendiente del rol resuelto (tipo, de quién, tarea, summary de ≤ 600 caracteres) y avise si hay un BLOCKER. Debe ser **rápido (< 200 ms)**, **de solo lectura** y **no fallar nunca** (si falla, no imprime nada).
- **Dependencia:** WP-V0 punto 2 (¿el hook puede inyectar contexto?) y 3 (¿Kimi lo soporta?). Si alguno no puede, **alternativa:** el runner (WP-R3) pega el resumen de la bandeja en el prompt inicial de cada ejecución.
- **Seguridad [VALIDADO como riesgo]:** el contenido de los mensajes es **dato no confiable** (inyección de prompts entre agentes, OWASP Agentic ASI07). El hook debe imprimirlo **claramente delimitado como dato**, truncado y sin ejecutar nada de él.
- **Aceptación:** con un mensaje pendiente, el hook imprime un resumen delimitado; con la bandeja vacía no imprime nada; con la bandeja corrupta no falla.

#### WP-R3 · **Runner**: lanzar un agente por tarea (12–20 h) · **P0** · prueba: `test_gap_runner_launches_agents_headless`
- **Qué:** `csdd.py run <TAREA> [--dry-run]` abre el agente correcto en el worktree de la tarea, con el rol y el prompt de la tarea, sin interfaz, y deja logs y resultado.
- **Diseño [PROPUESTA] — adaptadores:** define una interfaz mínima y un adaptador por herramienta, en `engine/adapters/`:
  ```text
  Adapter.build_command(role, task, worktree, prompt) -> (argv, env)   # incluye CSDD_ROLE y la tarea
  Adapter.capabilities -> {headless, hooks, usage_report, model_flag}
  Adapter.parse_output(stdout) -> {result_text, tokens_in, tokens_out, cost}   # si lo reporta
  ```
  Adaptadores: `claude_code` (modo impresión `claude -p` con `--output-format json`, `--allowedTools`, etc. **[HIPÓTESIS: confirma las banderas con `claude --help` en tu versión]**), `kimi_code` (**[HIPÓTESIS]**: depende de WP-V0 punto 4) y `generic` (cualquier CLI que reciba el prompt por argumento o stdin). La elección de adaptador sale de `system.toml` / `roles.toml` (`runtime_default` ya existe).
- **Responsabilidades del runner:** (1) calcular el prompt desde el contrato de tarea + `AGENTS.md` + bandeja; (2) exportar `CSDD_ROLE` y la tarea; (3) **timeout y presupuesto** (`max_minutes`; el guard ya corta por llamadas); (4) capturar stdout/stderr a `.project/artifacts/evidence/<T>/run-*.log`; (5) registrar en `events.jsonl` inicio, fin, código de salida y uso; (6) si el agente termina sin `handoff`, marcar la tarea como STUCK con motivo.
- **Alternativa A (CLI en modo impresión):** simple, sin dependencias, funciona con cualquier agente que lo ofrezca. *Contra:* poca interacción; si el agente se detiene a preguntar, queda colgado → necesita timeout.
- **Alternativa B (SDK / ACP):** controlar el agente por su SDK (Claude Agent SDK) o por **Agent Client Protocol** (Kimi Code expone un servidor ACP **[VALIDADO según la investigación del 3-nov; verifica versión]**). *Pro:* sesión interactiva y eventos de uso fiables. *Contra:* dependencia nueva (rompe I-11 salvo extra opcional) y más trabajo.
- **[PROPUESTA]** empieza con A para Claude y para el adaptador `generic`; decide B para Kimi según WP-V0.
- **Aceptación:** `run T-001 --dry-run` imprime el comando exacto; `run T-001` con un adaptador **falso** (un script de prueba que simula al agente: escribe un archivo permitido, hace commit y llama a `csdd.py handoff`) deja la tarea en IN_REVIEW; si el falso intenta escribir fuera de rutas, el guard lo bloquea y el log lo muestra; un agente colgado muere por timeout y la tarea queda STUCK. **Escribe primero el adaptador falso:** permite probar todo el motor sin gastar un token.
- **Riesgo grande:** cada herramienta cambia su CLI a menudo; aísla todo en el adaptador y deja una prueba de humo que se pueda correr con las herramientas reales de forma manual.

#### WP-R4 · **Dispatcher**: decidir qué tareas lanzar ahora (8–12 h) · **P0** · prueba: `test_gap_dispatcher_exists`
- **Qué:** `csdd.py dispatch [--dry-run]` mira todas las tareas y lanza (con el runner) las que estén listas.
- **Una tarea está lista si:** estado QUEUED o REWORK; todas sus `depends_on` están DONE; sus `allowed_paths` no se pisan con tareas activas (ya hay `globs_overlap`); hay cupo (`max_parallel_write_tasks`); el presupuesto y los reintentos lo permiten; no hay un BLOCKER sin resolver sobre ella.
- **Diseño [PROPUESTA]:** función pura `ready_tasks(state) -> list` con pruebas unitarias exhaustivas (es lógica de planificación: el sitio ideal para pruebas rápidas de propiedades). El comando solo orquesta.
- **Aceptación:** con un DAG A→B y C independiente, y cupo 2: lanza A y C, no B; al terminar A, lanza B. Dos tareas con rutas que chocan nunca corren a la vez (aunque haya cupo).

#### WP-R5 · Revisión y cola de integración automáticas (8–12 h) · **P1**
- **Qué:** al llegar un HANDOFF: crear el worktree de revisión y lanzar a Cortana (y a El Portero si `security_review_required`), **de preferencia con un modelo distinto al que implementó** (`cross_model_verification` ya existe en `system.toml` como intención; falta hacerlo cumplir). Al llegar RESULT PASS completo: poner la tarea en la **cola de integración** (una a la vez), correr `merge` y luego `verify`; si falla, REWORK.
- **Aceptación:** un flujo completo T-001 → handoff → revisión → merge ocurre sin intervención con adaptadores falsos; si el revisor es el mismo adaptador que el implementador, se avisa en el informe.

#### WP-R6 · Rama de integración: el motor **nunca** fusiona a `main` (2–3 h) · **P0** · invariante I-10
- **Hecho [VALIDADO leyendo `cmd_merge`]:** `csdd.py merge` fusiona en la rama que esté activa en el worktree principal, **sin comprobar cuál es**. Si es `main`, un agente (o el motor) integraría directo a `main`. La regla de Camilo (Corbeta) es que **solo él fusiona PRs a `main`**.
- **Diseño [PROPUESTA]:** `[orchestration] integration_branch = "csdd/integration"` en `system.toml`; `merge` se niega si la rama activa es `base_branch` y no hay `--allow-main` (solo propietario); el flujo normal integra en `csdd/integration` y Camilo abre el PR a `main`.
- **Aceptación (escribe la prueba primero):** `merge` desde `main` → error claro; desde `csdd/integration` → funciona; el guard bloquea `--allow-main` a los agentes.

#### Demo de aceptación de v0.6
Con adaptadores falsos primero y luego con Claude Code y Kimi Code reales, en un repo de juguete: 3 tareas (T1 y T2 con rutas distintas y sin dependencia, T3 depende de T1). **Un solo comando** (`csdd.py dispatch`) debe: lanzar T1 y T2 a la vez, pasar cada una a revisión con otro modelo, integrar en `csdd/integration` en orden, lanzar T3, y dejar un `report`. Camilo solo interviene para aprobar el PR final. **Si esto funciona, el sistema hace lo que pidió.**

---

### v0.7 · Cerrar la puerta (seguridad)

> Antes de usar el sistema con datos reales de clientes (Cifra) o con secretos, esta versión es obligatoria. **[VALIDADO]** Las brechas 1 y 2 están demostradas con `test_known_gaps.py`.

#### WP-S1 · Intérpretes en línea: `python -c`, `node -e` (6–25 h) · **P0 de seguridad** · prueba: `test_gap_interpreter_inline_cannot_write_outside_scope`
- **Hecho [VALIDADO]:** el guard bloquea `echo x > archivo`, pero **deja pasar** `python3 -c "open('cualquier/ruta','w')..."` y `node -e "…writeFileSync…"`. Un agente puede escribir fuera de su `allowed_paths`. Además, **`pytest` o un script de build pueden escribir donde quieran**: ningún análisis de comandos lo evitará del todo.
- **Alternativa A (parche, 6–10 h):** bloquear patrones de intérprete en línea (`python -c`, `node -e`, `perl -e`, `ruby -e`, `bash -c` con escrituras) y analizar con un parser de shell real en vez de expresiones regulares. *Pro:* rápido. *Contra:* es "gato y ratón": siempre habrá otra forma.
- **Alternativa B (raíz, 15–25 h):** **sandbox del sistema de archivos**: el runner lanza al agente en un contenedor / `sandbox-exec` (macOS) / bubblewrap (Linux) donde **solo su worktree es escribible**. *Pro:* resuelve la causa y también los puertos/BD (WP-S5). *Contra:* más complejo; en macOS es distinto que en Linux.
- **[PROPUESTA]** A ahora, como mitigación inmediata; B como objetivo real. El guard **sigue siendo útil** (mensajes claros y bloqueo temprano) pero no puede ser la única barrera, y la documentación debe decirlo.
- **Aceptación (A):** la prueba pasa y se agrega un **corpus de comandos** (permitidos/bloqueados) como prueba de regresión; (B): un agente de prueba no puede escribir fuera de su worktree ni con `python -c`.

#### WP-S2 · Identidad del rol que no se pueda falsificar (6–8 h) · **P0 de seguridad** · prueba: `test_gap_role_identity_cannot_be_forged`
- **Hecho [VALIDADO]:** el rol se decide por (1) identidad del subagente si el hook la envía, (2) variable `CSDD_ROLE`, (3) archivo `.csdd-task` del worktree. Un `python -c` puede **reescribir `.csdd-task`** y cambiar de rol.
- **Diseño [PROPUESTA]:** el **runner** (WP-R3) emite un token firmado con HMAC `(rol, tarea, worktree, expira)` usando un secreto del propietario **fuera del repo** (`~/.config/csdd/`), lo pasa por variable de entorno, y el guard **verifica la firma** en vez de confiar en el archivo. Sin token válido, el guard asume el rol de menor privilegio.
- **Aceptación:** reescribir `.csdd-task` no cambia el rol efectivo; un token vencido o de otra tarea se rechaza. **Depende de** WP-R3.

#### WP-S3 · Bitácora de eventos a prueba de manipulación (3–4 h) · P1 · prueba: `test_gap_events_log_is_tamper_evident`
- **Qué:** cada línea de `events.jsonl` incluye `prev_hash` (hash de la anterior) y `csdd.py verify` detecta cortes o alteraciones. **Límite honesto:** quien controle el archivo puede reescribirlo entero; esto detecta ediciones parciales, no un atacante con control total (para eso, anclar el último hash en otro lugar, p. ej. en el commit).

#### WP-S4 · Autorizaciones firmadas (4–6 h) · P1 · prueba: `test_gap_approvals_are_signed`
- **Hecho [VALIDADO]:** las autorizaciones Comunista son TOML sin firma; el guard impide que un agente escriba ahí, pero el sistema no verifica quién las creó. **Diseño:** firma HMAC con el secreto del propietario (el mismo de WP-S2); el guard ignora autorizaciones sin firma válida.

#### WP-S5 · Aislar puertos, bases de datos y servicios por tarea (10–20 h) · P2
- **Hecho [VALIDADO por documentación de git]:** un worktree aísla **archivos**, no puertos, bases, procesos ni cachés. Dos tareas con pruebas que usan el puerto 3000 o la misma base de datos de desarrollo se pisan. **Alternativa A:** asignar puertos y nombres de base por tarea (variables de entorno que calcula el runner). **Alternativa B:** contenedores por tarea (se fusiona con WP-S1-B). **[PROPUESTA]** A primero.

#### WP-S6 · Revisión de seguridad del propio motor (4–6 h) · P1
- Usar el skill `cybersecurity` / revisión OWASP sobre `guard.py`, `csdd.py`, `sesion.py` y el runner; atención a **inyección de comandos** al construir `argv` del adaptador (nunca `shell=True`), a **traversal de rutas** en `task_id`/`message_id` (hoy se valida con regex `[A-Za-z0-9._-]{1,64}`; mantenerlo) y a tratar **todo contenido de mensajes como no confiable**.

---

### v0.8 · Ver y medir

#### WP-O1 · `csdd.py report`: llamadas, tokens y costo (6–10 h) · P1 · prueba: `test_gap_cost_report_exists`
- **Hecho [VALIDADO]:** hoy solo se cuentan **llamadas a herramientas** por tarea y rol, no tokens ni dinero. Con el runner (WP-R3), el adaptador puede capturar el uso que reporte cada CLI **[HIPÓTESIS: Claude en modo JSON lo reporta; Kimi por verificar]**. Si una herramienta no lo reporta, el reporte lo dice ("sin dato") en vez de inventarlo.
- **Aceptación:** tabla por tarea y por rol: llamadas, minutos, tokens (si hay), costo (si hay), reintentos, resultado; y total por tramo, para alimentar `ruta_critica.py` (`horas_reales`).

#### WP-O2 · Panel de solo lectura (6–8 h) · P2
- HTML estático generado desde `events.jsonl` y el estado de tareas: tareas por estado, bandejas, últimos bloqueos del guard, semáforo de la ruta crítica. **Sin servidor.** Alternativa: salida en terminal (TUI) con la biblioteca estándar.

#### WP-E1 · Evaluación: ¿rinde más que un solo agente? (12–20 h) · **P0 para decidir** · prueba: `test_gap_eval_harness_exists`
- **Por qué es la más importante de esta versión:** la investigación del 3-nov (fuentes citadas allí) encontró que en benchmarks de código **los sistemas multiagente suelen rendir *peor* que un solo agente** y cuestan entre 1,6 y 6 veces más tokens, y que la mayoría de los fallos son de especificación y coordinación, no del modelo. **[VALIDADO como hallazgo de esa investigación; no lo he reproducido aquí.]** El sistema puede ser técnicamente perfecto y aun así **no valer la pena** para el tipo de tareas de Camilo. Hay que medirlo.
- **Qué construir:** `.csdd/evals/` con **15–20 tareas reales de Corbeta** (con criterio de aceptación automático) y un comando que las corra en **tres modos**: (1) solo Claude, (2) solo Kimi, (3) líder + trabajadores con el sistema. Métricas: éxito del gate, **costo por tarea exitosa**, tiempo de reloj, intervenciones humanas, bloqueos del guard.
- **Aceptación:** informe comparativo reproducible. **Regla de decisión [PROPUESTA]:** si el modo 3 no gana en costo por tarea exitosa o en tiempo de reloj **en tareas paralelizables**, no es el modo por defecto.
- **Necesita de Camilo:** escoger las tareas canario. Sin eso este WP no empieza.

---

### v1.0 · Empaquetar

| WP | Qué | Horas | Nota |
|---|---|---|---|
| **WP-P1** | Convertir `csdd.py` (918 líneas, un solo archivo) en un paquete Python con módulos (`engine/`, `cli/`, `guard/`); instalable con `pipx install` y comando `csdd`. Mantener `install.sh` por compatibilidad | 8–12 | Hacerlo **después** de v0.6, no antes: refactorizar con el diseño aún en movimiento sale caro |
| **WP-P2** | Servidor **MCP** opcional que exponga la cola y el buzón como herramientas (`send_message`, `list_tasks`, `report_result`) para que los agentes lo usen sin shell | 10–16 | **[PROPUESTA] opcional.** Solo si el shell resulta frágil; MCP es la vía estándar agente↔herramienta |
| **WP-P3** | Documentación para terceros, guía de contribución, versionado semántico, `CHANGELOG` automatizado | 4–8 | |
| **WP-P4** | Revisión legal/IP si el sistema se va a compartir o usar en Cifra: licencia del paquete y de lo que escriba el colaborador | 2–4 | Ver D-5 |

---

## 6. Decisiones abiertas (cada una con dos alternativas)

| # | Decisión | Alternativa A | Alternativa B | Mi recomendación **[PROPUESTA]** | ¿Quién decide? | ¿Antes de…? |
|---|---|---|---|---|---|---|
| **D-1** | ¿Cómo se entera un agente de un mensaje? | Hooks que inyectan la bandeja (WP-R2) | El runner pega la bandeja en el prompt inicial | A si WP-V0 confirma que los hooks inyectan contexto; si no, B | Se decide con WP-V0 | WP-R2 |
| **D-2** | ¿Cómo se lanza cada agente? | CLI en modo impresión | SDK / ACP | A para empezar | Colaborador + Camilo | WP-R3 |
| **D-3** | ¿El Jefe Maestro sigue siendo una sesión LLM? | Sí, solo para planear/informar; el motor hace el resto | No: todo programado, el LLM solo se consulta | A | Camilo | v0.6 |
| **D-4** | ¿Dónde vive el estado (tareas, mensajes)? | Archivos JSON (hoy) con `flock` | SQLite (librería estándar) | A hasta que aparezcan carreras reales; B si el motor las provoca | Colaborador | WP-R1 |
| **D-5** | ¿De quién es lo que escriba el colaborador? *(Camilo, 4-nov: no es prioridad todavía; se resuelve antes de que el colaborador escriba código, no antes de recibir el paquete)* | Cesión de derechos al proyecto de Camilo (por escrito) | Licencia abierta compartida | Cualquiera, **pero por escrito y antes de empezar** (aunque sea un acuerdo de una página) | **Camilo y su amigo** | **Antes de escribir código** |
| **D-6** | ADR-0002 parte B: TLS, ¿artículo X o anexo MUST en el V? | Artículo X "Transporte seguro" | Anexo dentro del Art. V | A solo para proyectos con datos sensibles | Camilo | v0.7 |
| **D-7** | ADR-0004 parte 3: ¿artículo "Estado verificable"? | Control del Art. IX (hoy) | Artículo de dominio MUST | A base; B en Corbeta | Camilo | v0.6 |
| **D-8** | ¿Dónde integra el motor? | Rama `csdd/integration` + PR del propietario a `main` | Directo en `main` | **A, obligatorio** (invariante I-10) | Camilo (ya lo exige en Corbeta) | WP-R6 |
| **D-9** | Nivel de soporte de Windows | Git Bash como terminal de los agentes; PowerShell sin cobertura | Soporte nativo de PowerShell | A | Camilo | WP-V3 |

---

## 7. Qué NO construir (y por qué)

Según la investigación del 3-nov (con fuentes en su informe) y lo que vi construyendo esto:

| No hagas | Por qué | Qué hacer en su lugar |
|---|---|---|
| **Protocolo A2A** entre agentes | Pensado para agentes remotos entre organizaciones; aquí todo corre en una máquina y archivos + git bastan | Buzón de archivos (hoy) o MCP si hace falta |
| **Reescribir en LangGraph / CrewAI / AutoGen** | Esos marcos orquestan **llamadas a modelos**, no CLIs de código ya existentes (Claude Code, Kimi Code) | El runner con adaptadores |
| **Debates entre agentes / asignación de roles por LLM** | Sin evidencia a favor en programación; aumenta tokens y fallos de coordinación | Roles fijos y reglas deterministas |
| **Memoria vectorial compartida** | Es superficie de ataque (envenenamiento de contexto, OWASP ASI06) y no es necesaria | Spec + handoffs + `events.jsonl` |
| **Más de 2–3 agentes en paralelo** | Con una persona revisando, el cuello de botella eres tú | `max_parallel_write_tasks = 2` |
| **Meter los 9 artículos en `AGENTS.md`** | Un estudio de 2026 mostró que los archivos de contexto largos suben el costo sin mejorar el resultado | `AGENTS.md` corto; detalle en las skills |
| **Confiar en el guard como única barrera** | Demostrado que se puede rodear (WP-S1) | CI + sandbox + revisión independiente |

---

## 8. Riesgos y límites conocidos

1. **El guard se puede rodear** con intérpretes en línea y con cualquier programa que escriba archivos (pruebas, scripts de build). **[VALIDADO]** Es la brecha más seria (WP-S1, S2).
2. **Los hooks de Kimi Code no bloquean si fallan** (exit distinto de 2 = permitir; sin lista fija de herramientas verificada). **[VALIDADO por la documentación consultada en nov 2026]** Por eso CI y la revisión de alcance de Cortana (`git diff` contra `allowed_paths`) son obligatorios.
3. **El rol se decide por variable de entorno o archivo**, no por una credencial. Es un sistema de **honor con alarmas**, no de aislamiento real, hasta WP-S2.
4. **No cuenta tokens ni dinero** hasta WP-O1.
5. **`csdd.py merge` puede fusionar a `main`** si es la rama activa (WP-R6).
6. **La detección de documentos desfasados** (`estado`) es por patrones que define cada proyecto: da falsos positivos.
7. **La calculadora de ruta crítica** no busca el orden óptimo; evalúa el orden dado. La probabilidad PERT supone tareas independientes.
8. **Dependencias de herramientas que cambian rápido** (Claude Code, Kimi Code): cualquier bandera o esquema puede cambiar. Todo lo que dependa de ellas va dentro de adaptadores, con una prueba de humo manual.
9. **Cambiar `roles.toml`, hooks o CI** es decisión del propietario y no se puede hacer desde un agente: el colaborador lo hace en el repo fuente (`skills/.../assets/system/`), no en un `.csdd/` instalado.

---

## 9. Cómo trabajar juntos

1. **Ten tu propia rama y PR por cada WP.** Camilo ratifica y fusiona a `main`; **ningún agente fusiona**.
2. **Prueba primero (Test-First).** Para cada WP: la prueba `test_gap_*` ya existe, o escríbela antes de programar (WP-R6 y los de la lista de aceptación que no tienen prueba todavía).
3. **Mantén en verde `python3 -m unittest discover -s tests`.** Un cambio que rompe una de las pruebas que pasan rompió un invariante (§4).
4. **Dónde vive el código:** `skills/csdd-multiagent-orchestrator/assets/system/` (runtime), `tests/`, y las skills en `skills/*/SKILL.md`. Tras tocar una skill: `python3 scripts/build_claude_web.py` y sube los `.zip` que cambiaron.
5. **Toda decisión de diseño con alternativas va en un ADR** (`docs/adr/`, plantilla en `templates/decision-record.md`): contexto, **dos opciones o más**, decisión, consecuencias. Camilo decide las reservadas (§6).
6. **Cero dependencias externas** (I-11). Si necesitas una, propónla en un ADR como extra opcional.
7. **Usa el propio sistema** (*dogfooding*): `session start` y `session end` con horas, worktrees para trabajo en paralelo, nada de `git add -A`. Si el sistema te estorba, eso es un hallazgo: anótalo.
8. **No compartas secretos.** El paquete no contiene ninguno **[VALIDADO]**: se revisó con una búsqueda de claves y correos. El repositorio de Corbeta y `datos-privados/` **no** forman parte de esto y no se envían.
9. **Cada viernes (propuesta):** 15 minutos para revisar `csdd.py ruta`, horas reales y qué WP sigue.

### Sugerencia de primeras cuatro semanas (8 h/semana) **[HIPÓTESIS]**
| Semana | Entrega |
|---|---|
| 1 | Decisión D-5 (acuerdo escrito, **antes de código**) + WP-V0 en sesión conjunta + WP-V1 (CI) |
| 2 | WP-R1 (`watch`) + WP-R6 (rama de integración) + adaptador **falso** |
| 3 | WP-R3 (runner) con el adaptador falso y Claude en modo impresión |
| 4 | WP-R4 (dispatcher) + primera demo de aceptación con adaptadores falsos |

---

## Apéndice A · Mapa del código **[VALIDADO]**

Ruta base: `skills/csdd-multiagent-orchestrator/assets/system/`

| Archivo | Líneas | Qué hace |
|---|---|---|
| `hooks/guard.py` | 537 | Hook PreToolUse (Claude y Kimi): rutas protegidas, secretos, permisos por rol, shell por clase, git, instalaciones, CLI, sesión, presupuesto, bucles, aprobaciones Comunista |
| `lib/csdd_core.py` | 296 | Resolución de raíz y de rol, globs, TOML/JSON atómico, tareas, eventos, aprobaciones |
| `tools/csdd.py` | 918 | CLI: `init`, `task`, `worktree`, `send/route/inbox/ack`, `handoff`, `result`, `merge`, `approval`, `watchdog`, `status`, `verify`, `doctor`, `estado`, `session`, `ruta` |
| `tools/sesion.py` | 308 | Estado calculado, marcador de sesión, bitácora, horas |
| `tools/ruta_critica.py` | 353 | CPM, recurso limitado, relojes, PERT, semáforo, horizonte rodante |
| `tools/check_constitution_controls.py` | 63 | Cada MUST con control automatizado o justificación |
| `tools/check_traceability.py` | 77 | REQ → test |
| `tools/sync_agents.py` | 69 | Genera `.claude/agents` y `.agents/agents` desde `roles.toml` + skills de rol |
| `config/roles.toml` | | Permisos por rol (fuente única) |
| `config/system.toml` | | Sistema, sesión, ruta crítica |
| `config/constitution-controls.toml` | | `enforced_by` por artículo |
| `policy/semgrep/` | | 14 reglas + fixtures |
| `integrations/` | | Claude `settings.json`, plantilla de hooks de Kimi, workflow de CI, gitleaks |
| `templates/` | | Contratos, mensajes, aprobaciones, informes, `AGENTS.md`, `CLAUDE.md`, ruta crítica |

Total: **2 621 líneas** de Python de runtime + 438 de pruebas end-to-end + 120 de pruebas de brechas.

## Apéndice B · Contratos de datos

**Tarea** (`.project/state/tasks/<T>.json`): `task_id, title, objective, owner_role, runtime, status, req_ids, articles, allowed_paths, dependencies_allowed, acceptance_criteria, depends_on, verification{qa_required, security_review_required, commands}, budget{max_tool_calls, max_minutes, max_retries}, worktree{path, branch, base, base_commit, review_path, review_branch}, results[{by, status, summary, evidence, blocking, at, commit}], retries, handoff, merged, created_at, updated_at`.
Estados: `QUEUED → IN_PROGRESS → IN_REVIEW → DONE`; `REWORK` tras FAIL; `STUCK` por reintentos, tiempo o presupuesto; `CANCELLED`.

**Mensaje** (`.project/mailbox/.../<id>.json`, `schema: csdd-message/0.4`): `message_id, created_at, from, to, type (TASK|HANDOFF|QUESTION|ANSWER|RESULT|BLOCKER), task_id, summary (≤ 600), refs[], reply_to, needs_user` (+ `status`, `blocking` en RESULT; `changed_files` en HANDOFF). Inmutable; el estado sale de su ubicación (`outbox → inbox → archive | rejected`) y de `state/acks/`.

**Evento** (`.project/log/events.jsonl`, una línea JSON): `ts, kind (tool|cli), role, role_source, task, tool, class, paths|command (redactado), decision (allow|block), reason, notes`.

**Autorización** (`.project/state/approvals/*.toml`): `approval_id, task_id, role, status, purpose, valid_from, expires_at, risk_assessment, rollback, required_reviews, [scope]{paths, dependencies, commands_regex}`.

## Apéndice C · Glosario

| Término | Significa |
|---|---|
| **CSDD** | Constitutional Spec-Driven Development: reglas de proyecto (constitución) + especificaciones con requisitos verificables + verificación |
| **Constitución** | `constitution.md`: 9 artículos base (Library-First, Test-First, validación en límites, mínimo privilegio, defensa en profundidad, fail secure, auditabilidad, sin secretos, verificación reproducible) con nivel MUST/SHOULD/MAY |
| **Jefe Maestro** | Rol líder: planea, enruta, integra, informa |
| **Jarvis** (+ Tráiler) | Rol de arquitectura y especificación (Tráiler = modo de descubrimiento) |
| **El Hombre de la Bolsa** | Rol que implementa código, una tarea a la vez |
| **Cortana** | Rol de QA e integración: re-ejecuta y registra RESULT |
| **El Portero** | Rol de seguridad: puede bloquear con evidencia |
| **Comunista** | Ya no es un agente: es una autorización temporal y acotada creada por el propietario |
| **Worktree** | Copia de trabajo aislada de git con su propia rama |
| **Guard** | Hook que se ejecuta antes de cada llamada a herramienta y bloquea lo no permitido (exit 2) |
| **RESULT** | Veredicto de verificación: PASS, FAIL, NOT_RUN, NOT_APPLICABLE, UNKNOWN |
| **Reloj** | Espera de calendario que no consume horas de trabajo (p. ej. 2 meses de uso real) |
| **Tramo** | Grupo de tareas que termina en un punto de control y un bloque de deuda |
| **Propietario** | Camilo: autoridad final; nadie más aprueba gates, crea autorizaciones ni fusiona a `main` |

## Apéndice D · Fuentes y límites de este documento

- Lo marcado **[VALIDADO]** sobre el código lo comprobé leyéndolo o con las pruebas de `tests/`. Lo marcado así sobre herramientas externas (Claude Code, Kimi Code, OWASP, estudios de sistemas multiagente) proviene de la **investigación del 3-nov-2026** que Camilo activó, con sus fuentes en ese informe; no repetí esa búsqueda aquí y las versiones de las herramientas **cambian rápido**.
- Las horas son estimaciones sin datos propios del colaborador. Recalcúlalas tras el primer WP con `csdd.py ruta` y las horas reales: es justo para lo que sirve.
- Este roadmap es un **borrador de Aurora para que Camilo y su colaborador lo ajusten**, no un plan aprobado. Las decisiones de §6 son de ellos.

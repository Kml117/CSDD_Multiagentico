# ADR-0003 — Cinco roles con permisos reales, buzón enrutado por Jefe Maestro y Comunista como protocolo

- **Fecha:** 2026-11-03
- **Estado:** **Aceptado** (decisión del propietario en la sesión del 2026-11-03)
- **Decisor:** Camilo
- **Artículos relacionados:** IV (mínimo privilegio), VII (auditabilidad), VI (fail secure)

## Contexto
v0.3.0 tenía nueve roles cuyos `SKILL.md` compartían el mismo procedimiento y límites; solo cambiaban responsabilidades y salidas. Nada hacía cumplir permisos. El buzón suponía un "orquestador" que enrutaba, pero con Claude Code y Kimi como procesos aislados nadie cumplía ese papel. "Comunista" era un agente con capacidad de ejecutar acciones excepcionales, el mayor riesgo de privilegio del sistema.

## Opciones consideradas
- **Roles:** (A) 4-5 roles con permisos distintos y reales · (B) mantener 9 como "sombreros" de un agente. → **Elegida A**, con exigencia de que cada rol tenga impacto diferente.
- **Enrutador:** (A) script automático que valida y enruta · (B) Claude Code como enrutador explícito (Jefe Maestro); Kimi solo lee y escribe su bandeja. → **Elegida B**.

## Decisión
1. Cinco roles: Jefe Maestro, Jarvis (+ modo Tráiler), El Hombre de la Bolsa, Cortana (+ integración), El Portero. Permisos en `roles.toml`, aplicados por `guard.py`.
2. Solo Jefe Maestro ejecuta `csdd.py route` y `csdd.py merge`; seis tipos de mensaje.
3. Comunista pasa a protocolo de autorización acotada, creada solo por el propietario y aplicada por el guard.
4. El operador Git se absorbe en Jefe Maestro mediante `csdd.py worktree` y `merge`.

## Consecuencias
- (+) Separación verificable: probada en `tests/test_system.py` (9 pruebas end-to-end).
- (+) Menos coordinación libre, que es la principal fuente de fallos en sistemas multiagente.
- (−) Latencia: los mensajes esperan a que Jefe Maestro enrute.
- (−) Los hooks de Kimi son fail-open y el análisis de shell es heurístico: CI sigue siendo el gate real.
- (−) Los nombres de los dos roles pendientes de v0.3.0 desaparecen (ya no son necesarios).

# ADR-0004 — Protocolo de sesión anti-retrabajo y ruta crítica adaptable

- **Fecha:** 2026-11-03
- **Estado:** Parte 1 y 2 **aceptadas** (propuesta de Camilo desde la práctica de Corbeta) · Parte 3 **abierta** (decide Camilo)
- **Decisor:** Camilo
- **Artículos relacionados:** IX (verificación reproducible), VII (auditabilidad)

## Contexto
En Corbeta (2-nov-2026) se perdieron horas reconstruyendo el estado del proyecto desde documentos contradictorios; hubo errores reales (migración dada por aplicada sin estarlo, RATIFY hecho por un agente, estados de ADR equivocados). Se resolvió con `scripts/estado.sh` + `PROTOCOLO-SESION.md`. En paralelo, `RUTA-CRITICA.md` mostró que, con un solo recurso de 7 h/semana, el orden de ejecución puede ganar ~2 meses si los relojes de calendario se arrancan temprano.

## Decisión
1. **Protocolo de sesión como MUST operativo del sistema**, hecho cumplir por el guard: sin `csdd.py session start` no se modifica nada; `session end` exige verificación si se tocó código y horas en la bitácora (≤ 10 líneas). Prohibidos `git add -A`, `git add .` y `git commit -a`. Control `session-protocol` y `no-blind-add` del Art. IX en `constitution-controls.toml`.
2. **Ruta crítica derivada del ciclo de vida y del enfoque**, calculada por `csdd.py ruta` (CPM, recurso limitado, relojes, PERT, horizonte rodante), con tramos, bloques de deuda, entradas del propietario en tanda y semáforo de hitos. Dueño: Jefe Maestro; aprueba el propietario.
3. **¿Artículo constitucional propio?** (abierta)

| Opción | Implica | A favor | En contra |
|---|---|---|---|
| **A. Control del Art. IX (aplicada)** | Sin cambio doctrinal; MUST del sistema vía guard | No toca los 9 artículos; ya muerde | Art. IX es SHOULD: en un proyecto sin el sistema, queda como recomendación |
| **B. Artículo de dominio "Estado verificable" (MUST)** | Se ratifica en la constitución de cada proyecto que lo necesite | Obligación explícita y auditable aunque cambie la herramienta | Más ceremonia; requiere ADR de adopción por proyecto |

**Recomendación (yo propongo):** A como base para todos; B solo en proyectos con datos sensibles o donde varios agentes trabajen en paralelo de forma sostenida (Corbeta califica).

## Consecuencias
- (+) Probado: `tests/test_system.py` 10–12 (gate de sesión, alertas, bitácora y horas, ruta crítica que reproduce las cifras de Corbeta).
- (+) Corbeta puede reemplazar `estado.sh` por `csdd.py estado` configurando `[session]` (ejemplo en `references/ruta-critica.md` §5), o mantener ambos.
- (−) Fricción: ninguna edición sin `session start` (12 h de vigencia).
- (−) En Kimi el hook es fail-open: el gate de sesión es disciplina asistida, no garantía.

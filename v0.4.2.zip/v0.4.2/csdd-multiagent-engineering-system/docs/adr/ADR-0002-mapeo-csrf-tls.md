# ADR-0002 — Corrección del mapeo SEC→artículo (CSRF, SEC-014) y propuesta sobre TLS

- **Fecha:** 2026-11-03
- **Estado:** Parte A **aplicada en csdd-mentor v1.6.0, pendiente de tu ratificación** · Parte B **propuesta**
- **Decisor autorizado:** Camilo (propietario; ratifica la constitución base)
- **Artículos afectados:** III, V, VI, VIII

## Contexto
La tabla "Policy as Code" de csdd-mentor v1.5.0 mapeaba SEC-003 (anti-CSRF, CWE-352) al Artículo V, que es **SHOULD**. CWE-352 es el #3 del CWE Top 25 de 2025 (MITRE/CISA, 11 dic 2025): una de las debilidades más explotadas quedaba sin obligación. SEC-014 (errores sin detalles internos, CWE-200) estaba en el Artículo VIII (secretos en código), cuando su naturaleza es fallar sin exponer (Artículo VI). SEC-013 (TLS ≥ 1.2, CWE-319) está en V (SHOULD).

## Parte A — Corrección de mapeo (aplicada en v1.6.0, reversible)
- SEC-003 CSRF → **Artículo III** (MUST): verificar token u `Origin` de una petición que muta estado es validar en el límite.
- SEC-014 → **Artículo VI** (MUST).
- No cambia el texto ni el nivel de ningún artículo; cambia qué controles se exigen bajo cada uno.
- Efecto práctico: El Portero revisa CSRF como obligación (`csdd-art3-csrf-review` en `constitution-controls.toml`).
- **Si no la ratificas:** revierte las dos filas en `references/workflow-fases.md` y la entrada de controles; el resto del sistema no depende de esto.

## Parte B — TLS (propuesta, no aplicada)
| Opción | Qué implica | A favor | En contra |
|---|---|---|---|
| **B1. Artículo X "Transporte seguro" (MUST)** | Nuevo artículo core: todo tráfico externo con TLS ≥ 1.2 verificado; prohibido `verify=False` | Claridad; un control MUST explícito | Rompe el "9 artículos" base; requiere actualizar enseñanza y matrices |
| **B2. Anexo MUST dentro del Art. V** | V sigue SHOULD en general, pero SEC-003 y SEC-013 quedan como controles MUST listados | No crea artículo nuevo | Mezcla niveles dentro de un artículo; más fácil de malinterpretar |
| B0. No hacer nada | TLS sigue SHOULD | Cero costo | Un `verify=False` no bloquearía un proyecto con datos sensibles |

**Recomendación (yo propongo):** B1 para proyectos con datos personales o pagos (dominio), y B0 para prototipos locales, declarándolo en el ADR de adopción de cada proyecto. Requiere tu ratificación; ningún agente lo aplica.

## Consecuencias
Mientras no decidas B: la regla Semgrep `csdd-art5-requests-verify-false` ya marca `verify=False` como ERROR en CI, aunque el artículo sea SHOULD.

"""Brechas conocidas de CSDD v0.4.1 como pruebas de aceptación ejecutables.

Cada prueba describe el comportamiento DESEADO y hoy FALLA a propósito (@unittest.expectedFailure).
Es el backlog ejecutable del ROADMAP-DESARROLLO.md:

  * Al implementar un paquete de trabajo, la prueba pasará y unittest avisará "unexpected success".
  * Entonces quita el decorador @expectedFailure de esa prueba y déjala como prueba de regresión.
  * Mientras esté marcada, `python3 -m unittest discover -s tests` sigue en verde.

Ejecutar solo este archivo:  python3 -m unittest tests.test_known_gaps -v   (desde la raíz del paquete)
"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_system import PKG, PY, run  # noqa: E402


class KnownGaps(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp(prefix="csdd-gaps-"))
        cls.repo = cls.tmp / "repo"
        cls.repo.mkdir()
        run(["git", "init", "-q", "-b", "main"], cls.repo, check=True)
        (cls.repo / "README.md").write_text("x\n", encoding="utf-8")
        run(["git", "add", "README.md"], cls.repo, check=True)
        run(["git", "commit", "-qm", "init"], cls.repo, check=True)
        run(["bash", str(PKG / "scripts" / "install.sh"), str(cls.repo)], cls.repo, check=True)
        run(["git", "add", "-A"], cls.repo, check=True)
        run(["git", "commit", "-qm", "install", "--no-verify"], cls.repo, check=True)
        cls.cli(cls.repo, "session", "start")
        cls.cli(cls.repo, "task", "new", "--id", "T-1", "--title", "gap", "--role",
                "csdd-implementation-engineer", "--paths", "src/a/**")
        cls.cli(cls.repo, "worktree", "new", "T-1")
        task = json.loads((cls.repo / ".project/state/tasks/T-1.json").read_text(encoding="utf-8"))
        cls.wt = Path(task["worktree"]["path"])
        cls.cli(cls.wt, "session", "start")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    @staticmethod
    def cli(cwd, *args):
        return run([PY, ".csdd/tools/csdd.py", *args], cwd)

    def guard_bash(self, command: str) -> int:
        payload = {"tool_name": "Bash", "tool_input": {"command": command}, "cwd": str(self.wt)}
        return run([PY, ".csdd/hooks/guard.py"], self.wt, stdin=json.dumps(payload)).returncode

    # ------------------------------------------------------------------ R1-R2: guard
    @unittest.expectedFailure
    def test_gap_interpreter_inline_cannot_write_outside_scope(self):
        """WP-S1: `python -c`, `node -e`, `perl -e`, `ruby -e` no deben poder escribir fuera de allowed_paths."""
        for cmd in ("python3 -c \"open('src/otro.py','w').write('x')\"",
                    "node -e \"require('fs').writeFileSync('src/otro.js','x')\""):
            self.assertEqual(self.guard_bash(cmd), 2, cmd)

    @unittest.expectedFailure
    def test_gap_role_identity_file_cannot_be_forged(self):
        """WP-S2: reescribir `.csdd-task` (la identidad del rol) con un intérprete debe estar bloqueado."""
        self.assertEqual(self.guard_bash("python3 -c \"open('.csdd-task','w').write('{}')\""), 2)

    # ------------------------------------------------------------------ R3: auditoría
    @unittest.expectedFailure
    def test_gap_events_log_is_tamper_evident(self):
        """WP-S3: cada evento de events.jsonl lleva el hash del anterior (cadena de hashes)."""
        self.guard_bash("ls")
        log = (self.repo / ".project" / "log" / "events.jsonl").read_text(encoding="utf-8").splitlines()
        self.assertTrue(log and all("prev_hash" in json.loads(l) for l in log[-3:]))

    @unittest.expectedFailure
    def test_gap_approvals_are_signed(self):
        """WP-S4: una autorización Comunista lleva firma verificable (HMAC con secreto del propietario o similar)."""
        self.cli(self.repo, "approval", "new", "--task", "T-1", "--purpose", "gap", "--paths", "scripts/**", "--hours", "1")
        files = sorted((self.repo / ".project" / "state" / "approvals").glob("*.toml"))
        self.assertTrue(files and "signature" in files[-1].read_text(encoding="utf-8"))

    # ------------------------------------------------------------------ R4-R6: automatización
    @unittest.expectedFailure
    def test_gap_router_watch_exists(self):
        """WP-R1: `csdd.py watch` enruta el buzón en continuo (proceso del propietario, no un agente)."""
        self.assertEqual(self.cli(self.repo, "watch", "--once").returncode, 0)

    @unittest.expectedFailure
    def test_gap_inbox_is_injected_into_agent_context(self):
        """WP-R2: existe un hook que inyecta la bandeja pendiente al abrir sesión o enviar un prompt."""
        self.assertTrue((self.repo / ".csdd" / "hooks" / "inbox_hook.py").exists())

    @unittest.expectedFailure
    def test_gap_runner_launches_agents_headless(self):
        """WP-R3: `csdd.py run <TAREA> --dry-run` imprime el comando exacto que lanzaría al agente de la tarea."""
        self.assertEqual(self.cli(self.repo, "run", "T-1", "--dry-run").returncode, 0)

    @unittest.expectedFailure
    def test_gap_dispatcher_exists(self):
        """WP-R4: `csdd.py dispatch --dry-run` calcula qué tareas listas se pueden lanzar ahora (DAG, rutas, límite)."""
        self.assertEqual(self.cli(self.repo, "dispatch", "--dry-run").returncode, 0)

    # ------------------------------------------------------------------ R7: costos y evaluación
    @unittest.expectedFailure
    def test_gap_cost_report_exists(self):
        """WP-O1: `csdd.py report` resume llamadas, tokens y costo por tarea y por rol."""
        self.assertEqual(self.cli(self.repo, "report").returncode, 0)

    @unittest.expectedFailure
    def test_gap_eval_harness_exists(self):
        """WP-E1: `.csdd/evals/` con tareas canario y un comando que compara los tres modos."""
        self.assertTrue((self.repo / ".csdd" / "evals" / "README.md").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/usr/bin/env python3
"""Construye las versiones para claude.ai (web) desde las MISMAS fuentes de skills/.

Una .zip por skill (claude.ai sube una skill por archivo), con la carpeta <name>/ en la raíz.
Valida las reglas de subida: un solo SKILL.md, carpeta == name, name kebab-case ≤ 64,
description ≤ 1024 sin '<' ni '>', claves de frontmatter permitidas.
Uso: python3 scripts/build_claude_web.py [--out dist/claude-web]
"""
from __future__ import annotations

import argparse
import hashlib
import re
import sys
import zipfile
from pathlib import Path

ALLOWED = {"name", "description", "license", "allowed-tools", "metadata", "compatibility"}
EXCLUDE_DIRS = {"__pycache__", "node_modules", ".git"}


def frontmatter(text: str) -> dict:
    m = re.match(r"^---\n(.*?)\n---", text, re.S)
    if not m:
        raise ValueError("sin frontmatter YAML")
    try:
        import yaml  # type: ignore
        data = yaml.safe_load(m.group(1))
        if not isinstance(data, dict):
            raise ValueError("frontmatter no es un diccionario")
        return data
    except ImportError:
        data = {}
        for line in m.group(1).splitlines():
            km = re.match(r"^([A-Za-z][\w-]*):\s*(.*)$", line)
            if km:
                v = km.group(2).strip()
                if v.startswith('"') and v.endswith('"'):
                    v = v[1:-1].replace('\\"', '"')
                data[km.group(1)] = v
        return data


def validate(skill: Path) -> list[str]:
    errs = []
    md = skill / "SKILL.md"
    if not md.exists():
        return ["falta SKILL.md"]
    extra = [p for p in skill.rglob("SKILL.md") if p != md and not set(p.parts) & EXCLUDE_DIRS]
    if extra:
        errs.append(f"SKILL.md anidados: {extra}")
    fm = frontmatter(md.read_text(encoding="utf-8"))
    bad = set(fm) - ALLOWED
    if bad:
        errs.append(f"claves no permitidas en frontmatter: {sorted(bad)}")
    name = str(fm.get("name", "")).strip()
    if name != skill.name:
        errs.append(f"name '{name}' != carpeta '{skill.name}'")
    if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", name) or len(name) > 64:
        errs.append(f"name inválido: '{name}'")
    desc = str(fm.get("description", "")).strip()
    if not desc or len(desc) > 1024:
        errs.append(f"description de {len(desc)} caracteres (1..1024)")
    if "<" in desc or ">" in desc:
        errs.append("description contiene '<' o '>'")
    lines = md.read_text(encoding="utf-8").count("\n")
    if lines > 500:
        errs.append(f"SKILL.md de {lines} líneas (> 500 recomendado)")
    return errs


def build(skill: Path, out: Path) -> Path:
    dst = out / f"{skill.name}.zip"
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(skill.rglob("*")):
            if f.is_dir() or set(f.relative_to(skill).parts) & EXCLUDE_DIRS or f.suffix == ".pyc":
                continue
            z.write(f, Path(skill.name) / f.relative_to(skill))
    return dst


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="dist/claude-web")
    a = ap.parse_args(argv)
    root = Path(__file__).resolve().parent.parent
    out = (root / a.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    failed = False
    rows = []
    for skill in sorted((root / "skills").iterdir()):
        if not skill.is_dir():
            continue
        errs = validate(skill)
        if errs:
            failed = True
            print(f"FAIL {skill.name}: " + "; ".join(errs))
            continue
        z = build(skill, out)
        sha = hashlib.sha256(z.read_bytes()).hexdigest()[:16]
        n = sum(1 for _ in zipfile.ZipFile(z).namelist())
        rows.append((skill.name, n, z.stat().st_size, sha))
        print(f"OK   {skill.name:<32} {n:>3} archivos  {z.stat().st_size / 1024:>7.1f} KB  sha256:{sha}")
    (out / "CHECKSUMS.txt").write_text("".join(f"{r[0]}.zip  {r[1]} archivos  {r[2]} bytes  sha256-16:{r[3]}\n" for r in rows),
                                      encoding="utf-8")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())

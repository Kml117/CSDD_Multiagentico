﻿# =============================================================================
# CSDD Multi-Agent v0.4.2 — instalador para Windows PowerShell
# Uso: .\scripts\Install.ps1 -TargetPath C:\ruta\repo [-Force] [-ClaudeOnly] [-AgentsOnly] [-NoHooksPath]
# Idempotente: omite lo existente; -Force respalda en .csdd-backup\<fecha>\ y reemplaza.
# =============================================================================
param(
  [string]$TargetPath = (Get-Location).Path,
  [switch]$Force, [switch]$ClaudeOnly, [switch]$AgentsOnly, [switch]$NoHooksPath
)
$ErrorActionPreference = 'Stop'
$Pkg = Split-Path -Parent $PSScriptRoot
$Target = (Resolve-Path $TargetPath).Path
# Python 3.11+: se PRUEBA cada candidato. Se descarta el alias vacío de la Tienda de Microsoft (existe pero no corre).
# Se puede forzar con la variable CSDD_PYTHON.
function Find-Python {
  $candidates = @()
  if ($env:CSDD_PYTHON) { $candidates += ,@($env:CSDD_PYTHON) }
  $candidates += ,@('py', '-3')
  $candidates += ,@('python')
  $candidates += ,@('python3')
  foreach ($c in $candidates) {
    $exe = $c[0]; $pre = @(); if ($c.Count -gt 1) { $pre = $c[1..($c.Count - 1)] }
    if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { continue }
    try {
      & $exe @pre -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" *> $null
      if ($LASTEXITCODE -eq 0) { return @{ Exe = $exe; Pre = $pre } }
    } catch { }
  }
  return $null
}
$found = Find-Python
if (-not $found) {
  throw ("No encontré un Python 3.11+ que funcione. Instálalo (python.org o: winget install Python.Python.3.12) y reabre PowerShell. " +
         "Si 'python' solo abre la Tienda de Microsoft, desactiva el alias en Configuración > Aplicaciones > Configuración avanzada de aplicaciones > Alias de ejecución de aplicaciones. " +
         "O indica la ruta con: `$env:CSDD_PYTHON = 'C:\ruta\python.exe'")
}
$PyExe = $found.Exe; $PyPre = $found.Pre
$env:PYTHONUTF8 = '1'; $env:PYTHONIOENCODING = 'utf-8'   # tildes correctas en la consola de Windows
git -C $Target rev-parse --show-toplevel *> $null
if ($LASTEXITCODE -ne 0) { throw "$Target no es un repositorio git (git init primero)." }
$Ts = Get-Date -Format 'yyyyMMdd-HHmmss'
$Backup = Join-Path $Target ".csdd-backup\$Ts"
$SkillDirs = @('.claude\skills', '.agents\skills')
if ($ClaudeOnly) { $SkillDirs = @('.claude\skills') }
if ($AgentsOnly) { $SkillDirs = @('.agents\skills') }

function Copy-Dir($Src, $Dst) {
  if (Test-Path $Dst) {
    if ($Force) {
      $rel = $Dst.Substring($Target.Length).TrimStart('\')
      $b = Join-Path $Backup $rel
      New-Item -ItemType Directory -Force -Path (Split-Path $b) | Out-Null
      Move-Item $Dst $b
      Write-Host "  respaldo: $rel"
    } else { Write-Host "  OMITIDO (ya existe): $Dst  (usa -Force)"; return }
  }
  New-Item -ItemType Directory -Force -Path (Split-Path $Dst) | Out-Null
  Copy-Item -Recurse $Src $Dst
  Write-Host "  OK $Dst"
}
function Copy-FileOrSide($Src, $Dst, $Alt) {
  New-Item -ItemType Directory -Force -Path (Split-Path $Dst) | Out-Null
  if (Test-Path $Dst) { Copy-Item $Src $Alt; Write-Host "  YA EXISTE $Dst -> dejé $Alt para merge manual" }
  else { Copy-Item $Src $Dst; Write-Host "  OK $Dst" }
}

Write-Host '== Skills'
Get-ChildItem (Join-Path $Pkg 'skills') -Directory | ForEach-Object {
  foreach ($d in $SkillDirs) {
    $dst = Join-Path $Target "$d\$($_.Name)"
    Copy-Dir $_.FullName $dst
    $sys = Join-Path $dst 'assets\system'
    if (Test-Path $sys) { Remove-Item -Recurse -Force $sys }
  }
}
Write-Host '== Sistema (.csdd)'
Copy-Dir (Join-Path $Pkg 'skills\csdd-multiagent-orchestrator\assets\system') (Join-Path $Target '.csdd')
Write-Host '== Integraciones'
$settings = Join-Path $Target '.claude\settings.json'
Copy-FileOrSide (Join-Path $Target '.csdd\integrations\claude\settings.json') $settings (Join-Path $Target '.claude\settings.csdd.json')
# Sin BOM: Windows PowerShell 5.1 con "-Encoding UTF8" escribe BOM y puede romper el JSON de settings.json
$pyName = if ($PyExe -eq 'py') { 'py -3' } else { 'python' }
$txt = (Get-Content $settings -Raw -Encoding UTF8) -replace 'python3 ', "$pyName "
[System.IO.File]::WriteAllText($settings, $txt, (New-Object System.Text.UTF8Encoding($false)))
Copy-FileOrSide (Join-Path $Target '.csdd\templates\repo\AGENTS.md') (Join-Path $Target 'AGENTS.md') (Join-Path $Target 'AGENTS.csdd.md')
Copy-FileOrSide (Join-Path $Target '.csdd\templates\repo\CLAUDE.md') (Join-Path $Target 'CLAUDE.md') (Join-Path $Target 'CLAUDE.csdd.md')
$wf = Join-Path $Target '.github\workflows\csdd-gate.yml'
if (Test-Path $wf) { Write-Host "  OMITIDO $wf (ya existe)" } else {
  New-Item -ItemType Directory -Force -Path (Split-Path $wf) | Out-Null
  Copy-Item (Join-Path $Target '.csdd\integrations\github\csdd-gate.yml') $wf; Write-Host "  OK $wf" }
Write-Host '== Agentes generados desde roles.toml'
& $PyExe @PyPre (Join-Path $Target '.csdd\tools\sync_agents.py') $Target
Write-Host '== Coordinación (.project)'
Push-Location $Target; & $PyExe @PyPre '.csdd\tools\csdd.py' init; Pop-Location
if (-not $NoHooksPath) {
  $current = git -C $Target config --get core.hooksPath
  if (-not $current) { git -C $Target config core.hooksPath .csdd/git-hooks; Write-Host '  OK core.hooksPath = .csdd/git-hooks' }
  elseif ($current -ne '.csdd/git-hooks') { Write-Host "  AVISO: core.hooksPath ya es '$current'." }
}
Write-Host ''
Write-Host 'Listo. 1) Commitea .csdd .claude .agents AGENTS.md CLAUDE.md .github en tu rama base.'
Write-Host '2) Kimi: plantilla .csdd\integrations\kimi\hooks.example.toml (VERIFICAR esquema).'
Write-Host "3) Diagnóstico: $PyExe $($PyPre -join ' ') .csdd\tools\csdd.py doctor"
Write-Host '   Nota: el hook de Claude Code usa el intérprete detectado (python o py -3), no python3.'

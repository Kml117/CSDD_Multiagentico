#!/usr/bin/env bash
# =============================================================================
# CSDD Multi-Agent v0.4.2 — instalador (Linux / macOS / Git Bash en Windows)
# Uso: bash scripts/install.sh [RUTA_DEL_REPO] [--force] [--claude-only|--agents-only] [--no-hooks-path]
#  - Idempotente: si algo ya existe, lo OMITE (no aborta). --force respalda en .csdd-backup/<fecha>/ y reemplaza.
#  - Nunca sobrescribe tu AGENTS.md, CLAUDE.md, .claude/settings.json ni tu workflow de CI: deja una copia
#    *.csdd.* para que hagas el merge a mano.
# =============================================================================
set -euo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET=""; FORCE=0; HOOKS_PATH=1; SKILL_DIRS=(".claude/skills" ".agents/skills")
for arg in "$@"; do
  case "$arg" in
    --force) FORCE=1 ;;
    --claude-only) SKILL_DIRS=(".claude/skills") ;;
    --agents-only) SKILL_DIRS=(".agents/skills") ;;
    --no-hooks-path) HOOKS_PATH=0 ;;
    -*) echo "Opción desconocida: $arg" >&2; exit 1 ;;
    *) TARGET="$arg" ;;
  esac
done
TARGET="$(cd "${TARGET:-$PWD}" && pwd)"
# Python 3.11+: se PRUEBA cada candidato ejecutándolo. Un nombre que existe pero no corre (p. ej. el alias de
# la Tienda de Microsoft en Windows, o un python 3.9 del sistema) se descarta. Se puede forzar: CSDD_PYTHON=/ruta/python
find_python() {
  local c path
  for c in "${CSDD_PYTHON:-}" python3.13 python3.12 python3.11 python3 python; do
    [[ -n "$c" ]] || continue
    path="$(command -v "$c" 2>/dev/null)" || continue
    if "$path" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)' >/dev/null 2>&1; then
      printf '%s\n' "$path"; return 0
    fi
  done
  return 1
}
PY="$(find_python)" || {
  cat >&2 <<'ERR'
ERROR: no encontré un Python 3.11+ que funcione (se probaron python3.13, python3.12, python3.11, python3 y python).
  - Instálalo (python.org, brew install python@3.12, winget install Python.Python.3.12, o uv) y reabre la terminal.
  - Windows: si `python3` solo abre la Tienda de Microsoft, es un alias vacío; desactívalo en
    Configuración > Aplicaciones > Configuración avanzada de aplicaciones > Alias de ejecución de aplicaciones.
  - Si ya lo tienes en otra ruta: CSDD_PYTHON=/ruta/al/python bash scripts/install.sh <repo>
ERR
  exit 1
}
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8   # tildes correctas en consolas heredadas (Windows)
git -C "$TARGET" rev-parse --show-toplevel >/dev/null 2>&1 || { echo "ERROR: $TARGET no es un repositorio git (git init primero)." >&2; exit 1; }
TS="$(date +%Y%m%d-%H%M%S)"; BACKUP="$TARGET/.csdd-backup/$TS"

copy_dir() {  # origen destino
  local src="$1" dst="$2"
  if [[ -e "$dst" ]]; then
    if [[ $FORCE -eq 1 ]]; then
      mkdir -p "$BACKUP/$(dirname "${dst#$TARGET/}")"; mv "$dst" "$BACKUP/${dst#$TARGET/}"
      echo "  respaldo: ${dst#$TARGET/} -> .csdd-backup/$TS/"
    else
      echo "  OMITIDO (ya existe): ${dst#$TARGET/}  (usa --force para actualizar)"; return 0
    fi
  fi
  mkdir -p "$(dirname "$dst")"; cp -R "$src" "$dst"; echo "  OK ${dst#$TARGET/}"
}
copy_file_or_side() {  # origen destino alterno
  local src="$1" dst="$2" alt="$3"
  mkdir -p "$(dirname "$dst")"
  if [[ -e "$dst" ]]; then cp "$src" "$alt"; echo "  YA EXISTE ${dst#$TARGET/}: dejé ${alt#$TARGET/} para merge manual"
  else cp "$src" "$dst"; echo "  OK ${dst#$TARGET/}"; fi
}

echo "== Skills"
for skill in "$PKG"/skills/*/; do
  name="$(basename "$skill")"
  for d in "${SKILL_DIRS[@]}"; do
    copy_dir "${skill%/}" "$TARGET/$d/$name"
    rm -rf "$TARGET/$d/$name/assets/system" 2>/dev/null || true   # el sistema vive en .csdd/, no duplicar
  done
done
echo "== Sistema (.csdd/)"
copy_dir "$PKG/skills/csdd-multiagent-orchestrator/assets/system" "$TARGET/.csdd"
echo "== Integraciones"
copy_file_or_side "$TARGET/.csdd/integrations/claude/settings.json" "$TARGET/.claude/settings.json" "$TARGET/.claude/settings.csdd.json"
PYNAME="$(basename "$PY")"; PYNAME="${PYNAME%.exe}"   # el hook usará el intérprete que SÍ funciona (p. ej. python)
if [[ "$PYNAME" != "python3" && "$PYNAME" =~ ^[A-Za-z0-9._-]+$ ]]; then
  sed -i.bak "s/python3 /${PYNAME} /" "$TARGET/.claude/settings.json" 2>/dev/null && rm -f "$TARGET/.claude/settings.json.bak" || true
fi
copy_file_or_side "$TARGET/.csdd/templates/repo/AGENTS.md" "$TARGET/AGENTS.md" "$TARGET/AGENTS.csdd.md"
copy_file_or_side "$TARGET/.csdd/templates/repo/CLAUDE.md" "$TARGET/CLAUDE.md" "$TARGET/CLAUDE.csdd.md"
if [[ -e "$TARGET/.github/workflows/csdd-gate.yml" ]]; then echo "  OMITIDO .github/workflows/csdd-gate.yml (ya existe)"
else mkdir -p "$TARGET/.github/workflows"; cp "$TARGET/.csdd/integrations/github/csdd-gate.yml" "$TARGET/.github/workflows/csdd-gate.yml"; echo "  OK .github/workflows/csdd-gate.yml"; fi
echo "== Agentes generados desde roles.toml"
"$PY" "$TARGET/.csdd/tools/sync_agents.py" "$TARGET" | sed 's/^/  /'
echo "== Coordinación (.project/)"
(cd "$TARGET" && "$PY" .csdd/tools/csdd.py init | sed 's/^/  /')
if [[ $HOOKS_PATH -eq 1 ]]; then
  current="$(git -C "$TARGET" config --get core.hooksPath || true)"
  if [[ -z "$current" ]]; then git -C "$TARGET" config core.hooksPath .csdd/git-hooks; echo "  OK core.hooksPath = .csdd/git-hooks"
  elif [[ "$current" != ".csdd/git-hooks" ]]; then echo "  AVISO: core.hooksPath ya es '$current'. Llama a .csdd/git-hooks/pre-commit desde tu hook."; fi
fi
cat <<MSG

Listo. Siguientes pasos:
  1. Revisa el diff y commitea .csdd/ .claude/ .agents/ AGENTS.md CLAUDE.md .github/ en tu rama base
     (los worktrees heredan el guard solo si está commiteado).
  2. Kimi Code: copia la plantilla .csdd/integrations/kimi/hooks.example.toml a ~/.kimi-code/config.toml
     y VERIFICA el esquema contra la documentación oficial.
  3. Diagnóstico: $PY .csdd/tools/csdd.py doctor
  4. Lee EXECUTION_GUIDE.md (flujo completo Jefe Maestro -> worktrees -> Cortana -> merge).
MSG
